--
-- PostgreSQL database dump
--

\restrict ANIYBWw2gwLiQ5lecv5eybL9agm95V8wtEazjkLTnd1aiNHE0OYBYFVmTZtnsXY

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.warehouse_stock DROP CONSTRAINT IF EXISTS warehouse_stock_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.warehouse_stock DROP CONSTRAINT IF EXISTS warehouse_stock_stock_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.voucher_attachments DROP CONSTRAINT IF EXISTS voucher_attachments_voucher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.vendor_payments DROP CONSTRAINT IF EXISTS vendor_payments_vendor_invoice_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_sales_person_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_transfers DROP CONSTRAINT IF EXISTS stock_transfers_to_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_transfers DROP CONSTRAINT IF EXISTS stock_transfers_from_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_transfer_items DROP CONSTRAINT IF EXISTS stock_transfer_items_stock_transfer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_transfer_items DROP CONSTRAINT IF EXISTS stock_transfer_items_stock_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_serials DROP CONSTRAINT IF EXISTS stock_serials_stock_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_stock_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_item_purchase_prices DROP CONSTRAINT IF EXISTS stock_item_purchase_prices_stock_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_adjustments DROP CONSTRAINT IF EXISTS stock_adjustments_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_adjustments DROP CONSTRAINT IF EXISTS stock_adjustments_stock_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_permission_id_fkey;
ALTER TABLE IF EXISTS ONLY public.report_templates DROP CONSTRAINT IF EXISTS report_templates_report_definition_id_fkey;
ALTER TABLE IF EXISTS ONLY public.report_fields DROP CONSTRAINT IF EXISTS report_fields_report_definition_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pos_sales DROP CONSTRAINT IF EXISTS pos_sales_sales_person_id_fkey;
ALTER TABLE IF EXISTS ONLY public.opening_stock DROP CONSTRAINT IF EXISTS opening_stock_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.opening_stock DROP CONSTRAINT IF EXISTS opening_stock_stock_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.journal_lines DROP CONSTRAINT IF EXISTS journal_lines_journal_entry_id_fkey;
ALTER TABLE IF EXISTS ONLY public.journal_lines DROP CONSTRAINT IF EXISTS journal_lines_account_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invoice_payments DROP CONSTRAINT IF EXISTS invoice_payments_invoice_id_fkey;
ALTER TABLE IF EXISTS ONLY public.income_attachments DROP CONSTRAINT IF EXISTS income_attachments_income_id_fkey;
ALTER TABLE IF EXISTS ONLY public.goods_receipts DROP CONSTRAINT IF EXISTS goods_receipts_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.goods_receipt_items DROP CONSTRAINT IF EXISTS goods_receipt_items_stock_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.goods_receipt_items DROP CONSTRAINT IF EXISTS goods_receipt_items_goods_receipt_id_fkey;
ALTER TABLE IF EXISTS ONLY public.goods_issues DROP CONSTRAINT IF EXISTS goods_issues_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.goods_issue_items DROP CONSTRAINT IF EXISTS goods_issue_items_stock_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.goods_issue_items DROP CONSTRAINT IF EXISTS goods_issue_items_goods_issue_id_fkey;
ALTER TABLE IF EXISTS ONLY public.customer_deposits DROP CONSTRAINT IF EXISTS customer_deposits_journal_entry_id_fkey;
DROP INDEX IF EXISTS public.vendor_proforma_invoices_company_vpi_number_unique;
DROP INDEX IF EXISTS public.stock_movements_wh_idx;
DROP INDEX IF EXISTS public.stock_movements_item_idx;
DROP INDEX IF EXISTS public.stock_movements_date_idx;
DROP INDEX IF EXISTS public.stock_movements_company_idx;
DROP INDEX IF EXISTS public.stock_item_purchase_prices_item_idx;
DROP INDEX IF EXISTS public.service_reports_company_id_idx;
DROP INDEX IF EXISTS public.sales_persons_company_code_idx;
DROP INDEX IF EXISTS public.report_templates_one_system_default_idx;
DROP INDEX IF EXISTS public.report_templates_one_active_idx;
DROP INDEX IF EXISTS public.report_templates_company_def_name_idx;
DROP INDEX IF EXISTS public.report_fields_definition_key_idx;
DROP INDEX IF EXISTS public.report_definitions_report_type_idx;
DROP INDEX IF EXISTS public.pos_sales_company_number_idx;
DROP INDEX IF EXISTS public.pos_sales_company_channel_idx;
DROP INDEX IF EXISTS public.payroll_records_employee_period_idx;
DROP INDEX IF EXISTS public.payroll_records_company_id_idx;
DROP INDEX IF EXISTS public.licenses_company_id_idx;
DROP INDEX IF EXISTS public.ir8a_employers_company_id_idx;
DROP INDEX IF EXISTS public.idx_vendors_company;
DROP INDEX IF EXISTS public.idx_vendor_payments_vi;
DROP INDEX IF EXISTS public.idx_stock_items_company;
DROP INDEX IF EXISTS public.idx_quotations_company;
DROP INDEX IF EXISTS public.idx_purchase_orders_company;
DROP INDEX IF EXISTS public.idx_proforma_invoices_company;
DROP INDEX IF EXISTS public.idx_journal_lines_entry;
DROP INDEX IF EXISTS public.idx_journal_lines_account;
DROP INDEX IF EXISTS public.idx_journal_entries_company;
DROP INDEX IF EXISTS public.idx_invoices_company;
DROP INDEX IF EXISTS public.idx_invoice_payments_inv;
DROP INDEX IF EXISTS public.idx_grn_company;
DROP INDEX IF EXISTS public.idx_delivery_orders_company;
DROP INDEX IF EXISTS public.idx_customers_company;
DROP INDEX IF EXISTS public.idx_credit_notes_company;
DROP INDEX IF EXISTS public.idx_audit_logs_entity;
DROP INDEX IF EXISTS public.idx_audit_logs_company;
DROP INDEX IF EXISTS public.financial_years_company_dates_uidx;
DROP INDEX IF EXISTS public.employees_company_id_idx;
DROP INDEX IF EXISTS public.employee_payroll_employee_id_idx;
DROP INDEX IF EXISTS public.employee_payroll_company_id_idx;
DROP INDEX IF EXISTS public.employee_documents_company_id_idx;
DROP INDEX IF EXISTS public.companies_slug_unique;
DROP INDEX IF EXISTS public.assets_company_id_idx;
DROP INDEX IF EXISTS public.accounting_restore_ops_company_idx;
DROP INDEX IF EXISTS public.accounting_restore_ops_backup_idx;
DROP INDEX IF EXISTS public.accounting_backups_status_idx;
DROP INDEX IF EXISTS public.accounting_backups_company_idx;
DROP INDEX IF EXISTS public."IDX_session_expire";
ALTER TABLE IF EXISTS ONLY public.wht_records DROP CONSTRAINT IF EXISTS wht_records_pkey;
ALTER TABLE IF EXISTS ONLY public.warehouses DROP CONSTRAINT IF EXISTS warehouses_pkey;
ALTER TABLE IF EXISTS ONLY public.warehouses DROP CONSTRAINT IF EXISTS warehouses_company_id_code_key;
ALTER TABLE IF EXISTS ONLY public.warehouse_stock DROP CONSTRAINT IF EXISTS warehouse_stock_warehouse_id_stock_item_id_key;
ALTER TABLE IF EXISTS ONLY public.warehouse_stock DROP CONSTRAINT IF EXISTS warehouse_stock_pkey;
ALTER TABLE IF EXISTS ONLY public.vouchers DROP CONSTRAINT IF EXISTS vouchers_pkey;
ALTER TABLE IF EXISTS ONLY public.voucher_attachments DROP CONSTRAINT IF EXISTS voucher_attachments_pkey;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_pkey;
ALTER TABLE IF EXISTS ONLY public.vendor_proforma_invoices DROP CONSTRAINT IF EXISTS vendor_proforma_invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.vendor_payments DROP CONSTRAINT IF EXISTS vendor_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.vendor_opening_balances DROP CONSTRAINT IF EXISTS vendor_opening_balances_pkey;
ALTER TABLE IF EXISTS ONLY public.vendor_invoices DROP CONSTRAINT IF EXISTS vendor_invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_companies DROP CONSTRAINT IF EXISTS user_companies_user_id_company_id_key;
ALTER TABLE IF EXISTS ONLY public.user_companies DROP CONSTRAINT IF EXISTS user_companies_pkey;
ALTER TABLE IF EXISTS ONLY public.tax_filings DROP CONSTRAINT IF EXISTS tax_filings_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_transfers DROP CONSTRAINT IF EXISTS stock_transfers_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_transfer_items DROP CONSTRAINT IF EXISTS stock_transfer_items_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_serials DROP CONSTRAINT IF EXISTS stock_serials_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_items DROP CONSTRAINT IF EXISTS stock_items_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_item_purchase_prices DROP CONSTRAINT IF EXISTS stock_item_purchase_prices_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_adjustments DROP CONSTRAINT IF EXISTS stock_adjustments_pkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_pkey;
ALTER TABLE IF EXISTS ONLY public.session DROP CONSTRAINT IF EXISTS session_pkey;
ALTER TABLE IF EXISTS ONLY public.service_reports DROP CONSTRAINT IF EXISTS service_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.sales_persons DROP CONSTRAINT IF EXISTS sales_persons_pkey;
ALTER TABLE IF EXISTS ONLY public.sales_orders DROP CONSTRAINT IF EXISTS sales_orders_so_number_key;
ALTER TABLE IF EXISTS ONLY public.sales_orders DROP CONSTRAINT IF EXISTS sales_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_role_id_permission_id_unique;
ALTER TABLE IF EXISTS ONLY public.report_templates DROP CONSTRAINT IF EXISTS report_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.report_fields DROP CONSTRAINT IF EXISTS report_fields_pkey;
ALTER TABLE IF EXISTS ONLY public.report_definitions DROP CONSTRAINT IF EXISTS report_definitions_pkey;
ALTER TABLE IF EXISTS ONLY public.quotations DROP CONSTRAINT IF EXISTS quotations_qt_number_key;
ALTER TABLE IF EXISTS ONLY public.quotations DROP CONSTRAINT IF EXISTS quotations_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_quotations DROP CONSTRAINT IF EXISTS purchase_quotations_pq_number_key;
ALTER TABLE IF EXISTS ONLY public.purchase_quotations DROP CONSTRAINT IF EXISTS purchase_quotations_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_orders DROP CONSTRAINT IF EXISTS purchase_orders_po_number_key;
ALTER TABLE IF EXISTS ONLY public.purchase_orders DROP CONSTRAINT IF EXISTS purchase_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_pkey;
ALTER TABLE IF EXISTS ONLY public.proforma_invoices DROP CONSTRAINT IF EXISTS proforma_invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.proforma_invoices DROP CONSTRAINT IF EXISTS proforma_invoices_company_pi_number_unique;
ALTER TABLE IF EXISTS ONLY public.pos_sales DROP CONSTRAINT IF EXISTS pos_sales_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_module_action_unique;
ALTER TABLE IF EXISTS ONLY public.payroll_records DROP CONSTRAINT IF EXISTS payroll_records_pkey;
ALTER TABLE IF EXISTS ONLY public.ops_tasks DROP CONSTRAINT IF EXISTS ops_tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.ops_payroll_records DROP CONSTRAINT IF EXISTS ops_payroll_records_pkey;
ALTER TABLE IF EXISTS ONLY public.ops_licenses DROP CONSTRAINT IF EXISTS ops_licenses_pkey;
ALTER TABLE IF EXISTS ONLY public.ops_employees DROP CONSTRAINT IF EXISTS ops_employees_pkey;
ALTER TABLE IF EXISTS ONLY public.ops_employee_payroll DROP CONSTRAINT IF EXISTS ops_employee_payroll_pkey;
ALTER TABLE IF EXISTS ONLY public.ops_company_documents DROP CONSTRAINT IF EXISTS ops_company_documents_pkey;
ALTER TABLE IF EXISTS ONLY public.ops_assets DROP CONSTRAINT IF EXISTS ops_assets_pkey;
ALTER TABLE IF EXISTS ONLY public.ops_asset_assignments DROP CONSTRAINT IF EXISTS ops_asset_assignments_pkey;
ALTER TABLE IF EXISTS ONLY public.opening_stock DROP CONSTRAINT IF EXISTS opening_stock_warehouse_id_stock_item_id_key;
ALTER TABLE IF EXISTS ONLY public.opening_stock DROP CONSTRAINT IF EXISTS opening_stock_pkey;
ALTER TABLE IF EXISTS ONLY public.opening_balances DROP CONSTRAINT IF EXISTS opening_balances_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.maintenance_records DROP CONSTRAINT IF EXISTS maintenance_records_pkey;
ALTER TABLE IF EXISTS ONLY public.maintenance DROP CONSTRAINT IF EXISTS maintenance_pkey;
ALTER TABLE IF EXISTS ONLY public.login_credentials DROP CONSTRAINT IF EXISTS login_credentials_pkey;
ALTER TABLE IF EXISTS ONLY public.licenses DROP CONSTRAINT IF EXISTS licenses_pkey;
ALTER TABLE IF EXISTS ONLY public.journal_lines DROP CONSTRAINT IF EXISTS journal_lines_pkey;
ALTER TABLE IF EXISTS ONLY public.journal_entries DROP CONSTRAINT IF EXISTS journal_entries_pkey;
ALTER TABLE IF EXISTS ONLY public.ir8a_employers DROP CONSTRAINT IF EXISTS ir8a_employers_pkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_company_inv_number_unique;
ALTER TABLE IF EXISTS ONLY public.invoice_payments DROP CONSTRAINT IF EXISTS invoice_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory_opening_balances DROP CONSTRAINT IF EXISTS inventory_opening_balances_pkey;
ALTER TABLE IF EXISTS ONLY public.income_records DROP CONSTRAINT IF EXISTS income_records_pkey;
ALTER TABLE IF EXISTS ONLY public.income_attachments DROP CONSTRAINT IF EXISTS income_attachments_pkey;
ALTER TABLE IF EXISTS ONLY public.grn DROP CONSTRAINT IF EXISTS grn_pkey;
ALTER TABLE IF EXISTS ONLY public.grn DROP CONSTRAINT IF EXISTS grn_grn_number_key;
ALTER TABLE IF EXISTS ONLY public.goods_receipts DROP CONSTRAINT IF EXISTS goods_receipts_pkey;
ALTER TABLE IF EXISTS ONLY public.goods_receipt_items DROP CONSTRAINT IF EXISTS goods_receipt_items_pkey;
ALTER TABLE IF EXISTS ONLY public.goods_issues DROP CONSTRAINT IF EXISTS goods_issues_pkey;
ALTER TABLE IF EXISTS ONLY public.goods_issue_items DROP CONSTRAINT IF EXISTS goods_issue_items_pkey;
ALTER TABLE IF EXISTS ONLY public.fixed_asset_opening_balances DROP CONSTRAINT IF EXISTS fixed_asset_opening_balances_pkey;
ALTER TABLE IF EXISTS ONLY public.financial_years DROP CONSTRAINT IF EXISTS financial_years_pkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_pkey;
ALTER TABLE IF EXISTS ONLY public.employees DROP CONSTRAINT IF EXISTS employees_pkey;
ALTER TABLE IF EXISTS ONLY public.employee_payroll DROP CONSTRAINT IF EXISTS employee_payroll_pkey;
ALTER TABLE IF EXISTS ONLY public.employee_documents DROP CONSTRAINT IF EXISTS employee_documents_pkey;
ALTER TABLE IF EXISTS ONLY public.email_contacts DROP CONSTRAINT IF EXISTS email_contacts_pkey;
ALTER TABLE IF EXISTS ONLY public.dependents DROP CONSTRAINT IF EXISTS dependents_pkey;
ALTER TABLE IF EXISTS ONLY public.delivery_orders DROP CONSTRAINT IF EXISTS delivery_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.delivery_orders DROP CONSTRAINT IF EXISTS delivery_orders_do_number_key;
ALTER TABLE IF EXISTS ONLY public.debit_notes DROP CONSTRAINT IF EXISTS debit_notes_pkey;
ALTER TABLE IF EXISTS ONLY public.debit_notes DROP CONSTRAINT IF EXISTS debit_notes_company_dn_number_unique;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_pkey;
ALTER TABLE IF EXISTS ONLY public.customer_opening_balances DROP CONSTRAINT IF EXISTS customer_opening_balances_pkey;
ALTER TABLE IF EXISTS ONLY public.customer_deposits DROP CONSTRAINT IF EXISTS customer_deposits_pkey;
ALTER TABLE IF EXISTS ONLY public.credit_notes DROP CONSTRAINT IF EXISTS credit_notes_pkey;
ALTER TABLE IF EXISTS ONLY public.credit_notes DROP CONSTRAINT IF EXISTS credit_notes_company_cn_number_unique;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.companies DROP CONSTRAINT IF EXISTS companies_pkey;
ALTER TABLE IF EXISTS ONLY public.bank_opening_balances DROP CONSTRAINT IF EXISTS bank_opening_balances_pkey;
ALTER TABLE IF EXISTS ONLY public.backup_schedules DROP CONSTRAINT IF EXISTS backup_schedules_pkey;
ALTER TABLE IF EXISTS ONLY public.backup_retention_settings DROP CONSTRAINT IF EXISTS backup_retention_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.backup_retention_settings DROP CONSTRAINT IF EXISTS backup_retention_settings_company_id_key;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS assets_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_assignments DROP CONSTRAINT IF EXISTS asset_assignments_pkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_pkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_company_code_unique;
ALTER TABLE IF EXISTS ONLY public.accounting_restore_operations DROP CONSTRAINT IF EXISTS accounting_restore_operations_pkey;
ALTER TABLE IF EXISTS ONLY public.accounting_backups DROP CONSTRAINT IF EXISTS accounting_backups_pkey;
ALTER TABLE IF EXISTS public.wht_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.warehouses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.warehouse_stock ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.vouchers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.voucher_attachments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.vendors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.vendor_proforma_invoices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.vendor_payments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.vendor_opening_balances ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.vendor_invoices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_companies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tax_filings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stock_transfers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stock_transfer_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stock_serials ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stock_movements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stock_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stock_item_purchase_prices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stock_adjustments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.service_reports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sales_persons ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sales_orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.report_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.report_fields ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.report_definitions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.quotations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.purchase_quotations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.purchase_orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.projects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.proforma_invoices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.payroll_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ops_tasks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ops_payroll_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ops_licenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ops_employees ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ops_employee_payroll ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ops_company_documents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ops_assets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ops_asset_assignments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.opening_stock ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.opening_balances ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.maintenance_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.maintenance ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.licenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.journal_lines ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.journal_entries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ir8a_employers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.invoices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.invoice_payments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.inventory_opening_balances ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.income_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.income_attachments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.grn ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.goods_receipts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.goods_receipt_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.goods_issues ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.goods_issue_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fixed_asset_opening_balances ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.financial_years ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.expenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.employees ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.employee_payroll ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.employee_documents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.email_contacts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.dependents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.delivery_orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.debit_notes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.customers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.customer_opening_balances ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.customer_deposits ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.credit_notes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.conversations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.companies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.bank_opening_balances ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.backup_schedules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.backup_retention_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.assets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_assignments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.accounts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.accounting_restore_operations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.accounting_backups ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.wht_records_id_seq;
DROP TABLE IF EXISTS public.wht_records;
DROP SEQUENCE IF EXISTS public.warehouses_id_seq;
DROP TABLE IF EXISTS public.warehouses;
DROP SEQUENCE IF EXISTS public.warehouse_stock_id_seq;
DROP TABLE IF EXISTS public.warehouse_stock;
DROP SEQUENCE IF EXISTS public.vouchers_id_seq;
DROP TABLE IF EXISTS public.vouchers;
DROP SEQUENCE IF EXISTS public.voucher_attachments_id_seq;
DROP TABLE IF EXISTS public.voucher_attachments;
DROP SEQUENCE IF EXISTS public.vendors_id_seq;
DROP TABLE IF EXISTS public.vendors;
DROP SEQUENCE IF EXISTS public.vendor_proforma_invoices_id_seq;
DROP TABLE IF EXISTS public.vendor_proforma_invoices;
DROP SEQUENCE IF EXISTS public.vendor_payments_id_seq;
DROP TABLE IF EXISTS public.vendor_payments;
DROP SEQUENCE IF EXISTS public.vendor_opening_balances_id_seq;
DROP TABLE IF EXISTS public.vendor_opening_balances;
DROP SEQUENCE IF EXISTS public.vendor_invoices_id_seq;
DROP TABLE IF EXISTS public.vendor_invoices;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_companies_id_seq;
DROP TABLE IF EXISTS public.user_companies;
DROP SEQUENCE IF EXISTS public.tax_filings_id_seq;
DROP TABLE IF EXISTS public.tax_filings;
DROP SEQUENCE IF EXISTS public.stock_transfers_id_seq;
DROP TABLE IF EXISTS public.stock_transfers;
DROP SEQUENCE IF EXISTS public.stock_transfer_items_id_seq;
DROP TABLE IF EXISTS public.stock_transfer_items;
DROP SEQUENCE IF EXISTS public.stock_serials_id_seq;
DROP TABLE IF EXISTS public.stock_serials;
DROP SEQUENCE IF EXISTS public.stock_movements_id_seq;
DROP TABLE IF EXISTS public.stock_movements;
DROP SEQUENCE IF EXISTS public.stock_items_id_seq;
DROP TABLE IF EXISTS public.stock_items;
DROP SEQUENCE IF EXISTS public.stock_item_purchase_prices_id_seq;
DROP TABLE IF EXISTS public.stock_item_purchase_prices;
DROP SEQUENCE IF EXISTS public.stock_adjustments_id_seq;
DROP TABLE IF EXISTS public.stock_adjustments;
DROP SEQUENCE IF EXISTS public.settings_id_seq;
DROP TABLE IF EXISTS public.settings;
DROP TABLE IF EXISTS public.session;
DROP SEQUENCE IF EXISTS public.service_reports_id_seq;
DROP TABLE IF EXISTS public.service_reports;
DROP SEQUENCE IF EXISTS public.sales_persons_id_seq;
DROP TABLE IF EXISTS public.sales_persons;
DROP SEQUENCE IF EXISTS public.sales_orders_id_seq;
DROP TABLE IF EXISTS public.sales_orders;
DROP SEQUENCE IF EXISTS public.roles_id_seq;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.role_permissions;
DROP SEQUENCE IF EXISTS public.report_templates_id_seq;
DROP TABLE IF EXISTS public.report_templates;
DROP SEQUENCE IF EXISTS public.report_fields_id_seq;
DROP TABLE IF EXISTS public.report_fields;
DROP SEQUENCE IF EXISTS public.report_definitions_id_seq;
DROP TABLE IF EXISTS public.report_definitions;
DROP SEQUENCE IF EXISTS public.quotations_id_seq;
DROP TABLE IF EXISTS public.quotations;
DROP SEQUENCE IF EXISTS public.purchase_quotations_id_seq;
DROP TABLE IF EXISTS public.purchase_quotations;
DROP SEQUENCE IF EXISTS public.purchase_orders_id_seq;
DROP TABLE IF EXISTS public.purchase_orders;
DROP SEQUENCE IF EXISTS public.projects_id_seq;
DROP TABLE IF EXISTS public.projects;
DROP SEQUENCE IF EXISTS public.proforma_invoices_id_seq;
DROP TABLE IF EXISTS public.proforma_invoices;
DROP TABLE IF EXISTS public.pos_sales;
DROP SEQUENCE IF EXISTS public.permissions_id_seq;
DROP TABLE IF EXISTS public.permissions;
DROP SEQUENCE IF EXISTS public.payroll_records_id_seq;
DROP TABLE IF EXISTS public.payroll_records;
DROP SEQUENCE IF EXISTS public.ops_tasks_id_seq;
DROP TABLE IF EXISTS public.ops_tasks;
DROP SEQUENCE IF EXISTS public.ops_payroll_records_id_seq;
DROP TABLE IF EXISTS public.ops_payroll_records;
DROP SEQUENCE IF EXISTS public.ops_licenses_id_seq;
DROP TABLE IF EXISTS public.ops_licenses;
DROP SEQUENCE IF EXISTS public.ops_employees_id_seq;
DROP TABLE IF EXISTS public.ops_employees;
DROP SEQUENCE IF EXISTS public.ops_employee_payroll_id_seq;
DROP TABLE IF EXISTS public.ops_employee_payroll;
DROP SEQUENCE IF EXISTS public.ops_company_documents_id_seq;
DROP TABLE IF EXISTS public.ops_company_documents;
DROP SEQUENCE IF EXISTS public.ops_assets_id_seq;
DROP TABLE IF EXISTS public.ops_assets;
DROP SEQUENCE IF EXISTS public.ops_asset_assignments_id_seq;
DROP TABLE IF EXISTS public.ops_asset_assignments;
DROP SEQUENCE IF EXISTS public.opening_stock_id_seq;
DROP TABLE IF EXISTS public.opening_stock;
DROP SEQUENCE IF EXISTS public.opening_balances_id_seq;
DROP TABLE IF EXISTS public.opening_balances;
DROP SEQUENCE IF EXISTS public.messages_id_seq;
DROP TABLE IF EXISTS public.messages;
DROP SEQUENCE IF EXISTS public.maintenance_records_id_seq;
DROP TABLE IF EXISTS public.maintenance_records;
DROP SEQUENCE IF EXISTS public.maintenance_id_seq;
DROP TABLE IF EXISTS public.maintenance;
DROP TABLE IF EXISTS public.login_credentials;
DROP SEQUENCE IF EXISTS public.licenses_id_seq;
DROP TABLE IF EXISTS public.licenses;
DROP SEQUENCE IF EXISTS public.journal_lines_id_seq;
DROP TABLE IF EXISTS public.journal_lines;
DROP SEQUENCE IF EXISTS public.journal_entries_id_seq;
DROP TABLE IF EXISTS public.journal_entries;
DROP SEQUENCE IF EXISTS public.ir8a_employers_id_seq;
DROP TABLE IF EXISTS public.ir8a_employers;
DROP SEQUENCE IF EXISTS public.invoices_id_seq;
DROP TABLE IF EXISTS public.invoices;
DROP SEQUENCE IF EXISTS public.invoice_payments_id_seq;
DROP TABLE IF EXISTS public.invoice_payments;
DROP SEQUENCE IF EXISTS public.inventory_opening_balances_id_seq;
DROP TABLE IF EXISTS public.inventory_opening_balances;
DROP SEQUENCE IF EXISTS public.income_records_id_seq;
DROP TABLE IF EXISTS public.income_records;
DROP SEQUENCE IF EXISTS public.income_attachments_id_seq;
DROP TABLE IF EXISTS public.income_attachments;
DROP SEQUENCE IF EXISTS public.grn_id_seq;
DROP TABLE IF EXISTS public.grn;
DROP SEQUENCE IF EXISTS public.goods_receipts_id_seq;
DROP TABLE IF EXISTS public.goods_receipts;
DROP SEQUENCE IF EXISTS public.goods_receipt_items_id_seq;
DROP TABLE IF EXISTS public.goods_receipt_items;
DROP SEQUENCE IF EXISTS public.goods_issues_id_seq;
DROP TABLE IF EXISTS public.goods_issues;
DROP SEQUENCE IF EXISTS public.goods_issue_items_id_seq;
DROP TABLE IF EXISTS public.goods_issue_items;
DROP SEQUENCE IF EXISTS public.fixed_asset_opening_balances_id_seq;
DROP TABLE IF EXISTS public.fixed_asset_opening_balances;
DROP SEQUENCE IF EXISTS public.financial_years_id_seq;
DROP TABLE IF EXISTS public.financial_years;
DROP SEQUENCE IF EXISTS public.expenses_id_seq;
DROP TABLE IF EXISTS public.expenses;
DROP SEQUENCE IF EXISTS public.employees_id_seq;
DROP TABLE IF EXISTS public.employees;
DROP SEQUENCE IF EXISTS public.employee_payroll_id_seq;
DROP TABLE IF EXISTS public.employee_payroll;
DROP SEQUENCE IF EXISTS public.employee_documents_id_seq;
DROP TABLE IF EXISTS public.employee_documents;
DROP SEQUENCE IF EXISTS public.email_contacts_id_seq;
DROP TABLE IF EXISTS public.email_contacts;
DROP SEQUENCE IF EXISTS public.dependents_id_seq;
DROP TABLE IF EXISTS public.dependents;
DROP SEQUENCE IF EXISTS public.delivery_orders_id_seq;
DROP TABLE IF EXISTS public.delivery_orders;
DROP SEQUENCE IF EXISTS public.debit_notes_id_seq;
DROP TABLE IF EXISTS public.debit_notes;
DROP SEQUENCE IF EXISTS public.customers_id_seq;
DROP TABLE IF EXISTS public.customers;
DROP SEQUENCE IF EXISTS public.customer_opening_balances_id_seq;
DROP TABLE IF EXISTS public.customer_opening_balances;
DROP SEQUENCE IF EXISTS public.customer_deposits_id_seq;
DROP TABLE IF EXISTS public.customer_deposits;
DROP SEQUENCE IF EXISTS public.credit_notes_id_seq;
DROP TABLE IF EXISTS public.credit_notes;
DROP SEQUENCE IF EXISTS public.conversations_id_seq;
DROP TABLE IF EXISTS public.conversations;
DROP SEQUENCE IF EXISTS public.companies_id_seq;
DROP TABLE IF EXISTS public.companies;
DROP SEQUENCE IF EXISTS public.bank_opening_balances_id_seq;
DROP TABLE IF EXISTS public.bank_opening_balances;
DROP SEQUENCE IF EXISTS public.backup_schedules_id_seq;
DROP TABLE IF EXISTS public.backup_schedules;
DROP SEQUENCE IF EXISTS public.backup_retention_settings_id_seq;
DROP TABLE IF EXISTS public.backup_retention_settings;
DROP SEQUENCE IF EXISTS public.audit_logs_id_seq;
DROP TABLE IF EXISTS public.audit_logs;
DROP SEQUENCE IF EXISTS public.assets_id_seq;
DROP TABLE IF EXISTS public.assets;
DROP SEQUENCE IF EXISTS public.asset_assignments_id_seq;
DROP TABLE IF EXISTS public.asset_assignments;
DROP SEQUENCE IF EXISTS public.accounts_id_seq;
DROP TABLE IF EXISTS public.accounts;
DROP SEQUENCE IF EXISTS public.accounting_restore_operations_id_seq;
DROP TABLE IF EXISTS public.accounting_restore_operations;
DROP SEQUENCE IF EXISTS public.accounting_backups_id_seq;
DROP TABLE IF EXISTS public.accounting_backups;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounting_backups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounting_backups (
    id integer NOT NULL,
    company_id integer NOT NULL,
    backup_code text NOT NULL,
    backup_type text NOT NULL,
    from_date text,
    to_date text,
    financial_year_id integer,
    financial_year_label text,
    status text DEFAULT 'pending'::text NOT NULL,
    storage_path text,
    storage_ref text,
    file_size_bytes bigint,
    checksum_sha256 text,
    backup_source text DEFAULT 'manual'::text NOT NULL,
    schedule_id integer,
    error_message text,
    created_by integer,
    created_by_username text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    restored_at timestamp with time zone,
    restored_by integer
);


--
-- Name: accounting_backups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounting_backups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounting_backups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounting_backups_id_seq OWNED BY public.accounting_backups.id;


--
-- Name: accounting_restore_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounting_restore_operations (
    id integer NOT NULL,
    company_id integer NOT NULL,
    restore_code text NOT NULL,
    backup_id integer NOT NULL,
    backup_code text NOT NULL,
    restore_type text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    safety_backup_id integer,
    safety_backup_code text,
    steps_json text,
    result_message text,
    error_details text,
    started_by integer,
    started_by_username text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: accounting_restore_operations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounting_restore_operations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounting_restore_operations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounting_restore_operations_id_seq OWNED BY public.accounting_restore_operations.id;


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id integer NOT NULL,
    company_id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    sub_type text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: asset_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asset_assignments (
    id integer NOT NULL,
    company_id integer NOT NULL,
    asset_id integer NOT NULL,
    employee_id integer NOT NULL,
    date_assigned timestamp with time zone DEFAULT now() NOT NULL,
    date_returned timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: asset_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.asset_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asset_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.asset_assignments_id_seq OWNED BY public.asset_assignments.id;


--
-- Name: assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assets (
    id integer NOT NULL,
    company_id integer NOT NULL,
    tag text NOT NULL,
    type text NOT NULL,
    category text NOT NULL,
    serial text NOT NULL,
    model text,
    manufacturer text,
    status text DEFAULT 'available'::text NOT NULL,
    condition text,
    assigned_to text,
    location text,
    vendor text,
    vendor_id integer,
    invoice_number text,
    purchase_date timestamp with time zone,
    warranty_expiry timestamp with time zone,
    cost text,
    depreciation_start_date timestamp with time zone,
    useful_life_years integer,
    depreciation_method text,
    description text,
    has_license boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    useful_life_unit text,
    residual_value text,
    depreciation_frequency text,
    depreciation_book text,
    asset_image text
);


--
-- Name: assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assets_id_seq OWNED BY public.assets.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    company_id integer,
    user_id integer,
    username text,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text,
    entity_label text,
    details jsonb,
    ip_address text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: backup_retention_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_retention_settings (
    id integer NOT NULL,
    company_id integer NOT NULL,
    daily_keep_days integer DEFAULT 30 NOT NULL,
    weekly_keep_weeks integer DEFAULT 12 NOT NULL,
    monthly_keep_months integer DEFAULT 12 NOT NULL,
    financial_year_keep_forever boolean DEFAULT true NOT NULL,
    updated_by integer,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: backup_retention_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.backup_retention_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backup_retention_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.backup_retention_settings_id_seq OWNED BY public.backup_retention_settings.id;


--
-- Name: backup_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_schedules (
    id integer NOT NULL,
    company_id integer NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    frequency text NOT NULL,
    time_of_day text DEFAULT '23:00'::text NOT NULL,
    day_of_week integer,
    backup_type text DEFAULT 'accounting'::text NOT NULL,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: backup_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.backup_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backup_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.backup_schedules_id_seq OWNED BY public.backup_schedules.id;


--
-- Name: bank_opening_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_opening_balances (
    id integer NOT NULL,
    company_id integer NOT NULL,
    financial_year_id integer NOT NULL,
    account_id integer,
    account_code text NOT NULL,
    account_name text NOT NULL,
    amount numeric(15,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: bank_opening_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bank_opening_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bank_opening_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bank_opening_balances_id_seq OWNED BY public.bank_opening_balances.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name text NOT NULL,
    country text NOT NULL,
    address text,
    registration_no text,
    email text,
    phone text,
    logo_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    domain text,
    gst_reg_no text,
    slug text,
    database_name text,
    business_type text
);


--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id integer NOT NULL,
    title text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: credit_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_notes (
    id integer NOT NULL,
    cn_number text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    customer_name text NOT NULL,
    customer_address text,
    contact_person text,
    contact_email text,
    ref_inv_number text,
    reason text,
    issue_date text,
    currency text DEFAULT 'SGD'::text NOT NULL,
    payment_terms text,
    notes text,
    is_private boolean DEFAULT false NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    subtotal numeric(15,2) DEFAULT 0 NOT NULL,
    discount_amount numeric(15,2) DEFAULT 0 NOT NULL,
    tax_rate numeric(5,2) DEFAULT 9 NOT NULL,
    tax numeric(15,2) DEFAULT 0 NOT NULL,
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    void_reason text,
    email_sent_to text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    so_id integer,
    so_number text,
    terms_and_conditions text,
    delivery_instructions text,
    customer_note text,
    authorised_signature text
);


--
-- Name: credit_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_notes_id_seq OWNED BY public.credit_notes.id;


--
-- Name: customer_deposits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_deposits (
    id integer NOT NULL,
    company_id integer NOT NULL,
    customer_name text NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    total_amount numeric(15,2) NOT NULL,
    applied_amount numeric(15,2) DEFAULT 0 NOT NULL,
    status text DEFAULT 'available'::text NOT NULL,
    payment_date text NOT NULL,
    payment_method text DEFAULT 'bank_transfer'::text,
    bank_ref text,
    notes text,
    journal_entry_id integer,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_deposits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_deposits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_deposits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_deposits_id_seq OWNED BY public.customer_deposits.id;


--
-- Name: customer_opening_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_opening_balances (
    id integer NOT NULL,
    company_id integer NOT NULL,
    financial_year_id integer NOT NULL,
    customer_id integer,
    customer_name text NOT NULL,
    amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_opening_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_opening_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_opening_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_opening_balances_id_seq OWNED BY public.customer_opening_balances.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    company_id integer NOT NULL,
    name text NOT NULL,
    address text,
    postal_code text,
    country text,
    contact_person text,
    contact_email text,
    phone text,
    currency text,
    gst_registered boolean DEFAULT false NOT NULL,
    gst_no text,
    ship_to_address text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    quotation_terms text,
    credit_limit_enabled boolean DEFAULT false NOT NULL,
    credit_limit numeric(15,2)
);


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: debit_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.debit_notes (
    id integer NOT NULL,
    dn_number text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    customer_name text NOT NULL,
    customer_address text,
    contact_person text,
    contact_email text,
    ref_inv_number text,
    reason text,
    issue_date text,
    currency text DEFAULT 'SGD'::text NOT NULL,
    payment_terms text,
    notes text,
    is_private boolean DEFAULT false NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    subtotal numeric(15,2) DEFAULT 0 NOT NULL,
    discount_amount numeric(15,2) DEFAULT 0 NOT NULL,
    tax_rate numeric(5,2) DEFAULT 9 NOT NULL,
    tax numeric(15,2) DEFAULT 0 NOT NULL,
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    void_reason text,
    email_sent_to text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    so_id integer,
    so_number text,
    terms_and_conditions text,
    delivery_instructions text,
    customer_note text,
    authorised_signature text,
    attachment_path text,
    attachment_name text
);


--
-- Name: debit_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.debit_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: debit_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.debit_notes_id_seq OWNED BY public.debit_notes.id;


--
-- Name: delivery_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_orders (
    id integer NOT NULL,
    do_number text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    customer_name text NOT NULL,
    customer_address text,
    customer_contact text,
    issue_date text,
    delivery_date text,
    payment_terms text,
    notes text,
    is_private boolean DEFAULT false NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    email_sent_to text,
    inv_id integer,
    inv_number text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    so_id integer,
    so_number text,
    terms_and_conditions text,
    delivery_instructions text,
    customer_note text,
    authorised_signature text
);


--
-- Name: delivery_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.delivery_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delivery_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.delivery_orders_id_seq OWNED BY public.delivery_orders.id;


--
-- Name: dependents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dependents (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employee_id integer NOT NULL,
    name text NOT NULL,
    relationship text NOT NULL,
    passport_number text,
    passport_expiry timestamp with time zone,
    visa_number text,
    visa_expiry timestamp with time zone,
    visa_type text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: dependents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dependents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dependents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dependents_id_seq OWNED BY public.dependents.id;


--
-- Name: email_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_contacts (
    id integer NOT NULL,
    company_id integer NOT NULL,
    name text,
    email text NOT NULL,
    use_count integer DEFAULT 1 NOT NULL,
    last_used_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: email_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_contacts_id_seq OWNED BY public.email_contacts.id;


--
-- Name: employee_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_documents (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employee_id integer NOT NULL,
    document_type text NOT NULL,
    file_path text NOT NULL,
    issue_date timestamp with time zone,
    expiry_date timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: employee_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_documents_id_seq OWNED BY public.employee_documents.id;


--
-- Name: employee_payroll; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_payroll (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employee_id integer NOT NULL,
    base_salary numeric(10,2) NOT NULL,
    payroll_period text DEFAULT 'monthly'::text NOT NULL,
    cpf_employee_rate numeric(5,2),
    cpf_employer_rate numeric(5,2),
    allowances jsonb DEFAULT '[]'::jsonb,
    deductions jsonb DEFAULT '[]'::jsonb,
    bank_name text,
    bank_account text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    hourly_rate numeric(8,2),
    overtime_rate numeric(8,2),
    no_of_working_days integer,
    tax_rate numeric(5,2) DEFAULT 0,
    cpf_rate numeric(5,2),
    cpf_amount numeric(12,2),
    employer_cpf_rate numeric(5,2),
    employer_cpf_amount numeric(12,2),
    net_salary numeric(12,2),
    effective_from date,
    effective_to date
);


--
-- Name: employee_payroll_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_payroll_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_payroll_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_payroll_id_seq OWNED BY public.employee_payroll.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employee_id text NOT NULL,
    user_id integer,
    name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    address text NOT NULL,
    department text NOT NULL,
    designation text NOT NULL,
    join_date timestamp with time zone NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    salary text,
    annual_salary text,
    nationality text,
    pr_status text,
    date_of_birth timestamp with time zone,
    passport_number text,
    passport_expiry timestamp with time zone,
    visa_number text,
    visa_expiry timestamp with time zone,
    visa_type text,
    visa_remarks text,
    nric_number text,
    nric_expiry timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    passport_scan text,
    visa_scan text,
    nric_scan text,
    gender text
);


--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    company_id integer NOT NULL,
    expense_date text NOT NULL,
    vendor_name text NOT NULL,
    description text NOT NULL,
    category text NOT NULL,
    amount numeric(15,2) NOT NULL,
    gst_amount numeric(15,2) DEFAULT 0 NOT NULL,
    gst_claimable boolean DEFAULT false NOT NULL,
    is_deductible boolean DEFAULT true NOT NULL,
    deductible_pct integer DEFAULT 100 NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    payment_method text DEFAULT 'bank_transfer'::text,
    receipt_data text,
    receipt_mime_type text,
    vendor_id integer,
    project_id integer,
    voucher_id integer,
    journal_entry_id integer,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    account_id integer
);


--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: financial_years; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_years (
    id integer NOT NULL,
    company_id integer NOT NULL,
    label text NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    status text DEFAULT 'inactive'::text NOT NULL,
    audit_status text DEFAULT 'pending'::text NOT NULL,
    closed_at timestamp with time zone,
    closed_by integer,
    closed_by_username text,
    activated_at timestamp with time zone,
    activated_by integer,
    activated_by_username text,
    reopened_at timestamp with time zone,
    reopened_by integer,
    opening_balances_generated boolean DEFAULT false NOT NULL,
    opening_journal_entry_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: financial_years_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.financial_years_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: financial_years_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.financial_years_id_seq OWNED BY public.financial_years.id;


--
-- Name: fixed_asset_opening_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fixed_asset_opening_balances (
    id integer NOT NULL,
    company_id integer NOT NULL,
    financial_year_id integer NOT NULL,
    account_code text,
    description text NOT NULL,
    amount numeric(15,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: fixed_asset_opening_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fixed_asset_opening_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fixed_asset_opening_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fixed_asset_opening_balances_id_seq OWNED BY public.fixed_asset_opening_balances.id;


--
-- Name: goods_issue_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.goods_issue_items (
    id integer NOT NULL,
    goods_issue_id integer NOT NULL,
    stock_item_id integer NOT NULL,
    quantity numeric(15,3) NOT NULL
);


--
-- Name: goods_issue_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.goods_issue_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: goods_issue_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.goods_issue_items_id_seq OWNED BY public.goods_issue_items.id;


--
-- Name: goods_issues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.goods_issues (
    id integer NOT NULL,
    company_id integer NOT NULL,
    gin_number text NOT NULL,
    warehouse_id integer NOT NULL,
    reason text,
    issue_date date NOT NULL,
    remarks text,
    status text DEFAULT 'posted'::text NOT NULL,
    created_by integer,
    updated_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: goods_issues_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.goods_issues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: goods_issues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.goods_issues_id_seq OWNED BY public.goods_issues.id;


--
-- Name: goods_receipt_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.goods_receipt_items (
    id integer NOT NULL,
    goods_receipt_id integer NOT NULL,
    stock_item_id integer NOT NULL,
    quantity numeric(15,3) NOT NULL,
    unit_cost numeric(15,2) DEFAULT 0
);


--
-- Name: goods_receipt_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.goods_receipt_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: goods_receipt_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.goods_receipt_items_id_seq OWNED BY public.goods_receipt_items.id;


--
-- Name: goods_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.goods_receipts (
    id integer NOT NULL,
    company_id integer NOT NULL,
    grn_number text NOT NULL,
    warehouse_id integer NOT NULL,
    supplier text,
    reference_number text,
    receipt_date date NOT NULL,
    remarks text,
    status text DEFAULT 'posted'::text NOT NULL,
    created_by integer,
    updated_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: goods_receipts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.goods_receipts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: goods_receipts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.goods_receipts_id_seq OWNED BY public.goods_receipts.id;


--
-- Name: grn; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grn (
    id integer NOT NULL,
    grn_number text NOT NULL,
    po_id integer,
    po_number text NOT NULL,
    vendor_name text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: grn_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grn_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grn_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grn_id_seq OWNED BY public.grn.id;


--
-- Name: income_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.income_attachments (
    id integer NOT NULL,
    income_id integer NOT NULL,
    file_name text DEFAULT 'attachment'::text NOT NULL,
    mime_type text DEFAULT 'application/octet-stream'::text NOT NULL,
    file_data text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: income_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.income_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: income_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.income_attachments_id_seq OWNED BY public.income_attachments.id;


--
-- Name: income_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.income_records (
    id integer NOT NULL,
    company_id integer NOT NULL,
    income_date text NOT NULL,
    payer_name text NOT NULL,
    description text NOT NULL,
    category text NOT NULL,
    amount numeric(15,2) NOT NULL,
    gst_amount numeric(15,2) DEFAULT 0 NOT NULL,
    gst_treatment text DEFAULT 'standard_rated'::text NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    exchange_rate numeric(10,6) DEFAULT 1.000000 NOT NULL,
    payment_method text DEFAULT 'bank_transfer'::text,
    account_id integer,
    reference text,
    notes text,
    status text DEFAULT 'draft'::text NOT NULL,
    journal_entry_id integer,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    gst_claimable boolean DEFAULT false NOT NULL,
    is_deductible boolean DEFAULT true NOT NULL,
    deductible_pct integer DEFAULT 100 NOT NULL
);


--
-- Name: income_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.income_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: income_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.income_records_id_seq OWNED BY public.income_records.id;


--
-- Name: inventory_opening_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_opening_balances (
    id integer NOT NULL,
    company_id integer NOT NULL,
    financial_year_id integer NOT NULL,
    stock_item_id integer,
    item_code text,
    item_name text NOT NULL,
    warehouse_id integer,
    warehouse_name text,
    quantity numeric(15,4) DEFAULT 0 NOT NULL,
    value numeric(15,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_opening_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_opening_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_opening_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_opening_balances_id_seq OWNED BY public.inventory_opening_balances.id;


--
-- Name: invoice_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_payments (
    id integer NOT NULL,
    company_id integer NOT NULL,
    invoice_id integer NOT NULL,
    payment_date text NOT NULL,
    amount numeric(15,2) NOT NULL,
    reference text,
    payment_method text DEFAULT 'bank_transfer'::text,
    notes text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: invoice_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_payments_id_seq OWNED BY public.invoice_payments.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    inv_number text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    customer_name text NOT NULL,
    customer_address text,
    customer_contact text,
    customer_contact_email text,
    delivery_address text,
    issue_date text,
    delivery_date text,
    payment_terms text,
    notes text,
    is_private boolean DEFAULT false NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    subtotal numeric(15,2) DEFAULT 0 NOT NULL,
    discount_amount numeric(15,2) DEFAULT 0 NOT NULL,
    tax numeric(15,2) DEFAULT 0 NOT NULL,
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    po_ref_no text,
    status text DEFAULT 'draft'::text NOT NULL,
    email_sent_to text,
    void_reason text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    exchange_rate numeric(10,6) DEFAULT 1.000000 NOT NULL,
    so_id integer,
    so_number text,
    sales_person text,
    terms_and_conditions text,
    delivery_instructions text,
    customer_note text,
    authorised_signature text,
    is_modified boolean DEFAULT false NOT NULL
);


--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: ir8a_employers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ir8a_employers (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employer_name text NOT NULL,
    uen text NOT NULL,
    address text NOT NULL,
    signatory_name text NOT NULL,
    designation text NOT NULL,
    declaration_date date,
    signature text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: ir8a_employers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ir8a_employers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ir8a_employers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ir8a_employers_id_seq OWNED BY public.ir8a_employers.id;


--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entries (
    id integer NOT NULL,
    company_id integer NOT NULL,
    entry_date text NOT NULL,
    description text NOT NULL,
    ref_type text,
    ref_id integer,
    ref_number text,
    status text DEFAULT 'posted'::text NOT NULL,
    reversal_of_id integer,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: journal_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journal_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journal_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journal_entries_id_seq OWNED BY public.journal_entries.id;


--
-- Name: journal_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_lines (
    id integer NOT NULL,
    journal_entry_id integer NOT NULL,
    account_id integer NOT NULL,
    description text,
    debit numeric(15,2) DEFAULT 0 NOT NULL,
    credit numeric(15,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: journal_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journal_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journal_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journal_lines_id_seq OWNED BY public.journal_lines.id;


--
-- Name: licenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.licenses (
    id integer NOT NULL,
    company_id integer NOT NULL,
    asset_id integer,
    name text NOT NULL,
    license_key text NOT NULL,
    type text NOT NULL,
    seats integer DEFAULT 1,
    vendor_id integer,
    purchase_date timestamp with time zone,
    expiry_date timestamp with time zone,
    cost text,
    renewal_cycle text DEFAULT 'none'::text,
    status text DEFAULT 'active'::text,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: licenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.licenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: licenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.licenses_id_seq OWNED BY public.licenses.id;


--
-- Name: login_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_credentials (
    user_id integer NOT NULL,
    password_hash text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: maintenance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance (
    id integer NOT NULL,
    is_enabled boolean DEFAULT false NOT NULL,
    scheduled_start text,
    scheduled_end text,
    message text,
    contact_email text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by_user text
);


--
-- Name: maintenance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.maintenance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: maintenance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.maintenance_id_seq OWNED BY public.maintenance.id;


--
-- Name: maintenance_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_records (
    id integer NOT NULL,
    company_id integer NOT NULL,
    asset_id integer NOT NULL,
    issue_description text NOT NULL,
    resolution text,
    service_date timestamp with time zone NOT NULL,
    next_maintenance_date timestamp with time zone,
    cost text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: maintenance_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.maintenance_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: maintenance_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.maintenance_records_id_seq OWNED BY public.maintenance_records.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: opening_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.opening_balances (
    id integer NOT NULL,
    company_id integer NOT NULL,
    financial_year_id integer NOT NULL,
    account_id integer,
    account_code text NOT NULL,
    account_name text NOT NULL,
    account_type text,
    debit numeric(15,2) DEFAULT 0 NOT NULL,
    credit numeric(15,2) DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: opening_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.opening_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: opening_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.opening_balances_id_seq OWNED BY public.opening_balances.id;


--
-- Name: opening_stock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.opening_stock (
    id integer NOT NULL,
    company_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    stock_item_id integer NOT NULL,
    quantity numeric(15,3) NOT NULL,
    unit_cost numeric(15,2) DEFAULT 0,
    entry_date date NOT NULL,
    remarks text,
    created_by integer,
    updated_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: opening_stock_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.opening_stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: opening_stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.opening_stock_id_seq OWNED BY public.opening_stock.id;


--
-- Name: ops_asset_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ops_asset_assignments (
    id integer NOT NULL,
    company_id integer NOT NULL,
    asset_id integer NOT NULL,
    employee_id integer NOT NULL,
    date_assigned text,
    date_returned text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ops_asset_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ops_asset_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ops_asset_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ops_asset_assignments_id_seq OWNED BY public.ops_asset_assignments.id;


--
-- Name: ops_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ops_assets (
    id integer NOT NULL,
    company_id integer NOT NULL,
    tag text NOT NULL,
    type text NOT NULL,
    category text DEFAULT 'hardware'::text NOT NULL,
    serial text,
    model text,
    manufacturer text,
    status text DEFAULT 'available'::text NOT NULL,
    condition text,
    assigned_to text,
    location text,
    vendor text,
    purchase_date text,
    warranty_expiry text,
    cost text,
    description text,
    has_license boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ops_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ops_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ops_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ops_assets_id_seq OWNED BY public.ops_assets.id;


--
-- Name: ops_company_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ops_company_documents (
    id integer NOT NULL,
    company_id integer NOT NULL,
    document_type text DEFAULT 'other'::text NOT NULL,
    title text NOT NULL,
    file_path text,
    issue_date text,
    expiry_date text,
    notes text,
    uploaded_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ops_company_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ops_company_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ops_company_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ops_company_documents_id_seq OWNED BY public.ops_company_documents.id;


--
-- Name: ops_employee_payroll; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ops_employee_payroll (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employee_id integer NOT NULL,
    base_salary numeric(15,2) DEFAULT 0 NOT NULL,
    allowances jsonb DEFAULT '{}'::jsonb,
    deductions jsonb DEFAULT '{}'::jsonb,
    currency text DEFAULT 'SGD'::text NOT NULL,
    pay_frequency text DEFAULT 'monthly'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ops_employee_payroll_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ops_employee_payroll_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ops_employee_payroll_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ops_employee_payroll_id_seq OWNED BY public.ops_employee_payroll.id;


--
-- Name: ops_employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ops_employees (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employee_code text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    address text,
    department text,
    designation text,
    join_date text,
    status text DEFAULT 'active'::text NOT NULL,
    salary text,
    nationality text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ops_employees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ops_employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ops_employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ops_employees_id_seq OWNED BY public.ops_employees.id;


--
-- Name: ops_licenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ops_licenses (
    id integer NOT NULL,
    company_id integer NOT NULL,
    asset_id integer,
    name text NOT NULL,
    license_key text NOT NULL,
    type text DEFAULT 'perpetual'::text NOT NULL,
    seats integer DEFAULT 1,
    purchase_date text,
    expiry_date text,
    cost text,
    renewal_cycle text DEFAULT 'none'::text,
    status text DEFAULT 'active'::text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ops_licenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ops_licenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ops_licenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ops_licenses_id_seq OWNED BY public.ops_licenses.id;


--
-- Name: ops_payroll_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ops_payroll_records (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employee_id integer NOT NULL,
    payroll_config_id integer,
    period_start text NOT NULL,
    period_end text NOT NULL,
    gross_pay numeric(15,2) DEFAULT 0 NOT NULL,
    net_pay numeric(15,2) DEFAULT 0 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ops_payroll_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ops_payroll_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ops_payroll_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ops_payroll_records_id_seq OWNED BY public.ops_payroll_records.id;


--
-- Name: ops_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ops_tasks (
    id integer NOT NULL,
    company_id integer NOT NULL,
    title text NOT NULL,
    description text,
    status text DEFAULT 'todo'::text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    assignee_id integer,
    start_date text,
    due_date text,
    event_type text DEFAULT 'task'::text,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ops_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ops_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ops_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ops_tasks_id_seq OWNED BY public.ops_tasks.id;


--
-- Name: payroll_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_records (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employee_id integer NOT NULL,
    payroll_config_id integer,
    pay_period_start timestamp with time zone NOT NULL,
    pay_period_end timestamp with time zone NOT NULL,
    gross_pay numeric(12,2) NOT NULL,
    net_pay numeric(12,2) NOT NULL,
    cpf_employee numeric(12,2) DEFAULT 0,
    cpf_employer numeric(12,2) DEFAULT 0,
    status text DEFAULT 'draft'::text NOT NULL,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    base_salary numeric(10,2),
    overtime_hours numeric(6,2) DEFAULT 0,
    overtime_pay numeric(10,2) DEFAULT 0,
    allowances jsonb DEFAULT '{}'::jsonb,
    deductions jsonb DEFAULT '{}'::jsonb,
    notes text,
    updated_at timestamp with time zone DEFAULT now(),
    payroll_month integer,
    payroll_year integer
);


--
-- Name: payroll_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_records_id_seq OWNED BY public.payroll_records.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    module text NOT NULL,
    action text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: pos_sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_sales (
    id text NOT NULL,
    company_id integer NOT NULL,
    channel text DEFAULT 'retail'::text NOT NULL,
    pos_number text NOT NULL,
    sales_person_id integer,
    sales_person_name text,
    created_by integer,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: proforma_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proforma_invoices (
    id integer NOT NULL,
    pi_number text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    customer_name text NOT NULL,
    customer_address text,
    customer_contact text,
    customer_contact_email text,
    delivery_address text,
    issue_date text,
    delivery_date text,
    payment_terms text,
    notes text,
    is_private boolean DEFAULT false NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    subtotal numeric(15,2) DEFAULT 0 NOT NULL,
    discount_amount numeric(15,2) DEFAULT 0 NOT NULL,
    tax numeric(15,2) DEFAULT 0 NOT NULL,
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    qt_ref_no text,
    status text DEFAULT 'draft'::text NOT NULL,
    email_sent_to text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    terms_and_conditions text,
    delivery_instructions text,
    customer_note text,
    authorised_signature text
);


--
-- Name: proforma_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.proforma_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: proforma_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.proforma_invoices_id_seq OWNED BY public.proforma_invoices.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    company_id integer NOT NULL,
    name text NOT NULL,
    code text,
    description text,
    status text DEFAULT 'active'::text NOT NULL,
    budget numeric(15,2),
    start_date text,
    end_date text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id integer NOT NULL,
    po_number text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    vendor_name text NOT NULL,
    vendor_address text,
    vendor_contact text,
    vendor_contact_email text,
    delivery_address text,
    issue_date text,
    delivery_date text,
    payment_terms text,
    quote_ref_no text,
    notes text,
    is_private boolean DEFAULT false NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    subtotal numeric(15,2) DEFAULT 0 NOT NULL,
    tax numeric(15,2) DEFAULT 0 NOT NULL,
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    customer_id integer,
    customer_po_ref text,
    email_sent_to text,
    ack_token text,
    ack_at text,
    ack_note text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    attachment_path text,
    attachment_name text
);


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_orders_id_seq OWNED BY public.purchase_orders.id;


--
-- Name: purchase_quotations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_quotations (
    id integer NOT NULL,
    pq_number text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    vendor_name text NOT NULL,
    vendor_address text,
    vendor_contact text,
    vendor_contact_email text,
    delivery_address text,
    issue_date text,
    delivery_date text,
    payment_terms text,
    notes text,
    is_private boolean DEFAULT false NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    subtotal numeric(15,2) DEFAULT 0 NOT NULL,
    discount_amount numeric(15,2) DEFAULT 0 NOT NULL,
    tax numeric(15,2) DEFAULT 0 NOT NULL,
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    email_sent_to text,
    converted_po_id integer,
    converted_po_number text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: purchase_quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_quotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_quotations_id_seq OWNED BY public.purchase_quotations.id;


--
-- Name: quotations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotations (
    id integer NOT NULL,
    qt_number text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    customer_name text NOT NULL,
    customer_address text,
    customer_contact text,
    customer_contact_email text,
    delivery_address text,
    issue_date text,
    delivery_date text,
    payment_terms text,
    notes text,
    is_private boolean DEFAULT false NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    subtotal numeric(15,2) DEFAULT 0 NOT NULL,
    discount_amount numeric(15,2) DEFAULT 0 NOT NULL,
    tax numeric(15,2) DEFAULT 0 NOT NULL,
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    email_sent_to text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    terms_and_conditions text,
    delivery_instructions text,
    customer_note text,
    authorised_signature text,
    valid_until text,
    sales_person text
);


--
-- Name: quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotations_id_seq OWNED BY public.quotations.id;


--
-- Name: report_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_definitions (
    id integer NOT NULL,
    module text NOT NULL,
    report_type text NOT NULL,
    name text NOT NULL,
    description text,
    is_system boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: report_definitions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.report_definitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: report_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.report_definitions_id_seq OWNED BY public.report_definitions.id;


--
-- Name: report_fields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_fields (
    id integer NOT NULL,
    report_definition_id integer NOT NULL,
    field_key text NOT NULL,
    field_label text NOT NULL,
    field_group text NOT NULL,
    data_type text DEFAULT 'string'::text NOT NULL,
    is_repeatable boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: report_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.report_fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: report_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.report_fields_id_seq OWNED BY public.report_fields.id;


--
-- Name: report_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_templates (
    id integer NOT NULL,
    company_id integer,
    report_definition_id integer NOT NULL,
    name text NOT NULL,
    description text,
    template_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_system_template boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    created_by integer,
    updated_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: report_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.report_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: report_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.report_templates_id_seq OWNED BY public.report_templates.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    role_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name text NOT NULL,
    company_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sales_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_orders (
    id integer NOT NULL,
    so_number text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    qt_id integer,
    qt_number text,
    customer_name text NOT NULL,
    customer_address text,
    customer_contact text,
    customer_contact_email text,
    delivery_address text,
    issue_date text,
    delivery_date text,
    payment_terms text,
    notes text,
    is_private boolean DEFAULT false NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    subtotal numeric(15,2) DEFAULT 0 NOT NULL,
    discount_amount numeric(15,2) DEFAULT 0 NOT NULL,
    tax numeric(15,2) DEFAULT 0 NOT NULL,
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    email_sent_to text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    inv_id integer,
    inv_number text,
    do_id integer,
    do_number text,
    terms_and_conditions text,
    delivery_instructions text,
    customer_note text,
    authorised_signature text,
    attachment_path text,
    attachment_name text
);


--
-- Name: sales_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_orders_id_seq OWNED BY public.sales_orders.id;


--
-- Name: sales_persons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_persons (
    id integer NOT NULL,
    company_id integer NOT NULL,
    name text NOT NULL,
    employment_code text NOT NULL,
    password_hash text DEFAULT ''::text NOT NULL,
    department text DEFAULT ''::text NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    country text DEFAULT 'Singapore'::text NOT NULL,
    address text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sales_persons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_persons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_persons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_persons_id_seq OWNED BY public.sales_persons.id;


--
-- Name: service_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_reports (
    id integer NOT NULL,
    company_id integer NOT NULL,
    csr_number text NOT NULL,
    customer_id integer,
    customer_name text NOT NULL,
    customer_address text,
    customer_contact_person text,
    customer_phone text,
    customer_email text,
    support_requested_by text NOT NULL,
    support_request_date timestamp with time zone NOT NULL,
    problem_description text NOT NULL,
    engineer_id integer,
    service_date timestamp with time zone NOT NULL,
    service_time text NOT NULL,
    hours_charged numeric(4,2) NOT NULL,
    service_details text NOT NULL,
    remarks text,
    priority_level text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_by integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: service_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_reports_id_seq OWNED BY public.service_reports.id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    company_id integer,
    gst_rate numeric(5,2) DEFAULT 9 NOT NULL,
    smtp_host text,
    smtp_port text,
    smtp_user text,
    smtp_pass text,
    smtp_from text,
    po_prefix text DEFAULT 'PO'::text,
    po_counter integer DEFAULT 1 NOT NULL,
    po_suffix text DEFAULT ''::text,
    inv_prefix text DEFAULT 'INV'::text,
    inv_counter integer DEFAULT 1 NOT NULL,
    inv_suffix text DEFAULT ''::text,
    qt_prefix text DEFAULT 'QT'::text,
    qt_counter integer DEFAULT 1 NOT NULL,
    qt_suffix text DEFAULT ''::text,
    do_prefix text DEFAULT 'DO'::text,
    do_counter integer DEFAULT 1 NOT NULL,
    do_suffix text DEFAULT ''::text,
    grn_prefix text DEFAULT 'GRN'::text,
    grn_counter integer DEFAULT 1 NOT NULL,
    grn_suffix text DEFAULT ''::text,
    cn_prefix text DEFAULT 'CN'::text,
    cn_counter integer DEFAULT 1 NOT NULL,
    cn_suffix text DEFAULT ''::text,
    pi_prefix text DEFAULT 'PI'::text,
    pi_counter integer DEFAULT 1 NOT NULL,
    pi_suffix text DEFAULT ''::text,
    pv_prefix text DEFAULT 'PV'::text,
    pv_counter integer DEFAULT 1 NOT NULL,
    pv_suffix text DEFAULT ''::text,
    allow_negative_stock boolean DEFAULT false NOT NULL,
    auto_deduct_on_do boolean DEFAULT false NOT NULL,
    low_stock_warning numeric(15,3) DEFAULT 0,
    default_uom text DEFAULT 'pcs'::text,
    bank_details text,
    terms_and_conditions text,
    quotation_terms text,
    default_verifier_id integer,
    default_approver_id integer,
    default_paid_by_id integer,
    igr_prefix text DEFAULT 'IGR'::text,
    igr_counter integer DEFAULT 1,
    igr_suffix text DEFAULT ''::text,
    gin_prefix text DEFAULT 'GIN'::text,
    gin_counter integer DEFAULT 1,
    gin_suffix text DEFAULT ''::text,
    st_prefix text DEFAULT 'ST'::text,
    st_counter integer DEFAULT 1,
    st_suffix text DEFAULT ''::text,
    sa_prefix text DEFAULT 'SA'::text,
    sa_counter integer DEFAULT 1,
    sa_suffix text DEFAULT ''::text,
    si_prefix text DEFAULT 'STK'::text,
    si_counter integer DEFAULT 1,
    si_suffix text DEFAULT ''::text,
    dn_prefix text DEFAULT 'DN'::text NOT NULL,
    dn_counter integer DEFAULT 1 NOT NULL,
    dn_suffix text DEFAULT ''::text NOT NULL,
    so_prefix text DEFAULT 'SO'::text,
    so_counter integer DEFAULT 0 NOT NULL,
    so_suffix text DEFAULT ''::text,
    pq_prefix text DEFAULT 'PQ'::text,
    pq_counter integer DEFAULT 0 NOT NULL,
    pq_suffix text DEFAULT ''::text,
    fa_prefix text DEFAULT 'FA'::text,
    fa_counter integer DEFAULT 0 NOT NULL,
    fa_suffix text DEFAULT ''::text,
    bc_prefix text DEFAULT 'BC'::text,
    bc_counter integer DEFAULT 0,
    bc_suffix text DEFAULT ''::text,
    vpi_prefix text DEFAULT 'VPI'::text,
    vpi_counter integer DEFAULT 0 NOT NULL,
    vpi_suffix text DEFAULT ''::text
);


--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: stock_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_adjustments (
    id integer NOT NULL,
    company_id integer NOT NULL,
    adjustment_number text NOT NULL,
    warehouse_id integer NOT NULL,
    stock_item_id integer NOT NULL,
    adjustment_type text NOT NULL,
    reason text,
    current_quantity numeric(15,3) NOT NULL,
    actual_quantity numeric(15,3) NOT NULL,
    difference numeric(15,3) NOT NULL,
    remarks text,
    adjustment_date date NOT NULL,
    created_by integer,
    updated_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_adjustments_id_seq OWNED BY public.stock_adjustments.id;


--
-- Name: stock_item_purchase_prices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_item_purchase_prices (
    id integer NOT NULL,
    company_id integer NOT NULL,
    stock_item_id integer NOT NULL,
    purchase_price numeric(15,2) DEFAULT 0 NOT NULL,
    quantity numeric(15,3) DEFAULT 0 NOT NULL,
    effective_date text NOT NULL,
    source_type text DEFAULT 'item_master'::text NOT NULL,
    source_id integer,
    source_ref text,
    notes text,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_item_purchase_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_item_purchase_prices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_item_purchase_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_item_purchase_prices_id_seq OWNED BY public.stock_item_purchase_prices.id;


--
-- Name: stock_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_items (
    id integer NOT NULL,
    company_id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    uom text DEFAULT 'pcs'::text NOT NULL,
    type text DEFAULT 'product'::text NOT NULL,
    unit_price numeric(15,2) DEFAULT 0,
    stock_qty numeric(15,3) DEFAULT 0,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    min_stock_level numeric(15,3) DEFAULT 0,
    reorder_level numeric(15,3) DEFAULT 0,
    max_stock_level numeric(15,3) DEFAULT 0,
    created_by integer,
    updated_by integer,
    updated_at timestamp with time zone DEFAULT now(),
    batch_no text,
    mrp_price numeric(15,2) DEFAULT 0,
    alternate_uom text,
    alternate_qty numeric(15,4) DEFAULT 0,
    main_qty numeric(15,4) DEFAULT 0,
    is_weight_based boolean DEFAULT false NOT NULL,
    category text,
    sub_category text,
    brand text,
    barcode text,
    sales_person text,
    item_image text,
    purchase_price numeric(15,2) DEFAULT 0,
    track_inventory boolean DEFAULT true NOT NULL,
    show_in_pos boolean DEFAULT true NOT NULL,
    pricing_method text DEFAULT 'fixed'::text,
    tax_percent numeric(5,2) DEFAULT 9,
    expiry_date text,
    manufacturing_date text,
    batches_json text,
    stock_group text
);


--
-- Name: stock_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_items_id_seq OWNED BY public.stock_items.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    company_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    stock_item_id integer NOT NULL,
    transaction_type text NOT NULL,
    document_number text,
    reference_type text,
    reference_id integer,
    quantity_in numeric(15,3) DEFAULT 0 NOT NULL,
    quantity_out numeric(15,3) DEFAULT 0 NOT NULL,
    balance numeric(15,3) NOT NULL,
    reference text,
    user_id integer,
    username text,
    movement_date timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: stock_serials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_serials (
    id integer NOT NULL,
    company_id integer NOT NULL,
    stock_item_id integer NOT NULL,
    serial_number text NOT NULL,
    status text DEFAULT 'available'::text NOT NULL,
    grn_id integer,
    grn_number text,
    invoice_id integer,
    invoice_number text,
    reserved_by_user text,
    do_id integer,
    do_number text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    batch_no text,
    expiry_date text,
    manufacturing_date text
);


--
-- Name: stock_serials_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_serials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_serials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_serials_id_seq OWNED BY public.stock_serials.id;


--
-- Name: stock_transfer_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_transfer_items (
    id integer NOT NULL,
    stock_transfer_id integer NOT NULL,
    stock_item_id integer NOT NULL,
    quantity numeric(15,3) NOT NULL
);


--
-- Name: stock_transfer_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_transfer_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_transfer_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_transfer_items_id_seq OWNED BY public.stock_transfer_items.id;


--
-- Name: stock_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_transfers (
    id integer NOT NULL,
    company_id integer NOT NULL,
    transfer_number text NOT NULL,
    from_warehouse_id integer NOT NULL,
    to_warehouse_id integer NOT NULL,
    transfer_date date NOT NULL,
    remarks text,
    status text DEFAULT 'posted'::text NOT NULL,
    created_by integer,
    updated_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    sales_person text
);


--
-- Name: stock_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_transfers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_transfers_id_seq OWNED BY public.stock_transfers.id;


--
-- Name: tax_filings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_filings (
    id integer NOT NULL,
    company_id integer NOT NULL,
    type text NOT NULL,
    financial_year integer NOT NULL,
    fy_end_date text,
    revenue numeric(15,2),
    chargeable_income numeric(15,2),
    tax_payable numeric(15,2),
    status text DEFAULT 'draft'::text NOT NULL,
    filed_date text,
    reference_no text,
    data jsonb DEFAULT '{}'::jsonb,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer
);


--
-- Name: tax_filings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tax_filings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tax_filings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tax_filings_id_seq OWNED BY public.tax_filings.id;


--
-- Name: user_companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_companies (
    id integer NOT NULL,
    user_id integer NOT NULL,
    company_id integer NOT NULL,
    modules jsonb DEFAULT '["purchase_orders", "quotations", "invoices", "delivery_orders"]'::jsonb NOT NULL
);


--
-- Name: user_companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_companies_id_seq OWNED BY public.user_companies.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text DEFAULT ''::text,
    role text DEFAULT 'user'::text NOT NULL,
    email text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    full_name text,
    phone_number text,
    is_active boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer,
    role_id integer,
    sales_person_id integer,
    database_name text
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vendor_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_invoices (
    id integer NOT NULL,
    company_id integer NOT NULL,
    pi_number text NOT NULL,
    pi_date text,
    vendor_name text NOT NULL,
    po_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    po_numbers text,
    currency text DEFAULT 'SGD'::text NOT NULL,
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    paid_amount numeric(15,2) DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    expense_account_id integer,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    subtotal numeric(15,2) DEFAULT 0 NOT NULL,
    tax numeric(15,2) DEFAULT 0 NOT NULL,
    exchange_rate numeric(10,6) DEFAULT 1.000000 NOT NULL,
    gst_treatment text DEFAULT 'standard_rated'::text NOT NULL,
    gst_rate numeric(5,2) DEFAULT 9 NOT NULL,
    gst_amount numeric(15,2) DEFAULT 0 NOT NULL,
    gst_inclusive boolean DEFAULT false NOT NULL,
    payment_terms text,
    due_date text,
    planned_payment_date text,
    reminders_enabled boolean DEFAULT true NOT NULL,
    reminder_start_day integer,
    reminder_extra_recipients jsonb DEFAULT '[]'::jsonb NOT NULL,
    reminder_extra_emails jsonb DEFAULT '[]'::jsonb NOT NULL,
    reminder_start_after_day integer,
    reminder_emails jsonb DEFAULT '[]'::jsonb NOT NULL,
    sales_person text,
    customer_note text,
    delivery_instructions text,
    terms_and_conditions text,
    authorised_signature text,
    discount_amount numeric(15,2) DEFAULT 0 NOT NULL,
    attachment_path text,
    attachment_name text
);


--
-- Name: vendor_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendor_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendor_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendor_invoices_id_seq OWNED BY public.vendor_invoices.id;


--
-- Name: vendor_opening_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_opening_balances (
    id integer NOT NULL,
    company_id integer NOT NULL,
    financial_year_id integer NOT NULL,
    vendor_id integer,
    vendor_name text NOT NULL,
    amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vendor_opening_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendor_opening_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendor_opening_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendor_opening_balances_id_seq OWNED BY public.vendor_opening_balances.id;


--
-- Name: vendor_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_payments (
    id integer NOT NULL,
    company_id integer NOT NULL,
    vendor_invoice_id integer NOT NULL,
    payment_date text NOT NULL,
    amount numeric(15,2) NOT NULL,
    reference text,
    payment_method text DEFAULT 'bank_transfer'::text,
    notes text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vendor_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendor_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendor_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendor_payments_id_seq OWNED BY public.vendor_payments.id;


--
-- Name: vendor_proforma_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_proforma_invoices (
    id integer NOT NULL,
    vpi_number text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    vendor_name text NOT NULL,
    vendor_address text,
    vendor_contact text,
    vendor_contact_email text,
    delivery_address text,
    issue_date text,
    delivery_date text,
    payment_terms text,
    notes text,
    is_private boolean DEFAULT false NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    subtotal numeric(15,2) DEFAULT 0 NOT NULL,
    discount_amount numeric(15,2) DEFAULT 0 NOT NULL,
    tax numeric(15,2) DEFAULT 0 NOT NULL,
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    pq_ref_no text,
    status text DEFAULT 'draft'::text NOT NULL,
    email_sent_to text,
    terms_and_conditions text,
    delivery_instructions text,
    customer_note text,
    authorised_signature text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vendor_proforma_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendor_proforma_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendor_proforma_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendor_proforma_invoices_id_seq OWNED BY public.vendor_proforma_invoices.id;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id integer NOT NULL,
    company_id integer NOT NULL,
    name text NOT NULL,
    address text,
    postal_code text,
    country text,
    contact_person text,
    contact_email text,
    phone text,
    currency text,
    gst_registered boolean DEFAULT false NOT NULL,
    gst_no text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vendors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendors_id_seq OWNED BY public.vendors.id;


--
-- Name: voucher_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.voucher_attachments (
    id integer NOT NULL,
    voucher_id integer NOT NULL,
    file_name text DEFAULT 'attachment'::text NOT NULL,
    mime_type text DEFAULT 'image/jpeg'::text NOT NULL,
    file_data text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: voucher_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.voucher_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: voucher_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.voucher_attachments_id_seq OWNED BY public.voucher_attachments.id;


--
-- Name: vouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vouchers (
    id integer NOT NULL,
    voucher_number text NOT NULL,
    company_id integer NOT NULL,
    project_id integer,
    type text DEFAULT 'payment'::text NOT NULL,
    payee text NOT NULL,
    payee_contact text,
    issue_date text,
    description text,
    status text DEFAULT 'draft'::text NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    paid_date text,
    bank_ref text,
    notes text,
    proof_data text,
    proof_mime_type text,
    created_by integer NOT NULL,
    prepared_by_name text,
    verifier_id integer,
    approver_id integer,
    paid_by_id integer,
    verified_at text,
    approved_at text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vouchers_id_seq OWNED BY public.vouchers.id;


--
-- Name: warehouse_stock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warehouse_stock (
    id integer NOT NULL,
    company_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    stock_item_id integer NOT NULL,
    quantity numeric(15,3) DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: warehouse_stock_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warehouse_stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warehouse_stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warehouse_stock_id_seq OWNED BY public.warehouse_stock.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warehouses (
    id integer NOT NULL,
    company_id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    address text,
    city text,
    country text,
    contact_person text,
    contact_number text,
    email text,
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by integer,
    updated_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    state text,
    pin_code text,
    remarks text
);


--
-- Name: warehouses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warehouses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warehouses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warehouses_id_seq OWNED BY public.warehouses.id;


--
-- Name: wht_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wht_records (
    id integer NOT NULL,
    company_id integer NOT NULL,
    vendor_name text NOT NULL,
    vendor_country text,
    payment_date text NOT NULL,
    nature text NOT NULL,
    payment_type text NOT NULL,
    currency text DEFAULT 'SGD'::text NOT NULL,
    gross_amount numeric(15,2) NOT NULL,
    wht_rate numeric(5,2) NOT NULL,
    wht_amount numeric(15,2) NOT NULL,
    net_amount numeric(15,2) NOT NULL,
    filing_deadline text,
    status text DEFAULT 'pending'::text NOT NULL,
    filed_date text,
    reference_no text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer
);


--
-- Name: wht_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wht_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wht_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wht_records_id_seq OWNED BY public.wht_records.id;


--
-- Name: accounting_backups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_backups ALTER COLUMN id SET DEFAULT nextval('public.accounting_backups_id_seq'::regclass);


--
-- Name: accounting_restore_operations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_restore_operations ALTER COLUMN id SET DEFAULT nextval('public.accounting_restore_operations_id_seq'::regclass);


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: asset_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_assignments ALTER COLUMN id SET DEFAULT nextval('public.asset_assignments_id_seq'::regclass);


--
-- Name: assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets ALTER COLUMN id SET DEFAULT nextval('public.assets_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: backup_retention_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_retention_settings ALTER COLUMN id SET DEFAULT nextval('public.backup_retention_settings_id_seq'::regclass);


--
-- Name: backup_schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_schedules ALTER COLUMN id SET DEFAULT nextval('public.backup_schedules_id_seq'::regclass);


--
-- Name: bank_opening_balances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_opening_balances ALTER COLUMN id SET DEFAULT nextval('public.bank_opening_balances_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: credit_notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_notes ALTER COLUMN id SET DEFAULT nextval('public.credit_notes_id_seq'::regclass);


--
-- Name: customer_deposits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_deposits ALTER COLUMN id SET DEFAULT nextval('public.customer_deposits_id_seq'::regclass);


--
-- Name: customer_opening_balances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_opening_balances ALTER COLUMN id SET DEFAULT nextval('public.customer_opening_balances_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: debit_notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.debit_notes ALTER COLUMN id SET DEFAULT nextval('public.debit_notes_id_seq'::regclass);


--
-- Name: delivery_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_orders ALTER COLUMN id SET DEFAULT nextval('public.delivery_orders_id_seq'::regclass);


--
-- Name: dependents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dependents ALTER COLUMN id SET DEFAULT nextval('public.dependents_id_seq'::regclass);


--
-- Name: email_contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_contacts ALTER COLUMN id SET DEFAULT nextval('public.email_contacts_id_seq'::regclass);


--
-- Name: employee_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_documents ALTER COLUMN id SET DEFAULT nextval('public.employee_documents_id_seq'::regclass);


--
-- Name: employee_payroll id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_payroll ALTER COLUMN id SET DEFAULT nextval('public.employee_payroll_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: financial_years id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_years ALTER COLUMN id SET DEFAULT nextval('public.financial_years_id_seq'::regclass);


--
-- Name: fixed_asset_opening_balances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_asset_opening_balances ALTER COLUMN id SET DEFAULT nextval('public.fixed_asset_opening_balances_id_seq'::regclass);


--
-- Name: goods_issue_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_issue_items ALTER COLUMN id SET DEFAULT nextval('public.goods_issue_items_id_seq'::regclass);


--
-- Name: goods_issues id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_issues ALTER COLUMN id SET DEFAULT nextval('public.goods_issues_id_seq'::regclass);


--
-- Name: goods_receipt_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_items ALTER COLUMN id SET DEFAULT nextval('public.goods_receipt_items_id_seq'::regclass);


--
-- Name: goods_receipts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipts ALTER COLUMN id SET DEFAULT nextval('public.goods_receipts_id_seq'::regclass);


--
-- Name: grn id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn ALTER COLUMN id SET DEFAULT nextval('public.grn_id_seq'::regclass);


--
-- Name: income_attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.income_attachments ALTER COLUMN id SET DEFAULT nextval('public.income_attachments_id_seq'::regclass);


--
-- Name: income_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.income_records ALTER COLUMN id SET DEFAULT nextval('public.income_records_id_seq'::regclass);


--
-- Name: inventory_opening_balances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_opening_balances ALTER COLUMN id SET DEFAULT nextval('public.inventory_opening_balances_id_seq'::regclass);


--
-- Name: invoice_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments ALTER COLUMN id SET DEFAULT nextval('public.invoice_payments_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: ir8a_employers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir8a_employers ALTER COLUMN id SET DEFAULT nextval('public.ir8a_employers_id_seq'::regclass);


--
-- Name: journal_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries ALTER COLUMN id SET DEFAULT nextval('public.journal_entries_id_seq'::regclass);


--
-- Name: journal_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_lines ALTER COLUMN id SET DEFAULT nextval('public.journal_lines_id_seq'::regclass);


--
-- Name: licenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.licenses ALTER COLUMN id SET DEFAULT nextval('public.licenses_id_seq'::regclass);


--
-- Name: maintenance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance ALTER COLUMN id SET DEFAULT nextval('public.maintenance_id_seq'::regclass);


--
-- Name: maintenance_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_records ALTER COLUMN id SET DEFAULT nextval('public.maintenance_records_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: opening_balances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opening_balances ALTER COLUMN id SET DEFAULT nextval('public.opening_balances_id_seq'::regclass);


--
-- Name: opening_stock id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opening_stock ALTER COLUMN id SET DEFAULT nextval('public.opening_stock_id_seq'::regclass);


--
-- Name: ops_asset_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_asset_assignments ALTER COLUMN id SET DEFAULT nextval('public.ops_asset_assignments_id_seq'::regclass);


--
-- Name: ops_assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_assets ALTER COLUMN id SET DEFAULT nextval('public.ops_assets_id_seq'::regclass);


--
-- Name: ops_company_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_company_documents ALTER COLUMN id SET DEFAULT nextval('public.ops_company_documents_id_seq'::regclass);


--
-- Name: ops_employee_payroll id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_employee_payroll ALTER COLUMN id SET DEFAULT nextval('public.ops_employee_payroll_id_seq'::regclass);


--
-- Name: ops_employees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_employees ALTER COLUMN id SET DEFAULT nextval('public.ops_employees_id_seq'::regclass);


--
-- Name: ops_licenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_licenses ALTER COLUMN id SET DEFAULT nextval('public.ops_licenses_id_seq'::regclass);


--
-- Name: ops_payroll_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_payroll_records ALTER COLUMN id SET DEFAULT nextval('public.ops_payroll_records_id_seq'::regclass);


--
-- Name: ops_tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_tasks ALTER COLUMN id SET DEFAULT nextval('public.ops_tasks_id_seq'::regclass);


--
-- Name: payroll_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records ALTER COLUMN id SET DEFAULT nextval('public.payroll_records_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: proforma_invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_invoices ALTER COLUMN id SET DEFAULT nextval('public.proforma_invoices_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: purchase_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders ALTER COLUMN id SET DEFAULT nextval('public.purchase_orders_id_seq'::regclass);


--
-- Name: purchase_quotations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_quotations ALTER COLUMN id SET DEFAULT nextval('public.purchase_quotations_id_seq'::regclass);


--
-- Name: quotations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations ALTER COLUMN id SET DEFAULT nextval('public.quotations_id_seq'::regclass);


--
-- Name: report_definitions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_definitions ALTER COLUMN id SET DEFAULT nextval('public.report_definitions_id_seq'::regclass);


--
-- Name: report_fields id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_fields ALTER COLUMN id SET DEFAULT nextval('public.report_fields_id_seq'::regclass);


--
-- Name: report_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_templates ALTER COLUMN id SET DEFAULT nextval('public.report_templates_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: sales_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders ALTER COLUMN id SET DEFAULT nextval('public.sales_orders_id_seq'::regclass);


--
-- Name: sales_persons id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_persons ALTER COLUMN id SET DEFAULT nextval('public.sales_persons_id_seq'::regclass);


--
-- Name: service_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_reports ALTER COLUMN id SET DEFAULT nextval('public.service_reports_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: stock_adjustments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments ALTER COLUMN id SET DEFAULT nextval('public.stock_adjustments_id_seq'::regclass);


--
-- Name: stock_item_purchase_prices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_purchase_prices ALTER COLUMN id SET DEFAULT nextval('public.stock_item_purchase_prices_id_seq'::regclass);


--
-- Name: stock_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_items ALTER COLUMN id SET DEFAULT nextval('public.stock_items_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: stock_serials id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_serials ALTER COLUMN id SET DEFAULT nextval('public.stock_serials_id_seq'::regclass);


--
-- Name: stock_transfer_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfer_items ALTER COLUMN id SET DEFAULT nextval('public.stock_transfer_items_id_seq'::regclass);


--
-- Name: stock_transfers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers ALTER COLUMN id SET DEFAULT nextval('public.stock_transfers_id_seq'::regclass);


--
-- Name: tax_filings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_filings ALTER COLUMN id SET DEFAULT nextval('public.tax_filings_id_seq'::regclass);


--
-- Name: user_companies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_companies ALTER COLUMN id SET DEFAULT nextval('public.user_companies_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vendor_invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_invoices ALTER COLUMN id SET DEFAULT nextval('public.vendor_invoices_id_seq'::regclass);


--
-- Name: vendor_opening_balances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_opening_balances ALTER COLUMN id SET DEFAULT nextval('public.vendor_opening_balances_id_seq'::regclass);


--
-- Name: vendor_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_payments ALTER COLUMN id SET DEFAULT nextval('public.vendor_payments_id_seq'::regclass);


--
-- Name: vendor_proforma_invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_proforma_invoices ALTER COLUMN id SET DEFAULT nextval('public.vendor_proforma_invoices_id_seq'::regclass);


--
-- Name: vendors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors ALTER COLUMN id SET DEFAULT nextval('public.vendors_id_seq'::regclass);


--
-- Name: voucher_attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voucher_attachments ALTER COLUMN id SET DEFAULT nextval('public.voucher_attachments_id_seq'::regclass);


--
-- Name: vouchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vouchers ALTER COLUMN id SET DEFAULT nextval('public.vouchers_id_seq'::regclass);


--
-- Name: warehouse_stock id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_stock ALTER COLUMN id SET DEFAULT nextval('public.warehouse_stock_id_seq'::regclass);


--
-- Name: warehouses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses ALTER COLUMN id SET DEFAULT nextval('public.warehouses_id_seq'::regclass);


--
-- Name: wht_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wht_records ALTER COLUMN id SET DEFAULT nextval('public.wht_records_id_seq'::regclass);


--
-- Data for Name: accounting_backups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounting_backups (id, company_id, backup_code, backup_type, from_date, to_date, financial_year_id, financial_year_label, status, storage_path, storage_ref, file_size_bytes, checksum_sha256, backup_source, schedule_id, error_message, created_by, created_by_username, created_at, completed_at, restored_at, restored_by) FROM stdin;
\.


--
-- Data for Name: accounting_restore_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounting_restore_operations (id, company_id, restore_code, backup_id, backup_code, restore_type, status, safety_backup_id, safety_backup_code, steps_json, result_message, error_details, started_by, started_by_username, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (id, company_id, code, name, type, sub_type, description, is_active, is_system, created_at) FROM stdin;
\.


--
-- Data for Name: asset_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.asset_assignments (id, company_id, asset_id, employee_id, date_assigned, date_returned, notes, created_at) FROM stdin;
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assets (id, company_id, tag, type, category, serial, model, manufacturer, status, condition, assigned_to, location, vendor, vendor_id, invoice_number, purchase_date, warranty_expiry, cost, depreciation_start_date, useful_life_years, depreciation_method, description, has_license, created_at, useful_life_unit, residual_value, depreciation_frequency, depreciation_book, asset_image) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, company_id, user_id, username, action, entity_type, entity_id, entity_label, details, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: backup_retention_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_retention_settings (id, company_id, daily_keep_days, weekly_keep_weeks, monthly_keep_months, financial_year_keep_forever, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: backup_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_schedules (id, company_id, enabled, frequency, time_of_day, day_of_week, backup_type, last_run_at, next_run_at, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bank_opening_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_opening_balances (id, company_id, financial_year_id, account_id, account_code, account_name, amount, created_at) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies (id, name, country, address, registration_no, email, phone, logo_url, created_at, domain, gst_reg_no, slug, database_name, business_type) FROM stdin;
24	MSM Solutions	SG	House Number:36-99-184 RamjeeEstate Kancharapalam visakhapatnam 530008\nHouse Number:36-99-184 RamjeeEstate Kancharapalam visakhapatnam 530008	\N	msmsolutions@gmail.com	+65 2156 2750	\N	2026-10-26 21:08:54.111-07	\N	\N	msmsolutions	bizone_msmsolutions	trading_services
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, title, created_at) FROM stdin;
\.


--
-- Data for Name: credit_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_notes (id, cn_number, company_id, customer_name, customer_address, contact_person, contact_email, ref_inv_number, reason, issue_date, currency, payment_terms, notes, is_private, items, subtotal, discount_amount, tax_rate, tax, total_amount, status, void_reason, email_sent_to, created_by, created_at, so_id, so_number, terms_and_conditions, delivery_instructions, customer_note, authorised_signature) FROM stdin;
\.


--
-- Data for Name: customer_deposits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_deposits (id, company_id, customer_name, currency, total_amount, applied_amount, status, payment_date, payment_method, bank_ref, notes, journal_entry_id, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: customer_opening_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_opening_balances (id, company_id, financial_year_id, customer_id, customer_name, amount, currency, created_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, company_id, name, address, postal_code, country, contact_person, contact_email, phone, currency, gst_registered, gst_no, ship_to_address, is_active, created_at, quotation_terms, credit_limit_enabled, credit_limit) FROM stdin;
\.


--
-- Data for Name: debit_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.debit_notes (id, dn_number, company_id, customer_name, customer_address, contact_person, contact_email, ref_inv_number, reason, issue_date, currency, payment_terms, notes, is_private, items, subtotal, discount_amount, tax_rate, tax, total_amount, status, void_reason, email_sent_to, created_by, created_at, so_id, so_number, terms_and_conditions, delivery_instructions, customer_note, authorised_signature, attachment_path, attachment_name) FROM stdin;
\.


--
-- Data for Name: delivery_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.delivery_orders (id, do_number, company_id, customer_name, customer_address, customer_contact, issue_date, delivery_date, payment_terms, notes, is_private, items, status, email_sent_to, inv_id, inv_number, created_by, created_at, so_id, so_number, terms_and_conditions, delivery_instructions, customer_note, authorised_signature) FROM stdin;
\.


--
-- Data for Name: dependents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dependents (id, company_id, employee_id, name, relationship, passport_number, passport_expiry, visa_number, visa_expiry, visa_type, created_at) FROM stdin;
\.


--
-- Data for Name: email_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_contacts (id, company_id, name, email, use_count, last_used_at, created_at) FROM stdin;
\.


--
-- Data for Name: employee_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_documents (id, company_id, employee_id, document_type, file_path, issue_date, expiry_date, notes, created_at) FROM stdin;
\.


--
-- Data for Name: employee_payroll; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_payroll (id, company_id, employee_id, base_salary, payroll_period, cpf_employee_rate, cpf_employer_rate, allowances, deductions, bank_name, bank_account, is_active, created_at, updated_at, hourly_rate, overtime_rate, no_of_working_days, tax_rate, cpf_rate, cpf_amount, employer_cpf_rate, employer_cpf_amount, net_salary, effective_from, effective_to) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employees (id, company_id, employee_id, user_id, name, email, phone, address, department, designation, join_date, status, salary, annual_salary, nationality, pr_status, date_of_birth, passport_number, passport_expiry, visa_number, visa_expiry, visa_type, visa_remarks, nric_number, nric_expiry, created_at, passport_scan, visa_scan, nric_scan, gender) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, company_id, expense_date, vendor_name, description, category, amount, gst_amount, gst_claimable, is_deductible, deductible_pct, currency, payment_method, receipt_data, receipt_mime_type, vendor_id, project_id, voucher_id, journal_entry_id, status, notes, created_by, created_at, updated_at, account_id) FROM stdin;
\.


--
-- Data for Name: financial_years; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_years (id, company_id, label, start_date, end_date, status, audit_status, closed_at, closed_by, closed_by_username, activated_at, activated_by, activated_by_username, reopened_at, reopened_by, opening_balances_generated, opening_journal_entry_id, created_at) FROM stdin;
1	24	FY 2026	2026-01-01	2026-12-31	active	pending	\N	\N	\N	2026-10-26 21:09:00.597-07	\N	\N	\N	\N	f	\N	2026-10-26 21:09:00.598811-07
\.


--
-- Data for Name: fixed_asset_opening_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fixed_asset_opening_balances (id, company_id, financial_year_id, account_code, description, amount, created_at) FROM stdin;
\.


--
-- Data for Name: goods_issue_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.goods_issue_items (id, goods_issue_id, stock_item_id, quantity) FROM stdin;
\.


--
-- Data for Name: goods_issues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.goods_issues (id, company_id, gin_number, warehouse_id, reason, issue_date, remarks, status, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: goods_receipt_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.goods_receipt_items (id, goods_receipt_id, stock_item_id, quantity, unit_cost) FROM stdin;
\.


--
-- Data for Name: goods_receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.goods_receipts (id, company_id, grn_number, warehouse_id, supplier, reference_number, receipt_date, remarks, status, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grn; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grn (id, grn_number, po_id, po_number, vendor_name, company_id, status, items, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: income_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.income_attachments (id, income_id, file_name, mime_type, file_data, created_at) FROM stdin;
\.


--
-- Data for Name: income_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.income_records (id, company_id, income_date, payer_name, description, category, amount, gst_amount, gst_treatment, currency, exchange_rate, payment_method, account_id, reference, notes, status, journal_entry_id, created_by, created_at, updated_at, gst_claimable, is_deductible, deductible_pct) FROM stdin;
\.


--
-- Data for Name: inventory_opening_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_opening_balances (id, company_id, financial_year_id, stock_item_id, item_code, item_name, warehouse_id, warehouse_name, quantity, value, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_payments (id, company_id, invoice_id, payment_date, amount, reference, payment_method, notes, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, inv_number, company_id, customer_name, customer_address, customer_contact, customer_contact_email, delivery_address, issue_date, delivery_date, payment_terms, notes, is_private, items, subtotal, discount_amount, tax, total_amount, currency, po_ref_no, status, email_sent_to, void_reason, created_by, created_at, exchange_rate, so_id, so_number, sales_person, terms_and_conditions, delivery_instructions, customer_note, authorised_signature, is_modified) FROM stdin;
\.


--
-- Data for Name: ir8a_employers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ir8a_employers (id, company_id, employer_name, uen, address, signatory_name, designation, declaration_date, signature, created_at) FROM stdin;
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_entries (id, company_id, entry_date, description, ref_type, ref_id, ref_number, status, reversal_of_id, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: journal_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_lines (id, journal_entry_id, account_id, description, debit, credit, created_at) FROM stdin;
\.


--
-- Data for Name: licenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.licenses (id, company_id, asset_id, name, license_key, type, seats, vendor_id, purchase_date, expiry_date, cost, renewal_cycle, status, notes, created_at) FROM stdin;
\.


--
-- Data for Name: login_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_credentials (user_id, password_hash, updated_at) FROM stdin;
\.


--
-- Data for Name: maintenance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance (id, is_enabled, scheduled_start, scheduled_end, message, contact_email, updated_at, updated_by_user) FROM stdin;
\.


--
-- Data for Name: maintenance_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_records (id, company_id, asset_id, issue_description, resolution, service_date, next_maintenance_date, cost, created_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, conversation_id, role, content, created_at) FROM stdin;
\.


--
-- Data for Name: opening_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.opening_balances (id, company_id, financial_year_id, account_id, account_code, account_name, account_type, debit, credit, notes, created_at) FROM stdin;
\.


--
-- Data for Name: opening_stock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.opening_stock (id, company_id, warehouse_id, stock_item_id, quantity, unit_cost, entry_date, remarks, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ops_asset_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ops_asset_assignments (id, company_id, asset_id, employee_id, date_assigned, date_returned, notes, created_at) FROM stdin;
\.


--
-- Data for Name: ops_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ops_assets (id, company_id, tag, type, category, serial, model, manufacturer, status, condition, assigned_to, location, vendor, purchase_date, warranty_expiry, cost, description, has_license, created_at) FROM stdin;
\.


--
-- Data for Name: ops_company_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ops_company_documents (id, company_id, document_type, title, file_path, issue_date, expiry_date, notes, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: ops_employee_payroll; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ops_employee_payroll (id, company_id, employee_id, base_salary, allowances, deductions, currency, pay_frequency, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ops_employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ops_employees (id, company_id, employee_code, name, email, phone, address, department, designation, join_date, status, salary, nationality, created_at) FROM stdin;
\.


--
-- Data for Name: ops_licenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ops_licenses (id, company_id, asset_id, name, license_key, type, seats, purchase_date, expiry_date, cost, renewal_cycle, status, notes, created_at) FROM stdin;
\.


--
-- Data for Name: ops_payroll_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ops_payroll_records (id, company_id, employee_id, payroll_config_id, period_start, period_end, gross_pay, net_pay, status, notes, created_at) FROM stdin;
\.


--
-- Data for Name: ops_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ops_tasks (id, company_id, title, description, status, priority, assignee_id, start_date, due_date, event_type, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payroll_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_records (id, company_id, employee_id, payroll_config_id, pay_period_start, pay_period_end, gross_pay, net_pay, cpf_employee, cpf_employer, status, processed_at, created_at, base_salary, overtime_hours, overtime_pay, allowances, deductions, notes, updated_at, payroll_month, payroll_year) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, module, action, created_at, updated_at) FROM stdin;
1	dashboard	view	2026-08-12 05:12:08.311-07	2026-08-12 05:12:08.311-07
2	dashboard	create	2026-08-12 05:12:08.314-07	2026-08-12 05:12:08.314-07
3	dashboard	edit	2026-08-12 05:12:08.315-07	2026-08-12 05:12:08.315-07
4	dashboard	delete	2026-08-12 05:12:08.317-07	2026-08-12 05:12:08.317-07
5	assets	view	2026-08-12 05:12:08.318-07	2026-08-12 05:12:08.318-07
6	assets	create	2026-08-12 05:12:08.319-07	2026-08-12 05:12:08.319-07
7	assets	edit	2026-08-12 05:12:08.32-07	2026-08-12 05:12:08.32-07
8	assets	delete	2026-08-12 05:12:08.32-07	2026-08-12 05:12:08.32-07
9	licenses	view	2026-08-12 05:12:08.321-07	2026-08-12 05:12:08.321-07
10	licenses	create	2026-08-12 05:12:08.322-07	2026-08-12 05:12:08.322-07
11	licenses	edit	2026-08-12 05:12:08.324-07	2026-08-12 05:12:08.324-07
12	licenses	delete	2026-08-12 05:12:08.325-07	2026-08-12 05:12:08.325-07
13	employees	view	2026-08-12 05:12:08.326-07	2026-08-12 05:12:08.326-07
14	employees	create	2026-08-12 05:12:08.327-07	2026-08-12 05:12:08.327-07
15	employees	edit	2026-08-12 05:12:08.328-07	2026-08-12 05:12:08.328-07
16	employees	delete	2026-08-12 05:12:08.329-07	2026-08-12 05:12:08.329-07
17	payroll	view	2026-08-12 05:12:08.33-07	2026-08-12 05:12:08.33-07
18	payroll	create	2026-08-12 05:12:08.331-07	2026-08-12 05:12:08.331-07
19	payroll	edit	2026-08-12 05:12:08.332-07	2026-08-12 05:12:08.332-07
20	payroll	delete	2026-08-12 05:12:08.333-07	2026-08-12 05:12:08.333-07
21	service_reports	view	2026-08-12 05:12:08.334-07	2026-08-12 05:12:08.334-07
22	service_reports	create	2026-08-12 05:12:08.335-07	2026-08-12 05:12:08.335-07
23	service_reports	edit	2026-08-12 05:12:08.336-07	2026-08-12 05:12:08.336-07
24	service_reports	delete	2026-08-12 05:12:08.337-07	2026-08-12 05:12:08.337-07
25	purchase_orders	view	2026-08-12 05:12:08.338-07	2026-08-12 05:12:08.338-07
26	purchase_orders	create	2026-08-12 05:12:08.339-07	2026-08-12 05:12:08.339-07
27	purchase_orders	edit	2026-08-12 05:12:08.34-07	2026-08-12 05:12:08.34-07
28	purchase_orders	delete	2026-08-12 05:12:08.341-07	2026-08-12 05:12:08.341-07
29	quotations	view	2026-08-12 05:12:08.342-07	2026-08-12 05:12:08.342-07
30	quotations	create	2026-08-12 05:12:08.343-07	2026-08-12 05:12:08.343-07
31	quotations	edit	2026-08-12 05:12:08.344-07	2026-08-12 05:12:08.344-07
32	quotations	delete	2026-08-12 05:12:08.345-07	2026-08-12 05:12:08.345-07
33	sales_orders	view	2026-08-12 05:12:08.346-07	2026-08-12 05:12:08.346-07
34	sales_orders	create	2026-08-12 05:12:08.347-07	2026-08-12 05:12:08.347-07
35	sales_orders	edit	2026-08-12 05:12:08.348-07	2026-08-12 05:12:08.348-07
36	sales_orders	delete	2026-08-12 05:12:08.349-07	2026-08-12 05:12:08.349-07
37	invoices	view	2026-08-12 05:12:08.35-07	2026-08-12 05:12:08.35-07
38	invoices	create	2026-08-12 05:12:08.351-07	2026-08-12 05:12:08.351-07
39	invoices	edit	2026-08-12 05:12:08.352-07	2026-08-12 05:12:08.352-07
40	invoices	delete	2026-08-12 05:12:08.353-07	2026-08-12 05:12:08.353-07
41	proforma_invoices	view	2026-08-12 05:12:08.354-07	2026-08-12 05:12:08.354-07
42	proforma_invoices	create	2026-08-12 05:12:08.355-07	2026-08-12 05:12:08.355-07
43	proforma_invoices	edit	2026-08-12 05:12:08.356-07	2026-08-12 05:12:08.356-07
44	proforma_invoices	delete	2026-08-12 05:12:08.357-07	2026-08-12 05:12:08.357-07
45	credit_notes	view	2026-08-12 05:12:08.358-07	2026-08-12 05:12:08.358-07
46	credit_notes	create	2026-08-12 05:12:08.359-07	2026-08-12 05:12:08.359-07
47	credit_notes	edit	2026-08-12 05:12:08.359-07	2026-08-12 05:12:08.359-07
48	credit_notes	delete	2026-08-12 05:12:08.36-07	2026-08-12 05:12:08.36-07
49	delivery_orders	view	2026-08-12 05:12:08.361-07	2026-08-12 05:12:08.361-07
50	delivery_orders	create	2026-08-12 05:12:08.362-07	2026-08-12 05:12:08.362-07
51	delivery_orders	edit	2026-08-12 05:12:08.363-07	2026-08-12 05:12:08.363-07
52	delivery_orders	delete	2026-08-12 05:12:08.364-07	2026-08-12 05:12:08.364-07
53	point_of_sale	view	2026-08-12 05:12:08.365-07	2026-08-12 05:12:08.365-07
54	point_of_sale	create	2026-08-12 05:12:08.365-07	2026-08-12 05:12:08.365-07
55	point_of_sale	edit	2026-08-12 05:12:08.366-07	2026-08-12 05:12:08.366-07
56	point_of_sale	delete	2026-08-12 05:12:08.367-07	2026-08-12 05:12:08.367-07
57	bill_of_materials	view	2026-08-12 05:12:08.368-07	2026-08-12 05:12:08.368-07
58	bill_of_materials	create	2026-08-12 05:12:08.368-07	2026-08-12 05:12:08.368-07
59	bill_of_materials	edit	2026-08-12 05:12:08.369-07	2026-08-12 05:12:08.369-07
60	bill_of_materials	delete	2026-08-12 05:12:08.37-07	2026-08-12 05:12:08.37-07
61	grn	view	2026-08-12 05:12:08.37-07	2026-08-12 05:12:08.37-07
62	grn	create	2026-08-12 05:12:08.371-07	2026-08-12 05:12:08.371-07
63	grn	edit	2026-08-12 05:12:08.372-07	2026-08-12 05:12:08.372-07
64	grn	delete	2026-08-12 05:12:08.373-07	2026-08-12 05:12:08.373-07
65	stock_items	view	2026-08-12 05:12:08.375-07	2026-08-12 05:12:08.375-07
66	stock_items	create	2026-08-12 05:12:08.376-07	2026-08-12 05:12:08.376-07
67	stock_items	edit	2026-08-12 05:12:08.377-07	2026-08-12 05:12:08.377-07
68	stock_items	delete	2026-08-12 05:12:08.377-07	2026-08-12 05:12:08.377-07
69	warehouses	view	2026-08-12 05:12:08.378-07	2026-08-12 05:12:08.378-07
70	warehouses	create	2026-08-12 05:12:08.378-07	2026-08-12 05:12:08.378-07
71	warehouses	edit	2026-08-12 05:12:08.379-07	2026-08-12 05:12:08.379-07
72	warehouses	delete	2026-08-12 05:12:08.38-07	2026-08-12 05:12:08.38-07
73	stock_transfer	view	2026-08-12 05:12:08.38-07	2026-08-12 05:12:08.38-07
74	stock_transfer	create	2026-08-12 05:12:08.381-07	2026-08-12 05:12:08.381-07
75	stock_transfer	edit	2026-08-12 05:12:08.381-07	2026-08-12 05:12:08.381-07
76	stock_transfer	delete	2026-08-12 05:12:08.382-07	2026-08-12 05:12:08.382-07
77	inventory_reports	view	2026-08-12 05:12:08.383-07	2026-08-12 05:12:08.383-07
78	inventory_reports	create	2026-08-12 05:12:08.383-07	2026-08-12 05:12:08.383-07
79	inventory_reports	edit	2026-08-12 05:12:08.384-07	2026-08-12 05:12:08.384-07
80	inventory_reports	delete	2026-08-12 05:12:08.385-07	2026-08-12 05:12:08.385-07
81	batch_expiry	view	2026-08-12 05:12:08.385-07	2026-08-12 05:12:08.385-07
82	batch_expiry	create	2026-08-12 05:12:08.386-07	2026-08-12 05:12:08.386-07
83	batch_expiry	edit	2026-08-12 05:12:08.387-07	2026-08-12 05:12:08.387-07
84	batch_expiry	delete	2026-08-12 05:12:08.387-07	2026-08-12 05:12:08.387-07
85	vendors	view	2026-08-12 05:12:08.388-07	2026-08-12 05:12:08.388-07
86	vendors	create	2026-08-12 05:12:08.389-07	2026-08-12 05:12:08.389-07
87	vendors	edit	2026-08-12 05:12:08.389-07	2026-08-12 05:12:08.389-07
88	vendors	delete	2026-08-12 05:12:08.39-07	2026-08-12 05:12:08.39-07
89	customers	view	2026-08-12 05:12:08.391-07	2026-08-12 05:12:08.391-07
90	customers	create	2026-08-12 05:12:08.391-07	2026-08-12 05:12:08.391-07
91	customers	edit	2026-08-12 05:12:08.392-07	2026-08-12 05:12:08.392-07
92	customers	delete	2026-08-12 05:12:08.393-07	2026-08-12 05:12:08.393-07
93	projects	view	2026-08-12 05:12:08.393-07	2026-08-12 05:12:08.393-07
94	projects	create	2026-08-12 05:12:08.394-07	2026-08-12 05:12:08.394-07
95	projects	edit	2026-08-12 05:12:08.394-07	2026-08-12 05:12:08.394-07
96	projects	delete	2026-08-12 05:12:08.395-07	2026-08-12 05:12:08.395-07
97	accounting_coa	view	2026-08-12 05:12:08.395-07	2026-08-12 05:12:08.395-07
98	accounting_coa	create	2026-08-12 05:12:08.395-07	2026-08-12 05:12:08.395-07
99	accounting_coa	edit	2026-08-12 05:12:08.396-07	2026-08-12 05:12:08.396-07
100	accounting_coa	delete	2026-08-12 05:12:08.397-07	2026-08-12 05:12:08.397-07
101	accounting_je	view	2026-08-12 05:12:08.398-07	2026-08-12 05:12:08.398-07
102	accounting_je	create	2026-08-12 05:12:08.399-07	2026-08-12 05:12:08.399-07
103	accounting_je	edit	2026-08-12 05:12:08.4-07	2026-08-12 05:12:08.4-07
104	accounting_je	delete	2026-08-12 05:12:08.401-07	2026-08-12 05:12:08.401-07
105	accounting_gl	view	2026-08-12 05:12:08.402-07	2026-08-12 05:12:08.402-07
106	accounting_gl	create	2026-08-12 05:12:08.402-07	2026-08-12 05:12:08.402-07
107	accounting_gl	edit	2026-08-12 05:12:08.403-07	2026-08-12 05:12:08.403-07
108	accounting_gl	delete	2026-08-12 05:12:08.404-07	2026-08-12 05:12:08.404-07
109	accounting_tb	view	2026-08-12 05:12:08.404-07	2026-08-12 05:12:08.404-07
110	accounting_tb	create	2026-08-12 05:12:08.405-07	2026-08-12 05:12:08.405-07
111	accounting_tb	edit	2026-08-12 05:12:08.405-07	2026-08-12 05:12:08.405-07
112	accounting_tb	delete	2026-08-12 05:12:08.406-07	2026-08-12 05:12:08.406-07
113	accounting_bs	view	2026-08-12 05:12:08.407-07	2026-08-12 05:12:08.407-07
114	accounting_bs	create	2026-08-12 05:12:08.407-07	2026-08-12 05:12:08.407-07
115	accounting_bs	edit	2026-08-12 05:12:08.408-07	2026-08-12 05:12:08.408-07
116	accounting_bs	delete	2026-08-12 05:12:08.409-07	2026-08-12 05:12:08.409-07
117	accounting_pl	view	2026-08-12 05:12:08.409-07	2026-08-12 05:12:08.409-07
118	accounting_pl	create	2026-08-12 05:12:08.411-07	2026-08-12 05:12:08.411-07
119	accounting_pl	edit	2026-08-12 05:12:08.411-07	2026-08-12 05:12:08.411-07
120	accounting_pl	delete	2026-08-12 05:12:08.412-07	2026-08-12 05:12:08.412-07
121	accounting_cf	view	2026-08-12 05:12:08.412-07	2026-08-12 05:12:08.412-07
122	accounting_cf	create	2026-08-12 05:12:08.413-07	2026-08-12 05:12:08.413-07
123	accounting_cf	edit	2026-08-12 05:12:08.414-07	2026-08-12 05:12:08.414-07
124	accounting_cf	delete	2026-08-12 05:12:08.414-07	2026-08-12 05:12:08.414-07
125	accounting_gst_f5	view	2026-08-12 05:12:08.415-07	2026-08-12 05:12:08.415-07
126	accounting_gst_f5	create	2026-08-12 05:12:08.415-07	2026-08-12 05:12:08.415-07
127	accounting_gst_f5	edit	2026-08-12 05:12:08.415-07	2026-08-12 05:12:08.415-07
128	accounting_gst_f5	delete	2026-08-12 05:12:08.416-07	2026-08-12 05:12:08.416-07
129	accounting_gst_f7	view	2026-08-12 05:12:08.416-07	2026-08-12 05:12:08.416-07
130	accounting_gst_f7	create	2026-08-12 05:12:08.417-07	2026-08-12 05:12:08.417-07
131	accounting_gst_f7	edit	2026-08-12 05:12:08.417-07	2026-08-12 05:12:08.417-07
132	accounting_gst_f7	delete	2026-08-12 05:12:08.418-07	2026-08-12 05:12:08.418-07
133	accounting_gst_io	view	2026-08-12 05:12:08.418-07	2026-08-12 05:12:08.418-07
134	accounting_gst_io	create	2026-08-12 05:12:08.419-07	2026-08-12 05:12:08.419-07
135	accounting_gst_io	edit	2026-08-12 05:12:08.42-07	2026-08-12 05:12:08.42-07
136	accounting_gst_io	delete	2026-08-12 05:12:08.42-07	2026-08-12 05:12:08.42-07
137	accounting_wht	view	2026-08-12 05:12:08.421-07	2026-08-12 05:12:08.421-07
138	accounting_wht	create	2026-08-12 05:12:08.422-07	2026-08-12 05:12:08.422-07
139	accounting_wht	edit	2026-08-12 05:12:08.423-07	2026-08-12 05:12:08.423-07
140	accounting_wht	delete	2026-08-12 05:12:08.423-07	2026-08-12 05:12:08.423-07
141	accounting_eci	view	2026-08-12 05:12:08.424-07	2026-08-12 05:12:08.424-07
142	accounting_eci	create	2026-08-12 05:12:08.425-07	2026-08-12 05:12:08.425-07
143	accounting_eci	edit	2026-08-12 05:12:08.426-07	2026-08-12 05:12:08.426-07
144	accounting_eci	delete	2026-08-12 05:12:08.426-07	2026-08-12 05:12:08.426-07
145	accounting_formcs	view	2026-08-12 05:12:08.427-07	2026-08-12 05:12:08.427-07
146	accounting_formcs	create	2026-08-12 05:12:08.428-07	2026-08-12 05:12:08.428-07
147	accounting_formcs	edit	2026-08-12 05:12:08.429-07	2026-08-12 05:12:08.429-07
148	accounting_formcs	delete	2026-08-12 05:12:08.43-07	2026-08-12 05:12:08.43-07
149	accounting_iaf	view	2026-08-12 05:12:08.43-07	2026-08-12 05:12:08.43-07
150	accounting_iaf	create	2026-08-12 05:12:08.431-07	2026-08-12 05:12:08.431-07
151	accounting_iaf	edit	2026-08-12 05:12:08.431-07	2026-08-12 05:12:08.431-07
152	accounting_iaf	delete	2026-08-12 05:12:08.432-07	2026-08-12 05:12:08.432-07
153	accounting_ar	view	2026-08-12 05:12:08.432-07	2026-08-12 05:12:08.432-07
154	accounting_ar	create	2026-08-12 05:12:08.433-07	2026-08-12 05:12:08.433-07
155	accounting_ar	edit	2026-08-12 05:12:08.434-07	2026-08-12 05:12:08.434-07
156	accounting_ar	delete	2026-08-12 05:12:08.434-07	2026-08-12 05:12:08.434-07
157	accounting_ar_aging	view	2026-08-12 05:12:08.435-07	2026-08-12 05:12:08.435-07
158	accounting_ar_aging	create	2026-08-12 05:12:08.436-07	2026-08-12 05:12:08.436-07
159	accounting_ar_aging	edit	2026-08-12 05:12:08.437-07	2026-08-12 05:12:08.437-07
160	accounting_ar_aging	delete	2026-08-12 05:12:08.437-07	2026-08-12 05:12:08.437-07
161	accounting_cust_stmt	view	2026-08-12 05:12:08.438-07	2026-08-12 05:12:08.438-07
162	accounting_cust_stmt	create	2026-08-12 05:12:08.438-07	2026-08-12 05:12:08.438-07
163	accounting_cust_stmt	edit	2026-08-12 05:12:08.439-07	2026-08-12 05:12:08.439-07
164	accounting_cust_stmt	delete	2026-08-12 05:12:08.44-07	2026-08-12 05:12:08.44-07
165	accounting_ap	view	2026-08-12 05:12:08.441-07	2026-08-12 05:12:08.441-07
166	accounting_ap	create	2026-08-12 05:12:08.442-07	2026-08-12 05:12:08.442-07
167	accounting_ap	edit	2026-08-12 05:12:08.443-07	2026-08-12 05:12:08.443-07
168	accounting_ap	delete	2026-08-12 05:12:08.444-07	2026-08-12 05:12:08.444-07
169	accounting_ap_aging	view	2026-08-12 05:12:08.444-07	2026-08-12 05:12:08.444-07
170	accounting_ap_aging	create	2026-08-12 05:12:08.445-07	2026-08-12 05:12:08.445-07
171	accounting_ap_aging	edit	2026-08-12 05:12:08.445-07	2026-08-12 05:12:08.445-07
172	accounting_ap_aging	delete	2026-08-12 05:12:08.446-07	2026-08-12 05:12:08.446-07
173	accounting_vendor_stmt	view	2026-08-12 05:12:08.446-07	2026-08-12 05:12:08.446-07
174	accounting_vendor_stmt	create	2026-08-12 05:12:08.447-07	2026-08-12 05:12:08.447-07
175	accounting_vendor_stmt	edit	2026-08-12 05:12:08.448-07	2026-08-12 05:12:08.448-07
176	accounting_vendor_stmt	delete	2026-08-12 05:12:08.448-07	2026-08-12 05:12:08.448-07
177	user_management	view	2026-08-12 05:12:08.448-07	2026-08-12 05:12:08.448-07
178	user_management	create	2026-08-12 05:12:08.449-07	2026-08-12 05:12:08.449-07
179	user_management	edit	2026-08-12 05:12:08.45-07	2026-08-12 05:12:08.45-07
180	user_management	delete	2026-08-12 05:12:08.45-07	2026-08-12 05:12:08.45-07
181	audit_log	view	2026-08-12 05:12:08.451-07	2026-08-12 05:12:08.451-07
182	audit_log	create	2026-08-12 05:12:08.451-07	2026-08-12 05:12:08.451-07
183	audit_log	edit	2026-08-12 05:12:08.452-07	2026-08-12 05:12:08.452-07
184	audit_log	delete	2026-08-12 05:12:08.453-07	2026-08-12 05:12:08.453-07
185	settings	view	2026-08-12 05:12:08.453-07	2026-08-12 05:12:08.453-07
186	settings	create	2026-08-12 05:12:08.454-07	2026-08-12 05:12:08.454-07
187	settings	edit	2026-08-12 05:12:08.454-07	2026-08-12 05:12:08.454-07
188	settings	delete	2026-08-12 05:12:08.455-07	2026-08-12 05:12:08.455-07
1153	vendor_invoices	view	2026-08-12 21:00:11.134-07	2026-08-12 21:00:11.134-07
1154	vendor_invoices	create	2026-08-12 21:00:11.136-07	2026-08-12 21:00:11.136-07
1155	vendor_invoices	edit	2026-08-12 21:00:11.137-07	2026-08-12 21:00:11.137-07
1156	vendor_invoices	delete	2026-08-12 21:00:11.138-07	2026-08-12 21:00:11.138-07
1177	debit_notes	view	2026-08-12 21:00:11.152-07	2026-08-12 21:00:11.152-07
1178	debit_notes	create	2026-08-12 21:00:11.153-07	2026-08-12 21:00:11.153-07
1179	debit_notes	edit	2026-08-12 21:00:11.154-07	2026-08-12 21:00:11.154-07
1180	debit_notes	delete	2026-08-12 21:00:11.154-07	2026-08-12 21:00:11.154-07
1225	address_book	view	2026-08-12 21:00:11.184-07	2026-08-12 21:00:11.184-07
1226	address_book	create	2026-08-12 21:00:11.184-07	2026-08-12 21:00:11.184-07
1227	address_book	edit	2026-08-12 21:00:11.185-07	2026-08-12 21:00:11.185-07
1228	address_book	delete	2026-08-12 21:00:11.186-07	2026-08-12 21:00:11.186-07
1261	accounting_bank_recon	view	2026-08-12 21:00:11.202-07	2026-08-12 21:00:11.202-07
1262	accounting_bank_recon	create	2026-08-12 21:00:11.203-07	2026-08-12 21:00:11.203-07
1263	accounting_bank_recon	edit	2026-08-12 21:00:11.203-07	2026-08-12 21:00:11.203-07
1264	accounting_bank_recon	delete	2026-08-12 21:00:11.204-07	2026-08-12 21:00:11.204-07
1317	accounting_expenses	view	2026-08-12 21:00:11.232-07	2026-08-12 21:00:11.232-07
1318	accounting_expenses	create	2026-08-12 21:00:11.233-07	2026-08-12 21:00:11.233-07
1319	accounting_expenses	edit	2026-08-12 21:00:11.234-07	2026-08-12 21:00:11.234-07
1320	accounting_expenses	delete	2026-08-12 21:00:11.234-07	2026-08-12 21:00:11.234-07
1321	accounting_income	view	2026-08-12 21:00:11.236-07	2026-08-12 21:00:11.236-07
1322	accounting_income	create	2026-08-12 21:00:11.237-07	2026-08-12 21:00:11.237-07
1323	accounting_income	edit	2026-08-12 21:00:11.237-07	2026-08-12 21:00:11.237-07
1324	accounting_income	delete	2026-08-12 21:00:11.238-07	2026-08-12 21:00:11.238-07
6765	purchase_quotations	view	2026-08-16 20:52:24.462-07	2026-08-16 20:52:24.462-07
6766	purchase_quotations	create	2026-08-16 20:52:24.465-07	2026-08-16 20:52:24.465-07
6767	purchase_quotations	edit	2026-08-16 20:52:24.467-07	2026-08-16 20:52:24.467-07
6768	purchase_quotations	delete	2026-08-16 20:52:24.468-07	2026-08-16 20:52:24.468-07
9501	report_templates	view	2026-08-17 22:44:54.474-07	2026-08-17 22:44:54.474-07
9502	report_templates	create	2026-08-17 22:44:54.476-07	2026-08-17 22:44:54.476-07
9503	report_templates	edit	2026-08-17 22:44:54.48-07	2026-08-17 22:44:54.48-07
9504	report_templates	delete	2026-08-17 22:44:54.481-07	2026-08-17 22:44:54.481-07
13461	multi_price_level	view	2026-08-25 03:43:31.652-07	2026-08-25 03:43:31.652-07
13462	multi_price_level	create	2026-08-25 03:43:31.659-07	2026-08-25 03:43:31.659-07
13463	multi_price_level	edit	2026-08-25 03:43:31.662-07	2026-08-25 03:43:31.662-07
13464	multi_price_level	delete	2026-08-25 03:43:31.664-07	2026-08-25 03:43:31.664-07
20428	accounting_backup	view	2026-09-07 03:02:23.342-07	2026-09-07 03:02:23.342-07
20429	accounting_backup	create	2026-09-07 03:02:23.344-07	2026-09-07 03:02:23.344-07
20430	accounting_backup	edit	2026-09-07 03:02:23.344-07	2026-09-07 03:02:23.344-07
20431	accounting_backup	delete	2026-09-07 03:02:23.345-07	2026-09-07 03:02:23.345-07
40560	sales_person_wise_report	view	2026-09-20 22:33:48.992-07	2026-09-20 22:33:48.992-07
40561	sales_person_wise_report	create	2026-09-20 22:33:48.995-07	2026-09-20 22:33:48.995-07
40562	sales_person_wise_report	edit	2026-09-20 22:33:48.997-07	2026-09-20 22:33:48.997-07
40563	sales_person_wise_report	delete	2026-09-20 22:33:48.998-07	2026-09-20 22:33:48.998-07
57556	pos_retail	view	2026-10-12 22:41:25.886-07	2026-10-12 22:41:25.886-07
57557	pos_retail	create	2026-10-12 22:41:25.888-07	2026-10-12 22:41:25.888-07
57558	pos_retail	edit	2026-10-12 22:41:25.888-07	2026-10-12 22:41:25.888-07
57559	pos_retail	delete	2026-10-12 22:41:25.888-07	2026-10-12 22:41:25.888-07
57560	pos_supermarket	view	2026-10-12 22:41:25.888-07	2026-10-12 22:41:25.888-07
57561	pos_supermarket	create	2026-10-12 22:41:25.889-07	2026-10-12 22:41:25.889-07
57562	pos_supermarket	edit	2026-10-12 22:41:25.889-07	2026-10-12 22:41:25.889-07
57563	pos_supermarket	delete	2026-10-12 22:41:25.889-07	2026-10-12 22:41:25.889-07
57564	pos_restaurants	view	2026-10-12 22:41:25.889-07	2026-10-12 22:41:25.889-07
57565	pos_restaurants	create	2026-10-12 22:41:25.89-07	2026-10-12 22:41:25.89-07
57566	pos_restaurants	edit	2026-10-12 22:41:25.89-07	2026-10-12 22:41:25.89-07
57567	pos_restaurants	delete	2026-10-12 22:41:25.89-07	2026-10-12 22:41:25.89-07
57568	pos_pharmacy	view	2026-10-12 22:41:25.89-07	2026-10-12 22:41:25.89-07
57569	pos_pharmacy	create	2026-10-12 22:41:25.891-07	2026-10-12 22:41:25.891-07
57570	pos_pharmacy	edit	2026-10-12 22:41:25.891-07	2026-10-12 22:41:25.891-07
57571	pos_pharmacy	delete	2026-10-12 22:41:25.891-07	2026-10-12 22:41:25.891-07
57572	pos_electronics	view	2026-10-12 22:41:25.891-07	2026-10-12 22:41:25.891-07
57573	pos_electronics	create	2026-10-12 22:41:25.892-07	2026-10-12 22:41:25.892-07
57574	pos_electronics	edit	2026-10-12 22:41:25.892-07	2026-10-12 22:41:25.892-07
57575	pos_electronics	delete	2026-10-12 22:41:25.892-07	2026-10-12 22:41:25.892-07
57820	pos_reports	view	2026-10-12 23:24:47.222-07	2026-10-12 23:24:47.222-07
57821	pos_reports	create	2026-10-12 23:24:47.223-07	2026-10-12 23:24:47.223-07
57822	pos_reports	edit	2026-10-12 23:24:47.223-07	2026-10-12 23:24:47.223-07
57823	pos_reports	delete	2026-10-12 23:24:47.224-07	2026-10-12 23:24:47.224-07
66696	vendor_proforma_invoices	view	2026-10-20 21:08:14.534-07	2026-10-20 21:08:14.534-07
66697	vendor_proforma_invoices	create	2026-10-20 21:08:14.536-07	2026-10-20 21:08:14.536-07
66698	vendor_proforma_invoices	edit	2026-10-20 21:08:14.536-07	2026-10-20 21:08:14.536-07
66699	vendor_proforma_invoices	delete	2026-10-20 21:08:14.537-07	2026-10-20 21:08:14.537-07
\.


--
-- Data for Name: pos_sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_sales (id, company_id, channel, pos_number, sales_person_id, sales_person_name, created_by, payload, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: proforma_invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proforma_invoices (id, pi_number, company_id, customer_name, customer_address, customer_contact, customer_contact_email, delivery_address, issue_date, delivery_date, payment_terms, notes, is_private, items, subtotal, discount_amount, tax, total_amount, currency, qt_ref_no, status, email_sent_to, created_by, created_at, terms_and_conditions, delivery_instructions, customer_note, authorised_signature) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, company_id, name, code, description, status, budget, start_date, end_date, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_orders (id, po_number, company_id, vendor_name, vendor_address, vendor_contact, vendor_contact_email, delivery_address, issue_date, delivery_date, payment_terms, quote_ref_no, notes, is_private, items, subtotal, tax, total_amount, currency, status, customer_id, customer_po_ref, email_sent_to, ack_token, ack_at, ack_note, created_by, created_at, attachment_path, attachment_name) FROM stdin;
\.


--
-- Data for Name: purchase_quotations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_quotations (id, pq_number, company_id, vendor_name, vendor_address, vendor_contact, vendor_contact_email, delivery_address, issue_date, delivery_date, payment_terms, notes, is_private, items, subtotal, discount_amount, tax, total_amount, currency, status, email_sent_to, converted_po_id, converted_po_number, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: quotations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotations (id, qt_number, company_id, customer_name, customer_address, customer_contact, customer_contact_email, delivery_address, issue_date, delivery_date, payment_terms, notes, is_private, items, subtotal, discount_amount, tax, total_amount, currency, status, email_sent_to, created_by, created_at, terms_and_conditions, delivery_instructions, customer_note, authorised_signature, valid_until, sales_person) FROM stdin;
\.


--
-- Data for Name: report_definitions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_definitions (id, module, report_type, name, description, is_system, is_active, created_at, updated_at) FROM stdin;
1	quotations	quotation	Quotation	Sales quotation document	t	t	2026-10-26 21:10:32.520975-07	2026-10-26 22:20:25.697-07
2	sales_orders	sales-order	Sales Order	Sales order document	t	t	2026-10-26 21:10:32.544863-07	2026-10-26 22:20:25.721-07
3	proforma_invoices	proforma-invoice	Proforma Invoice	Proforma invoice document	t	t	2026-10-26 21:10:32.562591-07	2026-10-26 22:20:25.728-07
4	invoices	invoice	Tax Invoice	Tax invoice document	t	t	2026-10-26 21:10:32.57891-07	2026-10-26 22:20:25.733-07
5	credit_notes	credit-note	Credit Note	Credit note document	t	t	2026-10-26 21:10:32.594917-07	2026-10-26 22:20:25.739-07
6	debit_notes	debit-note	Debit Note	Debit note document	t	t	2026-10-26 21:10:32.610957-07	2026-10-26 22:20:25.745-07
7	delivery_orders	delivery-order	Delivery Order	Delivery order document	t	t	2026-10-26 21:10:32.628269-07	2026-10-26 22:20:25.753-07
8	purchase_quotations	purchase-quotation	Purchase Quotation	Purchase quotation document	t	t	2026-10-26 21:10:32.645315-07	2026-10-26 22:20:25.759-07
9	purchase_orders	purchase-order	Purchase Order	Purchase order document	t	t	2026-10-26 21:10:32.661238-07	2026-10-26 22:20:25.763-07
10	vendor_invoices	vendor-invoice	Vendor Invoice	Vendor invoice document	t	t	2026-10-26 21:10:32.682314-07	2026-10-26 22:20:25.768-07
11	grn	grn	Goods Receipt Note	Goods receipt note document	t	t	2026-10-26 21:10:32.70426-07	2026-10-26 22:20:25.771-07
\.


--
-- Data for Name: report_fields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_fields (id, report_definition_id, field_key, field_label, field_group, data_type, is_repeatable, is_active, created_at, updated_at) FROM stdin;
1	1	company.name	Company Name	Company	string	f	t	2026-10-26 21:10:32.523034-07	2026-10-26 21:10:32.523034-07
2	1	company.logo	Company Logo	Company	image	f	t	2026-10-26 21:10:32.524036-07	2026-10-26 21:10:32.524036-07
3	1	company.address	Company Address	Company	string	f	t	2026-10-26 21:10:32.524486-07	2026-10-26 21:10:32.524486-07
4	1	company.country	Company Country	Company	string	f	t	2026-10-26 21:10:32.52502-07	2026-10-26 21:10:32.52502-07
5	1	company.phone	Company Phone	Company	string	f	t	2026-10-26 21:10:32.525537-07	2026-10-26 21:10:32.525537-07
6	1	company.email	Company Email	Company	string	f	t	2026-10-26 21:10:32.526169-07	2026-10-26 21:10:32.526169-07
7	1	company.website	Company Website	Company	string	f	t	2026-10-26 21:10:32.526739-07	2026-10-26 21:10:32.526739-07
8	1	company.tax_number	Company Tax Number	Company	string	f	t	2026-10-26 21:10:32.52735-07	2026-10-26 21:10:32.52735-07
9	1	company.registration_number	Registration Number	Company	string	f	t	2026-10-26 21:10:32.527801-07	2026-10-26 21:10:32.527801-07
10	1	company.bank_details	Bank Details	Company	string	f	t	2026-10-26 21:10:32.528253-07	2026-10-26 21:10:32.528253-07
11	1	company.terms	Terms & Conditions	Company	string	f	t	2026-10-26 21:10:32.528803-07	2026-10-26 21:10:32.528803-07
12	1	company.gst_rate	GST Rate	Company	string	f	t	2026-10-26 21:10:32.529273-07	2026-10-26 21:10:32.529273-07
13	1	invoice.invoice_number	QT Number	Quotation	string	f	t	2026-10-26 21:10:32.529642-07	2026-10-26 21:10:32.529642-07
14	1	invoice.invoice_date	QT Date	Quotation	date	f	t	2026-10-26 21:10:32.529979-07	2026-10-26 21:10:32.529979-07
15	1	invoice.delivery_date	Delivery Date	Quotation	date	f	t	2026-10-26 21:10:32.530274-07	2026-10-26 21:10:32.530274-07
16	1	invoice.payment_terms	Payment Terms	Quotation	string	f	t	2026-10-26 21:10:32.530569-07	2026-10-26 21:10:32.530569-07
17	1	invoice.po_ref	PO Reference	Quotation	string	f	t	2026-10-26 21:10:32.530864-07	2026-10-26 21:10:32.530864-07
18	1	invoice.notes	Notes	Quotation	string	f	t	2026-10-26 21:10:32.531146-07	2026-10-26 21:10:32.531146-07
19	1	invoice.customer_note	Customer Note	Quotation	string	f	t	2026-10-26 21:10:32.531421-07	2026-10-26 21:10:32.531421-07
20	1	invoice.delivery_instructions	Delivery Instructions	Quotation	string	f	t	2026-10-26 21:10:32.531707-07	2026-10-26 21:10:32.531707-07
21	1	invoice.terms_and_conditions	Terms & Conditions	Quotation	string	f	t	2026-10-26 21:10:32.532419-07	2026-10-26 21:10:32.532419-07
22	1	invoice.authorised_signature	Authorised Signature	Quotation	image	f	t	2026-10-26 21:10:32.532842-07	2026-10-26 21:10:32.532842-07
23	1	invoice.subtotal	Subtotal	Quotation	currency	f	t	2026-10-26 21:10:32.533122-07	2026-10-26 21:10:32.533122-07
24	1	invoice.discount	Discount	Quotation	currency	f	t	2026-10-26 21:10:32.533495-07	2026-10-26 21:10:32.533495-07
25	1	invoice.tax	Tax	Quotation	currency	f	t	2026-10-26 21:10:32.533908-07	2026-10-26 21:10:32.533908-07
26	1	invoice.tax_label	GST Label	Quotation	string	f	t	2026-10-26 21:10:32.534371-07	2026-10-26 21:10:32.534371-07
27	1	invoice.total	Total	Quotation	currency	f	t	2026-10-26 21:10:32.534874-07	2026-10-26 21:10:32.534874-07
28	1	invoice.currency	Currency	Quotation	string	f	t	2026-10-26 21:10:32.535304-07	2026-10-26 21:10:32.535304-07
29	1	invoice.status	Status	Quotation	string	f	t	2026-10-26 21:10:32.535709-07	2026-10-26 21:10:32.535709-07
30	1	customer.name	Customer Name	Customer	string	f	t	2026-10-26 21:10:32.536024-07	2026-10-26 21:10:32.536024-07
31	1	customer.address	Customer Address	Customer	string	f	t	2026-10-26 21:10:32.536298-07	2026-10-26 21:10:32.536298-07
32	1	customer.email	Customer Email	Customer	string	f	t	2026-10-26 21:10:32.53661-07	2026-10-26 21:10:32.53661-07
33	1	customer.phone	Customer Phone	Customer	string	f	t	2026-10-26 21:10:32.53701-07	2026-10-26 21:10:32.53701-07
34	1	customer.tax_number	Customer Tax Number	Customer	string	f	t	2026-10-26 21:10:32.537338-07	2026-10-26 21:10:32.537338-07
35	1	customer.contact_person	Contact Person	Customer	string	f	t	2026-10-26 21:10:32.537634-07	2026-10-26 21:10:32.537634-07
36	1	customer.postal_code	Postal Code	Customer	string	f	t	2026-10-26 21:10:32.537931-07	2026-10-26 21:10:32.537931-07
37	1	customer.country	Customer Country	Customer	string	f	t	2026-10-26 21:10:32.538191-07	2026-10-26 21:10:32.538191-07
38	1	customer.ship_to_address	Ship To Address	Customer	string	f	t	2026-10-26 21:10:32.538431-07	2026-10-26 21:10:32.538431-07
39	1	item.index	#	Items	number	t	t	2026-10-26 21:10:32.538679-07	2026-10-26 21:10:32.538679-07
40	1	item.product_name	Product	Items	string	t	t	2026-10-26 21:10:32.539-07	2026-10-26 21:10:32.539-07
41	1	item.description	Description	Items	string	t	t	2026-10-26 21:10:32.539337-07	2026-10-26 21:10:32.539337-07
42	1	item.quantity	Quantity	Items	number	t	t	2026-10-26 21:10:32.539635-07	2026-10-26 21:10:32.539635-07
43	1	item.uom	UOM	Items	string	t	t	2026-10-26 21:10:32.539888-07	2026-10-26 21:10:32.539888-07
44	1	item.unit_price	Unit Price	Items	currency	t	t	2026-10-26 21:10:32.540132-07	2026-10-26 21:10:32.540132-07
45	1	item.discount	Item Discount	Items	number	t	t	2026-10-26 21:10:32.540387-07	2026-10-26 21:10:32.540387-07
46	1	item.tax	Item Tax	Items	number	t	t	2026-10-26 21:10:32.540692-07	2026-10-26 21:10:32.540692-07
47	1	item.amount	Amount	Items	currency	t	t	2026-10-26 21:10:32.540939-07	2026-10-26 21:10:32.540939-07
48	2	company.name	Company Name	Company	string	f	t	2026-10-26 21:10:32.545558-07	2026-10-26 21:10:32.545558-07
49	2	company.logo	Company Logo	Company	image	f	t	2026-10-26 21:10:32.545841-07	2026-10-26 21:10:32.545841-07
50	2	company.address	Company Address	Company	string	f	t	2026-10-26 21:10:32.546125-07	2026-10-26 21:10:32.546125-07
51	2	company.country	Company Country	Company	string	f	t	2026-10-26 21:10:32.546368-07	2026-10-26 21:10:32.546368-07
52	2	company.phone	Company Phone	Company	string	f	t	2026-10-26 21:10:32.54664-07	2026-10-26 21:10:32.54664-07
53	2	company.email	Company Email	Company	string	f	t	2026-10-26 21:10:32.547178-07	2026-10-26 21:10:32.547178-07
54	2	company.website	Company Website	Company	string	f	t	2026-10-26 21:10:32.547475-07	2026-10-26 21:10:32.547475-07
55	2	company.tax_number	Company Tax Number	Company	string	f	t	2026-10-26 21:10:32.547795-07	2026-10-26 21:10:32.547795-07
56	2	company.registration_number	Registration Number	Company	string	f	t	2026-10-26 21:10:32.548087-07	2026-10-26 21:10:32.548087-07
57	2	company.bank_details	Bank Details	Company	string	f	t	2026-10-26 21:10:32.54836-07	2026-10-26 21:10:32.54836-07
58	2	company.terms	Terms & Conditions	Company	string	f	t	2026-10-26 21:10:32.548668-07	2026-10-26 21:10:32.548668-07
59	2	company.gst_rate	GST Rate	Company	string	f	t	2026-10-26 21:10:32.548945-07	2026-10-26 21:10:32.548945-07
60	2	invoice.invoice_number	SO Number	Sales Order	string	f	t	2026-10-26 21:10:32.549186-07	2026-10-26 21:10:32.549186-07
61	2	invoice.invoice_date	SO Date	Sales Order	date	f	t	2026-10-26 21:10:32.549416-07	2026-10-26 21:10:32.549416-07
62	2	invoice.delivery_date	Delivery Date	Sales Order	date	f	t	2026-10-26 21:10:32.549641-07	2026-10-26 21:10:32.549641-07
63	2	invoice.payment_terms	Payment Terms	Sales Order	string	f	t	2026-10-26 21:10:32.549946-07	2026-10-26 21:10:32.549946-07
64	2	invoice.po_ref	PO Reference	Sales Order	string	f	t	2026-10-26 21:10:32.550384-07	2026-10-26 21:10:32.550384-07
65	2	invoice.notes	Notes	Sales Order	string	f	t	2026-10-26 21:10:32.550828-07	2026-10-26 21:10:32.550828-07
66	2	invoice.customer_note	Customer Note	Sales Order	string	f	t	2026-10-26 21:10:32.551182-07	2026-10-26 21:10:32.551182-07
67	2	invoice.delivery_instructions	Delivery Instructions	Sales Order	string	f	t	2026-10-26 21:10:32.55154-07	2026-10-26 21:10:32.55154-07
68	2	invoice.terms_and_conditions	Terms & Conditions	Sales Order	string	f	t	2026-10-26 21:10:32.551852-07	2026-10-26 21:10:32.551852-07
69	2	invoice.authorised_signature	Authorised Signature	Sales Order	image	f	t	2026-10-26 21:10:32.552164-07	2026-10-26 21:10:32.552164-07
70	2	invoice.subtotal	Subtotal	Sales Order	currency	f	t	2026-10-26 21:10:32.552439-07	2026-10-26 21:10:32.552439-07
71	2	invoice.discount	Discount	Sales Order	currency	f	t	2026-10-26 21:10:32.552772-07	2026-10-26 21:10:32.552772-07
72	2	invoice.tax	Tax	Sales Order	currency	f	t	2026-10-26 21:10:32.553131-07	2026-10-26 21:10:32.553131-07
73	2	invoice.tax_label	GST Label	Sales Order	string	f	t	2026-10-26 21:10:32.553414-07	2026-10-26 21:10:32.553414-07
74	2	invoice.total	Total	Sales Order	currency	f	t	2026-10-26 21:10:32.553713-07	2026-10-26 21:10:32.553713-07
75	2	invoice.currency	Currency	Sales Order	string	f	t	2026-10-26 21:10:32.553966-07	2026-10-26 21:10:32.553966-07
76	2	invoice.status	Status	Sales Order	string	f	t	2026-10-26 21:10:32.554202-07	2026-10-26 21:10:32.554202-07
77	2	customer.name	Customer Name	Customer	string	f	t	2026-10-26 21:10:32.554437-07	2026-10-26 21:10:32.554437-07
78	2	customer.address	Customer Address	Customer	string	f	t	2026-10-26 21:10:32.554666-07	2026-10-26 21:10:32.554666-07
79	2	customer.email	Customer Email	Customer	string	f	t	2026-10-26 21:10:32.555728-07	2026-10-26 21:10:32.555728-07
80	2	customer.phone	Customer Phone	Customer	string	f	t	2026-10-26 21:10:32.556039-07	2026-10-26 21:10:32.556039-07
81	2	customer.tax_number	Customer Tax Number	Customer	string	f	t	2026-10-26 21:10:32.556337-07	2026-10-26 21:10:32.556337-07
82	2	customer.contact_person	Contact Person	Customer	string	f	t	2026-10-26 21:10:32.556724-07	2026-10-26 21:10:32.556724-07
83	2	customer.postal_code	Postal Code	Customer	string	f	t	2026-10-26 21:10:32.557084-07	2026-10-26 21:10:32.557084-07
84	2	customer.country	Customer Country	Customer	string	f	t	2026-10-26 21:10:32.557476-07	2026-10-26 21:10:32.557476-07
85	2	customer.ship_to_address	Ship To Address	Customer	string	f	t	2026-10-26 21:10:32.557773-07	2026-10-26 21:10:32.557773-07
86	2	item.index	#	Items	number	t	t	2026-10-26 21:10:32.558058-07	2026-10-26 21:10:32.558058-07
87	2	item.product_name	Product	Items	string	t	t	2026-10-26 21:10:32.558295-07	2026-10-26 21:10:32.558295-07
88	2	item.description	Description	Items	string	t	t	2026-10-26 21:10:32.558524-07	2026-10-26 21:10:32.558524-07
89	2	item.quantity	Quantity	Items	number	t	t	2026-10-26 21:10:32.558753-07	2026-10-26 21:10:32.558753-07
90	2	item.uom	UOM	Items	string	t	t	2026-10-26 21:10:32.559055-07	2026-10-26 21:10:32.559055-07
91	2	item.unit_price	Unit Price	Items	currency	t	t	2026-10-26 21:10:32.559364-07	2026-10-26 21:10:32.559364-07
92	2	item.discount	Item Discount	Items	number	t	t	2026-10-26 21:10:32.559669-07	2026-10-26 21:10:32.559669-07
93	2	item.tax	Item Tax	Items	number	t	t	2026-10-26 21:10:32.559987-07	2026-10-26 21:10:32.559987-07
94	2	item.amount	Amount	Items	currency	t	t	2026-10-26 21:10:32.560358-07	2026-10-26 21:10:32.560358-07
95	3	company.name	Company Name	Company	string	f	t	2026-10-26 21:10:32.563297-07	2026-10-26 21:10:32.563297-07
96	3	company.logo	Company Logo	Company	image	f	t	2026-10-26 21:10:32.563644-07	2026-10-26 21:10:32.563644-07
97	3	company.address	Company Address	Company	string	f	t	2026-10-26 21:10:32.563912-07	2026-10-26 21:10:32.563912-07
98	3	company.country	Company Country	Company	string	f	t	2026-10-26 21:10:32.56419-07	2026-10-26 21:10:32.56419-07
99	3	company.phone	Company Phone	Company	string	f	t	2026-10-26 21:10:32.564461-07	2026-10-26 21:10:32.564461-07
100	3	company.email	Company Email	Company	string	f	t	2026-10-26 21:10:32.564761-07	2026-10-26 21:10:32.564761-07
101	3	company.website	Company Website	Company	string	f	t	2026-10-26 21:10:32.565054-07	2026-10-26 21:10:32.565054-07
102	3	company.tax_number	Company Tax Number	Company	string	f	t	2026-10-26 21:10:32.565322-07	2026-10-26 21:10:32.565322-07
103	3	company.registration_number	Registration Number	Company	string	f	t	2026-10-26 21:10:32.565561-07	2026-10-26 21:10:32.565561-07
104	3	company.bank_details	Bank Details	Company	string	f	t	2026-10-26 21:10:32.565787-07	2026-10-26 21:10:32.565787-07
105	3	company.terms	Terms & Conditions	Company	string	f	t	2026-10-26 21:10:32.566012-07	2026-10-26 21:10:32.566012-07
106	3	company.gst_rate	GST Rate	Company	string	f	t	2026-10-26 21:10:32.566247-07	2026-10-26 21:10:32.566247-07
107	3	invoice.invoice_number	PI Number	Proforma Invoice	string	f	t	2026-10-26 21:10:32.566518-07	2026-10-26 21:10:32.566518-07
108	3	invoice.invoice_date	PI Date	Proforma Invoice	date	f	t	2026-10-26 21:10:32.567062-07	2026-10-26 21:10:32.567062-07
109	3	invoice.delivery_date	Delivery Date	Proforma Invoice	date	f	t	2026-10-26 21:10:32.567486-07	2026-10-26 21:10:32.567486-07
110	3	invoice.payment_terms	Payment Terms	Proforma Invoice	string	f	t	2026-10-26 21:10:32.567852-07	2026-10-26 21:10:32.567852-07
111	3	invoice.po_ref	PO Reference	Proforma Invoice	string	f	t	2026-10-26 21:10:32.568174-07	2026-10-26 21:10:32.568174-07
112	3	invoice.notes	Notes	Proforma Invoice	string	f	t	2026-10-26 21:10:32.568567-07	2026-10-26 21:10:32.568567-07
113	3	invoice.customer_note	Customer Note	Proforma Invoice	string	f	t	2026-10-26 21:10:32.568934-07	2026-10-26 21:10:32.568934-07
114	3	invoice.delivery_instructions	Delivery Instructions	Proforma Invoice	string	f	t	2026-10-26 21:10:32.569226-07	2026-10-26 21:10:32.569226-07
115	3	invoice.terms_and_conditions	Terms & Conditions	Proforma Invoice	string	f	t	2026-10-26 21:10:32.569476-07	2026-10-26 21:10:32.569476-07
116	3	invoice.authorised_signature	Authorised Signature	Proforma Invoice	image	f	t	2026-10-26 21:10:32.569719-07	2026-10-26 21:10:32.569719-07
117	3	invoice.subtotal	Subtotal	Proforma Invoice	currency	f	t	2026-10-26 21:10:32.569949-07	2026-10-26 21:10:32.569949-07
118	3	invoice.discount	Discount	Proforma Invoice	currency	f	t	2026-10-26 21:10:32.570185-07	2026-10-26 21:10:32.570185-07
119	3	invoice.tax	Tax	Proforma Invoice	currency	f	t	2026-10-26 21:10:32.570415-07	2026-10-26 21:10:32.570415-07
120	3	invoice.tax_label	GST Label	Proforma Invoice	string	f	t	2026-10-26 21:10:32.570682-07	2026-10-26 21:10:32.570682-07
121	3	invoice.total	Total	Proforma Invoice	currency	f	t	2026-10-26 21:10:32.570971-07	2026-10-26 21:10:32.570971-07
122	3	invoice.currency	Currency	Proforma Invoice	string	f	t	2026-10-26 21:10:32.571205-07	2026-10-26 21:10:32.571205-07
123	3	invoice.status	Status	Proforma Invoice	string	f	t	2026-10-26 21:10:32.571488-07	2026-10-26 21:10:32.571488-07
124	3	customer.name	Customer Name	Customer	string	f	t	2026-10-26 21:10:32.571742-07	2026-10-26 21:10:32.571742-07
125	3	customer.address	Customer Address	Customer	string	f	t	2026-10-26 21:10:32.572095-07	2026-10-26 21:10:32.572095-07
126	3	customer.email	Customer Email	Customer	string	f	t	2026-10-26 21:10:32.572414-07	2026-10-26 21:10:32.572414-07
127	3	customer.phone	Customer Phone	Customer	string	f	t	2026-10-26 21:10:32.572728-07	2026-10-26 21:10:32.572728-07
128	3	customer.tax_number	Customer Tax Number	Customer	string	f	t	2026-10-26 21:10:32.572999-07	2026-10-26 21:10:32.572999-07
129	3	customer.contact_person	Contact Person	Customer	string	f	t	2026-10-26 21:10:32.573257-07	2026-10-26 21:10:32.573257-07
130	3	customer.postal_code	Postal Code	Customer	string	f	t	2026-10-26 21:10:32.573493-07	2026-10-26 21:10:32.573493-07
131	3	customer.country	Customer Country	Customer	string	f	t	2026-10-26 21:10:32.573726-07	2026-10-26 21:10:32.573726-07
132	3	customer.ship_to_address	Ship To Address	Customer	string	f	t	2026-10-26 21:10:32.573998-07	2026-10-26 21:10:32.573998-07
133	3	item.index	#	Items	number	t	t	2026-10-26 21:10:32.57427-07	2026-10-26 21:10:32.57427-07
134	3	item.product_name	Product	Items	string	t	t	2026-10-26 21:10:32.574554-07	2026-10-26 21:10:32.574554-07
135	3	item.description	Description	Items	string	t	t	2026-10-26 21:10:32.574852-07	2026-10-26 21:10:32.574852-07
136	3	item.quantity	Quantity	Items	number	t	t	2026-10-26 21:10:32.575127-07	2026-10-26 21:10:32.575127-07
137	3	item.uom	UOM	Items	string	t	t	2026-10-26 21:10:32.575381-07	2026-10-26 21:10:32.575381-07
138	3	item.unit_price	Unit Price	Items	currency	t	t	2026-10-26 21:10:32.575619-07	2026-10-26 21:10:32.575619-07
139	3	item.discount	Item Discount	Items	number	t	t	2026-10-26 21:10:32.575847-07	2026-10-26 21:10:32.575847-07
140	3	item.tax	Item Tax	Items	number	t	t	2026-10-26 21:10:32.576075-07	2026-10-26 21:10:32.576075-07
141	3	item.amount	Amount	Items	currency	t	t	2026-10-26 21:10:32.5763-07	2026-10-26 21:10:32.5763-07
142	4	company.name	Company Name	Company	string	f	t	2026-10-26 21:10:32.579531-07	2026-10-26 21:10:32.579531-07
143	4	company.logo	Company Logo	Company	image	f	t	2026-10-26 21:10:32.579895-07	2026-10-26 21:10:32.579895-07
144	4	company.address	Company Address	Company	string	f	t	2026-10-26 21:10:32.580207-07	2026-10-26 21:10:32.580207-07
145	4	company.country	Company Country	Company	string	f	t	2026-10-26 21:10:32.580481-07	2026-10-26 21:10:32.580481-07
146	4	company.phone	Company Phone	Company	string	f	t	2026-10-26 21:10:32.580816-07	2026-10-26 21:10:32.580816-07
147	4	company.email	Company Email	Company	string	f	t	2026-10-26 21:10:32.581082-07	2026-10-26 21:10:32.581082-07
148	4	company.website	Company Website	Company	string	f	t	2026-10-26 21:10:32.581367-07	2026-10-26 21:10:32.581367-07
149	4	company.tax_number	Company Tax Number	Company	string	f	t	2026-10-26 21:10:32.581757-07	2026-10-26 21:10:32.581757-07
150	4	company.registration_number	Registration Number	Company	string	f	t	2026-10-26 21:10:32.582058-07	2026-10-26 21:10:32.582058-07
151	4	company.bank_details	Bank Details	Company	string	f	t	2026-10-26 21:10:32.58235-07	2026-10-26 21:10:32.58235-07
152	4	company.terms	Terms & Conditions	Company	string	f	t	2026-10-26 21:10:32.58265-07	2026-10-26 21:10:32.58265-07
153	4	company.gst_rate	GST Rate	Company	string	f	t	2026-10-26 21:10:32.582935-07	2026-10-26 21:10:32.582935-07
154	4	invoice.invoice_number	INV Number	Tax Invoice	string	f	t	2026-10-26 21:10:32.583245-07	2026-10-26 21:10:32.583245-07
155	4	invoice.invoice_date	INV Date	Tax Invoice	date	f	t	2026-10-26 21:10:32.583531-07	2026-10-26 21:10:32.583531-07
156	4	invoice.delivery_date	Delivery Date	Tax Invoice	date	f	t	2026-10-26 21:10:32.584268-07	2026-10-26 21:10:32.584268-07
157	4	invoice.payment_terms	Payment Terms	Tax Invoice	string	f	t	2026-10-26 21:10:32.584777-07	2026-10-26 21:10:32.584777-07
158	4	invoice.po_ref	PO Reference	Tax Invoice	string	f	t	2026-10-26 21:10:32.585292-07	2026-10-26 21:10:32.585292-07
159	4	invoice.notes	Notes	Tax Invoice	string	f	t	2026-10-26 21:10:32.585646-07	2026-10-26 21:10:32.585646-07
160	4	invoice.customer_note	Customer Note	Tax Invoice	string	f	t	2026-10-26 21:10:32.585917-07	2026-10-26 21:10:32.585917-07
161	4	invoice.delivery_instructions	Delivery Instructions	Tax Invoice	string	f	t	2026-10-26 21:10:32.586159-07	2026-10-26 21:10:32.586159-07
162	4	invoice.terms_and_conditions	Terms & Conditions	Tax Invoice	string	f	t	2026-10-26 21:10:32.586457-07	2026-10-26 21:10:32.586457-07
163	4	invoice.authorised_signature	Authorised Signature	Tax Invoice	image	f	t	2026-10-26 21:10:32.586787-07	2026-10-26 21:10:32.586787-07
164	4	invoice.subtotal	Subtotal	Tax Invoice	currency	f	t	2026-10-26 21:10:32.58708-07	2026-10-26 21:10:32.58708-07
165	4	invoice.discount	Discount	Tax Invoice	currency	f	t	2026-10-26 21:10:32.587313-07	2026-10-26 21:10:32.587313-07
166	4	invoice.tax	Tax	Tax Invoice	currency	f	t	2026-10-26 21:10:32.587539-07	2026-10-26 21:10:32.587539-07
167	4	invoice.tax_label	GST Label	Tax Invoice	string	f	t	2026-10-26 21:10:32.58777-07	2026-10-26 21:10:32.58777-07
168	4	invoice.total	Total	Tax Invoice	currency	f	t	2026-10-26 21:10:32.588-07	2026-10-26 21:10:32.588-07
169	4	invoice.currency	Currency	Tax Invoice	string	f	t	2026-10-26 21:10:32.588234-07	2026-10-26 21:10:32.588234-07
170	4	invoice.status	Status	Tax Invoice	string	f	t	2026-10-26 21:10:32.588471-07	2026-10-26 21:10:32.588471-07
171	4	customer.name	Customer Name	Customer	string	f	t	2026-10-26 21:10:32.588788-07	2026-10-26 21:10:32.588788-07
172	4	customer.address	Customer Address	Customer	string	f	t	2026-10-26 21:10:32.589065-07	2026-10-26 21:10:32.589065-07
173	4	customer.email	Customer Email	Customer	string	f	t	2026-10-26 21:10:32.589309-07	2026-10-26 21:10:32.589309-07
174	4	customer.phone	Customer Phone	Customer	string	f	t	2026-10-26 21:10:32.589539-07	2026-10-26 21:10:32.589539-07
175	4	customer.tax_number	Customer Tax Number	Customer	string	f	t	2026-10-26 21:10:32.589779-07	2026-10-26 21:10:32.589779-07
176	4	customer.contact_person	Contact Person	Customer	string	f	t	2026-10-26 21:10:32.59001-07	2026-10-26 21:10:32.59001-07
177	4	customer.postal_code	Postal Code	Customer	string	f	t	2026-10-26 21:10:32.590236-07	2026-10-26 21:10:32.590236-07
178	4	customer.country	Customer Country	Customer	string	f	t	2026-10-26 21:10:32.590461-07	2026-10-26 21:10:32.590461-07
179	4	customer.ship_to_address	Ship To Address	Customer	string	f	t	2026-10-26 21:10:32.590689-07	2026-10-26 21:10:32.590689-07
180	4	item.index	#	Items	number	t	t	2026-10-26 21:10:32.590923-07	2026-10-26 21:10:32.590923-07
181	4	item.product_name	Product	Items	string	t	t	2026-10-26 21:10:32.591165-07	2026-10-26 21:10:32.591165-07
182	4	item.description	Description	Items	string	t	t	2026-10-26 21:10:32.591459-07	2026-10-26 21:10:32.591459-07
183	4	item.quantity	Quantity	Items	number	t	t	2026-10-26 21:10:32.591686-07	2026-10-26 21:10:32.591686-07
184	4	item.uom	UOM	Items	string	t	t	2026-10-26 21:10:32.591952-07	2026-10-26 21:10:32.591952-07
185	4	item.unit_price	Unit Price	Items	currency	t	t	2026-10-26 21:10:32.592198-07	2026-10-26 21:10:32.592198-07
186	4	item.discount	Item Discount	Items	number	t	t	2026-10-26 21:10:32.592438-07	2026-10-26 21:10:32.592438-07
187	4	item.tax	Item Tax	Items	number	t	t	2026-10-26 21:10:32.592761-07	2026-10-26 21:10:32.592761-07
188	4	item.amount	Amount	Items	currency	t	t	2026-10-26 21:10:32.593024-07	2026-10-26 21:10:32.593024-07
189	5	company.name	Company Name	Company	string	f	t	2026-10-26 21:10:32.595596-07	2026-10-26 21:10:32.595596-07
190	5	company.logo	Company Logo	Company	image	f	t	2026-10-26 21:10:32.595979-07	2026-10-26 21:10:32.595979-07
191	5	company.address	Company Address	Company	string	f	t	2026-10-26 21:10:32.596566-07	2026-10-26 21:10:32.596566-07
192	5	company.country	Company Country	Company	string	f	t	2026-10-26 21:10:32.59687-07	2026-10-26 21:10:32.59687-07
193	5	company.phone	Company Phone	Company	string	f	t	2026-10-26 21:10:32.597137-07	2026-10-26 21:10:32.597137-07
194	5	company.email	Company Email	Company	string	f	t	2026-10-26 21:10:32.597393-07	2026-10-26 21:10:32.597393-07
195	5	company.website	Company Website	Company	string	f	t	2026-10-26 21:10:32.597664-07	2026-10-26 21:10:32.597664-07
196	5	company.tax_number	Company Tax Number	Company	string	f	t	2026-10-26 21:10:32.598206-07	2026-10-26 21:10:32.598206-07
197	5	company.registration_number	Registration Number	Company	string	f	t	2026-10-26 21:10:32.59852-07	2026-10-26 21:10:32.59852-07
198	5	company.bank_details	Bank Details	Company	string	f	t	2026-10-26 21:10:32.598781-07	2026-10-26 21:10:32.598781-07
199	5	company.terms	Terms & Conditions	Company	string	f	t	2026-10-26 21:10:32.599025-07	2026-10-26 21:10:32.599025-07
200	5	company.gst_rate	GST Rate	Company	string	f	t	2026-10-26 21:10:32.599259-07	2026-10-26 21:10:32.599259-07
201	5	invoice.invoice_number	CN Number	Credit Note	string	f	t	2026-10-26 21:10:32.599495-07	2026-10-26 21:10:32.599495-07
202	5	invoice.invoice_date	CN Date	Credit Note	date	f	t	2026-10-26 21:10:32.599728-07	2026-10-26 21:10:32.599728-07
203	5	invoice.delivery_date	Delivery Date	Credit Note	date	f	t	2026-10-26 21:10:32.600022-07	2026-10-26 21:10:32.600022-07
204	5	invoice.payment_terms	Payment Terms	Credit Note	string	f	t	2026-10-26 21:10:32.600356-07	2026-10-26 21:10:32.600356-07
205	5	invoice.po_ref	PO Reference	Credit Note	string	f	t	2026-10-26 21:10:32.600823-07	2026-10-26 21:10:32.600823-07
206	5	invoice.notes	Notes	Credit Note	string	f	t	2026-10-26 21:10:32.601247-07	2026-10-26 21:10:32.601247-07
207	5	invoice.customer_note	Customer Note	Credit Note	string	f	t	2026-10-26 21:10:32.60173-07	2026-10-26 21:10:32.60173-07
208	5	invoice.delivery_instructions	Delivery Instructions	Credit Note	string	f	t	2026-10-26 21:10:32.602079-07	2026-10-26 21:10:32.602079-07
209	5	invoice.terms_and_conditions	Terms & Conditions	Credit Note	string	f	t	2026-10-26 21:10:32.602348-07	2026-10-26 21:10:32.602348-07
210	5	invoice.authorised_signature	Authorised Signature	Credit Note	image	f	t	2026-10-26 21:10:32.602598-07	2026-10-26 21:10:32.602598-07
211	5	invoice.subtotal	Subtotal	Credit Note	currency	f	t	2026-10-26 21:10:32.60283-07	2026-10-26 21:10:32.60283-07
212	5	invoice.discount	Discount	Credit Note	currency	f	t	2026-10-26 21:10:32.603054-07	2026-10-26 21:10:32.603054-07
213	5	invoice.tax	Tax	Credit Note	currency	f	t	2026-10-26 21:10:32.603275-07	2026-10-26 21:10:32.603275-07
214	5	invoice.tax_label	GST Label	Credit Note	string	f	t	2026-10-26 21:10:32.603495-07	2026-10-26 21:10:32.603495-07
215	5	invoice.total	Total	Credit Note	currency	f	t	2026-10-26 21:10:32.603714-07	2026-10-26 21:10:32.603714-07
216	5	invoice.currency	Currency	Credit Note	string	f	t	2026-10-26 21:10:32.604227-07	2026-10-26 21:10:32.604227-07
217	5	invoice.status	Status	Credit Note	string	f	t	2026-10-26 21:10:32.604533-07	2026-10-26 21:10:32.604533-07
218	5	customer.name	Customer Name	Customer	string	f	t	2026-10-26 21:10:32.604786-07	2026-10-26 21:10:32.604786-07
219	5	customer.address	Customer Address	Customer	string	f	t	2026-10-26 21:10:32.605017-07	2026-10-26 21:10:32.605017-07
220	5	customer.email	Customer Email	Customer	string	f	t	2026-10-26 21:10:32.605242-07	2026-10-26 21:10:32.605242-07
221	5	customer.phone	Customer Phone	Customer	string	f	t	2026-10-26 21:10:32.605469-07	2026-10-26 21:10:32.605469-07
222	5	customer.tax_number	Customer Tax Number	Customer	string	f	t	2026-10-26 21:10:32.605694-07	2026-10-26 21:10:32.605694-07
223	5	customer.contact_person	Contact Person	Customer	string	f	t	2026-10-26 21:10:32.605916-07	2026-10-26 21:10:32.605916-07
224	5	customer.postal_code	Postal Code	Customer	string	f	t	2026-10-26 21:10:32.606197-07	2026-10-26 21:10:32.606197-07
225	5	customer.country	Customer Country	Customer	string	f	t	2026-10-26 21:10:32.606579-07	2026-10-26 21:10:32.606579-07
226	5	customer.ship_to_address	Ship To Address	Customer	string	f	t	2026-10-26 21:10:32.606913-07	2026-10-26 21:10:32.606913-07
227	5	item.index	#	Items	number	t	t	2026-10-26 21:10:32.607178-07	2026-10-26 21:10:32.607178-07
228	5	item.product_name	Product	Items	string	t	t	2026-10-26 21:10:32.607412-07	2026-10-26 21:10:32.607412-07
229	5	item.description	Description	Items	string	t	t	2026-10-26 21:10:32.607647-07	2026-10-26 21:10:32.607647-07
230	5	item.quantity	Quantity	Items	number	t	t	2026-10-26 21:10:32.607874-07	2026-10-26 21:10:32.607874-07
231	5	item.uom	UOM	Items	string	t	t	2026-10-26 21:10:32.608099-07	2026-10-26 21:10:32.608099-07
232	5	item.unit_price	Unit Price	Items	currency	t	t	2026-10-26 21:10:32.608323-07	2026-10-26 21:10:32.608323-07
233	5	item.discount	Item Discount	Items	number	t	t	2026-10-26 21:10:32.608616-07	2026-10-26 21:10:32.608616-07
234	5	item.tax	Item Tax	Items	number	t	t	2026-10-26 21:10:32.608842-07	2026-10-26 21:10:32.608842-07
235	5	item.amount	Amount	Items	currency	t	t	2026-10-26 21:10:32.609063-07	2026-10-26 21:10:32.609063-07
236	6	company.name	Company Name	Company	string	f	t	2026-10-26 21:10:32.611602-07	2026-10-26 21:10:32.611602-07
237	6	company.logo	Company Logo	Company	image	f	t	2026-10-26 21:10:32.611922-07	2026-10-26 21:10:32.611922-07
238	6	company.address	Company Address	Company	string	f	t	2026-10-26 21:10:32.612208-07	2026-10-26 21:10:32.612208-07
239	6	company.country	Company Country	Company	string	f	t	2026-10-26 21:10:32.612537-07	2026-10-26 21:10:32.612537-07
240	6	company.phone	Company Phone	Company	string	f	t	2026-10-26 21:10:32.612883-07	2026-10-26 21:10:32.612883-07
241	6	company.email	Company Email	Company	string	f	t	2026-10-26 21:10:32.613163-07	2026-10-26 21:10:32.613163-07
242	6	company.website	Company Website	Company	string	f	t	2026-10-26 21:10:32.613418-07	2026-10-26 21:10:32.613418-07
243	6	company.tax_number	Company Tax Number	Company	string	f	t	2026-10-26 21:10:32.613649-07	2026-10-26 21:10:32.613649-07
244	6	company.registration_number	Registration Number	Company	string	f	t	2026-10-26 21:10:32.613876-07	2026-10-26 21:10:32.613876-07
245	6	company.bank_details	Bank Details	Company	string	f	t	2026-10-26 21:10:32.614098-07	2026-10-26 21:10:32.614098-07
246	6	company.terms	Terms & Conditions	Company	string	f	t	2026-10-26 21:10:32.614325-07	2026-10-26 21:10:32.614325-07
247	6	company.gst_rate	GST Rate	Company	string	f	t	2026-10-26 21:10:32.614624-07	2026-10-26 21:10:32.614624-07
248	6	invoice.invoice_number	DN Number	Debit Note	string	f	t	2026-10-26 21:10:32.614942-07	2026-10-26 21:10:32.614942-07
249	6	invoice.invoice_date	DN Date	Debit Note	date	f	t	2026-10-26 21:10:32.615258-07	2026-10-26 21:10:32.615258-07
250	6	invoice.delivery_date	Delivery Date	Debit Note	date	f	t	2026-10-26 21:10:32.61549-07	2026-10-26 21:10:32.61549-07
251	6	invoice.payment_terms	Payment Terms	Debit Note	string	f	t	2026-10-26 21:10:32.615714-07	2026-10-26 21:10:32.615714-07
252	6	invoice.po_ref	PO Reference	Debit Note	string	f	t	2026-10-26 21:10:32.615944-07	2026-10-26 21:10:32.615944-07
253	6	invoice.notes	Notes	Debit Note	string	f	t	2026-10-26 21:10:32.616167-07	2026-10-26 21:10:32.616167-07
254	6	invoice.customer_note	Customer Note	Debit Note	string	f	t	2026-10-26 21:10:32.616419-07	2026-10-26 21:10:32.616419-07
255	6	invoice.delivery_instructions	Delivery Instructions	Debit Note	string	f	t	2026-10-26 21:10:32.616987-07	2026-10-26 21:10:32.616987-07
256	6	invoice.terms_and_conditions	Terms & Conditions	Debit Note	string	f	t	2026-10-26 21:10:32.61759-07	2026-10-26 21:10:32.61759-07
257	6	invoice.authorised_signature	Authorised Signature	Debit Note	image	f	t	2026-10-26 21:10:32.618231-07	2026-10-26 21:10:32.618231-07
258	6	invoice.subtotal	Subtotal	Debit Note	currency	f	t	2026-10-26 21:10:32.618751-07	2026-10-26 21:10:32.618751-07
259	6	invoice.discount	Discount	Debit Note	currency	f	t	2026-10-26 21:10:32.619226-07	2026-10-26 21:10:32.619226-07
260	6	invoice.tax	Tax	Debit Note	currency	f	t	2026-10-26 21:10:32.619532-07	2026-10-26 21:10:32.619532-07
261	6	invoice.tax_label	GST Label	Debit Note	string	f	t	2026-10-26 21:10:32.619788-07	2026-10-26 21:10:32.619788-07
262	6	invoice.total	Total	Debit Note	currency	f	t	2026-10-26 21:10:32.620034-07	2026-10-26 21:10:32.620034-07
263	6	invoice.currency	Currency	Debit Note	string	f	t	2026-10-26 21:10:32.620273-07	2026-10-26 21:10:32.620273-07
264	6	invoice.status	Status	Debit Note	string	f	t	2026-10-26 21:10:32.620548-07	2026-10-26 21:10:32.620548-07
265	6	customer.name	Customer Name	Customer	string	f	t	2026-10-26 21:10:32.620856-07	2026-10-26 21:10:32.620856-07
266	6	customer.address	Customer Address	Customer	string	f	t	2026-10-26 21:10:32.621172-07	2026-10-26 21:10:32.621172-07
267	6	customer.email	Customer Email	Customer	string	f	t	2026-10-26 21:10:32.621491-07	2026-10-26 21:10:32.621491-07
268	6	customer.phone	Customer Phone	Customer	string	f	t	2026-10-26 21:10:32.62173-07	2026-10-26 21:10:32.62173-07
269	6	customer.tax_number	Customer Tax Number	Customer	string	f	t	2026-10-26 21:10:32.622045-07	2026-10-26 21:10:32.622045-07
270	6	customer.contact_person	Contact Person	Customer	string	f	t	2026-10-26 21:10:32.622323-07	2026-10-26 21:10:32.622323-07
271	6	customer.postal_code	Postal Code	Customer	string	f	t	2026-10-26 21:10:32.622614-07	2026-10-26 21:10:32.622614-07
272	6	customer.country	Customer Country	Customer	string	f	t	2026-10-26 21:10:32.622927-07	2026-10-26 21:10:32.622927-07
273	6	customer.ship_to_address	Ship To Address	Customer	string	f	t	2026-10-26 21:10:32.623205-07	2026-10-26 21:10:32.623205-07
274	6	item.index	#	Items	number	t	t	2026-10-26 21:10:32.623537-07	2026-10-26 21:10:32.623537-07
275	6	item.product_name	Product	Items	string	t	t	2026-10-26 21:10:32.623878-07	2026-10-26 21:10:32.623878-07
276	6	item.description	Description	Items	string	t	t	2026-10-26 21:10:32.624232-07	2026-10-26 21:10:32.624232-07
277	6	item.quantity	Quantity	Items	number	t	t	2026-10-26 21:10:32.624615-07	2026-10-26 21:10:32.624615-07
278	6	item.uom	UOM	Items	string	t	t	2026-10-26 21:10:32.625056-07	2026-10-26 21:10:32.625056-07
279	6	item.unit_price	Unit Price	Items	currency	t	t	2026-10-26 21:10:32.625393-07	2026-10-26 21:10:32.625393-07
280	6	item.discount	Item Discount	Items	number	t	t	2026-10-26 21:10:32.62564-07	2026-10-26 21:10:32.62564-07
281	6	item.tax	Item Tax	Items	number	t	t	2026-10-26 21:10:32.625939-07	2026-10-26 21:10:32.625939-07
282	6	item.amount	Amount	Items	currency	t	t	2026-10-26 21:10:32.626253-07	2026-10-26 21:10:32.626253-07
283	7	company.name	Company Name	Company	string	f	t	2026-10-26 21:10:32.628991-07	2026-10-26 21:10:32.628991-07
284	7	company.logo	Company Logo	Company	image	f	t	2026-10-26 21:10:32.629324-07	2026-10-26 21:10:32.629324-07
285	7	company.address	Company Address	Company	string	f	t	2026-10-26 21:10:32.629638-07	2026-10-26 21:10:32.629638-07
286	7	company.country	Company Country	Company	string	f	t	2026-10-26 21:10:32.629926-07	2026-10-26 21:10:32.629926-07
287	7	company.phone	Company Phone	Company	string	f	t	2026-10-26 21:10:32.630183-07	2026-10-26 21:10:32.630183-07
288	7	company.email	Company Email	Company	string	f	t	2026-10-26 21:10:32.630418-07	2026-10-26 21:10:32.630418-07
289	7	company.website	Company Website	Company	string	f	t	2026-10-26 21:10:32.630659-07	2026-10-26 21:10:32.630659-07
290	7	company.tax_number	Company Tax Number	Company	string	f	t	2026-10-26 21:10:32.630953-07	2026-10-26 21:10:32.630953-07
291	7	company.registration_number	Registration Number	Company	string	f	t	2026-10-26 21:10:32.631184-07	2026-10-26 21:10:32.631184-07
292	7	company.bank_details	Bank Details	Company	string	f	t	2026-10-26 21:10:32.631409-07	2026-10-26 21:10:32.631409-07
293	7	company.terms	Terms & Conditions	Company	string	f	t	2026-10-26 21:10:32.63163-07	2026-10-26 21:10:32.63163-07
294	7	company.gst_rate	GST Rate	Company	string	f	t	2026-10-26 21:10:32.631854-07	2026-10-26 21:10:32.631854-07
295	7	invoice.invoice_number	DO Number	Delivery Order	string	f	t	2026-10-26 21:10:32.632116-07	2026-10-26 21:10:32.632116-07
296	7	invoice.invoice_date	DO Date	Delivery Order	date	f	t	2026-10-26 21:10:32.632352-07	2026-10-26 21:10:32.632352-07
297	7	invoice.delivery_date	Delivery Date	Delivery Order	date	f	t	2026-10-26 21:10:32.632642-07	2026-10-26 21:10:32.632642-07
298	7	invoice.payment_terms	Payment Terms	Delivery Order	string	f	t	2026-10-26 21:10:32.632957-07	2026-10-26 21:10:32.632957-07
299	7	invoice.po_ref	PO Reference	Delivery Order	string	f	t	2026-10-26 21:10:32.633337-07	2026-10-26 21:10:32.633337-07
300	7	invoice.notes	Notes	Delivery Order	string	f	t	2026-10-26 21:10:32.633759-07	2026-10-26 21:10:32.633759-07
301	7	invoice.customer_note	Customer Note	Delivery Order	string	f	t	2026-10-26 21:10:32.634211-07	2026-10-26 21:10:32.634211-07
302	7	invoice.delivery_instructions	Delivery Instructions	Delivery Order	string	f	t	2026-10-26 21:10:32.634607-07	2026-10-26 21:10:32.634607-07
303	7	invoice.terms_and_conditions	Terms & Conditions	Delivery Order	string	f	t	2026-10-26 21:10:32.635476-07	2026-10-26 21:10:32.635476-07
304	7	invoice.authorised_signature	Authorised Signature	Delivery Order	image	f	t	2026-10-26 21:10:32.636003-07	2026-10-26 21:10:32.636003-07
305	7	invoice.subtotal	Subtotal	Delivery Order	currency	f	t	2026-10-26 21:10:32.636291-07	2026-10-26 21:10:32.636291-07
306	7	invoice.discount	Discount	Delivery Order	currency	f	t	2026-10-26 21:10:32.636556-07	2026-10-26 21:10:32.636556-07
307	7	invoice.tax	Tax	Delivery Order	currency	f	t	2026-10-26 21:10:32.636891-07	2026-10-26 21:10:32.636891-07
308	7	invoice.tax_label	GST Label	Delivery Order	string	f	t	2026-10-26 21:10:32.637314-07	2026-10-26 21:10:32.637314-07
309	7	invoice.total	Total	Delivery Order	currency	f	t	2026-10-26 21:10:32.637654-07	2026-10-26 21:10:32.637654-07
310	7	invoice.currency	Currency	Delivery Order	string	f	t	2026-10-26 21:10:32.638036-07	2026-10-26 21:10:32.638036-07
311	7	invoice.status	Status	Delivery Order	string	f	t	2026-10-26 21:10:32.6383-07	2026-10-26 21:10:32.6383-07
312	7	customer.name	Customer Name	Customer	string	f	t	2026-10-26 21:10:32.638546-07	2026-10-26 21:10:32.638546-07
313	7	customer.address	Customer Address	Customer	string	f	t	2026-10-26 21:10:32.638813-07	2026-10-26 21:10:32.638813-07
314	7	customer.email	Customer Email	Customer	string	f	t	2026-10-26 21:10:32.639066-07	2026-10-26 21:10:32.639066-07
315	7	customer.phone	Customer Phone	Customer	string	f	t	2026-10-26 21:10:32.639324-07	2026-10-26 21:10:32.639324-07
316	7	customer.tax_number	Customer Tax Number	Customer	string	f	t	2026-10-26 21:10:32.639569-07	2026-10-26 21:10:32.639569-07
317	7	customer.contact_person	Contact Person	Customer	string	f	t	2026-10-26 21:10:32.639836-07	2026-10-26 21:10:32.639836-07
318	7	customer.postal_code	Postal Code	Customer	string	f	t	2026-10-26 21:10:32.640138-07	2026-10-26 21:10:32.640138-07
319	7	customer.country	Customer Country	Customer	string	f	t	2026-10-26 21:10:32.640413-07	2026-10-26 21:10:32.640413-07
320	7	customer.ship_to_address	Ship To Address	Customer	string	f	t	2026-10-26 21:10:32.64076-07	2026-10-26 21:10:32.64076-07
321	7	item.index	#	Items	number	t	t	2026-10-26 21:10:32.641124-07	2026-10-26 21:10:32.641124-07
322	7	item.product_name	Product	Items	string	t	t	2026-10-26 21:10:32.641453-07	2026-10-26 21:10:32.641453-07
323	7	item.description	Description	Items	string	t	t	2026-10-26 21:10:32.641763-07	2026-10-26 21:10:32.641763-07
324	7	item.quantity	Quantity	Items	number	t	t	2026-10-26 21:10:32.6421-07	2026-10-26 21:10:32.6421-07
325	7	item.uom	UOM	Items	string	t	t	2026-10-26 21:10:32.642403-07	2026-10-26 21:10:32.642403-07
326	7	item.unit_price	Unit Price	Items	currency	t	t	2026-10-26 21:10:32.642675-07	2026-10-26 21:10:32.642675-07
327	7	item.discount	Item Discount	Items	number	t	t	2026-10-26 21:10:32.642956-07	2026-10-26 21:10:32.642956-07
328	7	item.tax	Item Tax	Items	number	t	t	2026-10-26 21:10:32.643219-07	2026-10-26 21:10:32.643219-07
329	7	item.amount	Amount	Items	currency	t	t	2026-10-26 21:10:32.643496-07	2026-10-26 21:10:32.643496-07
330	8	company.name	Company Name	Company	string	f	t	2026-10-26 21:10:32.64591-07	2026-10-26 21:10:32.64591-07
331	8	company.logo	Company Logo	Company	image	f	t	2026-10-26 21:10:32.646164-07	2026-10-26 21:10:32.646164-07
332	8	company.address	Company Address	Company	string	f	t	2026-10-26 21:10:32.646404-07	2026-10-26 21:10:32.646404-07
333	8	company.country	Company Country	Company	string	f	t	2026-10-26 21:10:32.646636-07	2026-10-26 21:10:32.646636-07
334	8	company.phone	Company Phone	Company	string	f	t	2026-10-26 21:10:32.646891-07	2026-10-26 21:10:32.646891-07
335	8	company.email	Company Email	Company	string	f	t	2026-10-26 21:10:32.64713-07	2026-10-26 21:10:32.64713-07
336	8	company.website	Company Website	Company	string	f	t	2026-10-26 21:10:32.647378-07	2026-10-26 21:10:32.647378-07
337	8	company.tax_number	Company Tax Number	Company	string	f	t	2026-10-26 21:10:32.64761-07	2026-10-26 21:10:32.64761-07
338	8	company.registration_number	Registration Number	Company	string	f	t	2026-10-26 21:10:32.64784-07	2026-10-26 21:10:32.64784-07
339	8	company.bank_details	Bank Details	Company	string	f	t	2026-10-26 21:10:32.648075-07	2026-10-26 21:10:32.648075-07
340	8	company.terms	Terms & Conditions	Company	string	f	t	2026-10-26 21:10:32.648333-07	2026-10-26 21:10:32.648333-07
341	8	company.gst_rate	GST Rate	Company	string	f	t	2026-10-26 21:10:32.648679-07	2026-10-26 21:10:32.648679-07
342	8	invoice.invoice_number	PQ Number	Purchase Quotation	string	f	t	2026-10-26 21:10:32.648969-07	2026-10-26 21:10:32.648969-07
343	8	invoice.invoice_date	PQ Date	Purchase Quotation	date	f	t	2026-10-26 21:10:32.649244-07	2026-10-26 21:10:32.649244-07
344	8	invoice.delivery_date	Delivery Date	Purchase Quotation	date	f	t	2026-10-26 21:10:32.649494-07	2026-10-26 21:10:32.649494-07
345	8	invoice.payment_terms	Payment Terms	Purchase Quotation	string	f	t	2026-10-26 21:10:32.649806-07	2026-10-26 21:10:32.649806-07
346	8	invoice.po_ref	PO Reference	Purchase Quotation	string	f	t	2026-10-26 21:10:32.650165-07	2026-10-26 21:10:32.650165-07
347	8	invoice.notes	Notes	Purchase Quotation	string	f	t	2026-10-26 21:10:32.650655-07	2026-10-26 21:10:32.650655-07
348	8	invoice.customer_note	Customer Note	Purchase Quotation	string	f	t	2026-10-26 21:10:32.651045-07	2026-10-26 21:10:32.651045-07
349	8	invoice.delivery_instructions	Delivery Instructions	Purchase Quotation	string	f	t	2026-10-26 21:10:32.651386-07	2026-10-26 21:10:32.651386-07
350	8	invoice.terms_and_conditions	Terms & Conditions	Purchase Quotation	string	f	t	2026-10-26 21:10:32.651746-07	2026-10-26 21:10:32.651746-07
351	8	invoice.authorised_signature	Authorised Signature	Purchase Quotation	image	f	t	2026-10-26 21:10:32.652062-07	2026-10-26 21:10:32.652062-07
352	8	invoice.subtotal	Subtotal	Purchase Quotation	currency	f	t	2026-10-26 21:10:32.652379-07	2026-10-26 21:10:32.652379-07
353	8	invoice.discount	Discount	Purchase Quotation	currency	f	t	2026-10-26 21:10:32.652713-07	2026-10-26 21:10:32.652713-07
354	8	invoice.tax	Tax	Purchase Quotation	currency	f	t	2026-10-26 21:10:32.653043-07	2026-10-26 21:10:32.653043-07
355	8	invoice.tax_label	GST Label	Purchase Quotation	string	f	t	2026-10-26 21:10:32.653346-07	2026-10-26 21:10:32.653346-07
356	8	invoice.total	Total	Purchase Quotation	currency	f	t	2026-10-26 21:10:32.653598-07	2026-10-26 21:10:32.653598-07
357	8	invoice.currency	Currency	Purchase Quotation	string	f	t	2026-10-26 21:10:32.653845-07	2026-10-26 21:10:32.653845-07
358	8	invoice.status	Status	Purchase Quotation	string	f	t	2026-10-26 21:10:32.654071-07	2026-10-26 21:10:32.654071-07
359	8	customer.name	Vendor Name	Vendor	string	f	t	2026-10-26 21:10:32.654295-07	2026-10-26 21:10:32.654295-07
360	8	customer.address	Vendor Address	Vendor	string	f	t	2026-10-26 21:10:32.654655-07	2026-10-26 21:10:32.654655-07
361	8	customer.email	Vendor Email	Vendor	string	f	t	2026-10-26 21:10:32.654892-07	2026-10-26 21:10:32.654892-07
362	8	customer.phone	Vendor Phone	Vendor	string	f	t	2026-10-26 21:10:32.655125-07	2026-10-26 21:10:32.655125-07
363	8	customer.tax_number	Vendor Tax Number	Vendor	string	f	t	2026-10-26 21:10:32.655403-07	2026-10-26 21:10:32.655403-07
364	8	customer.contact_person	Contact Person	Vendor	string	f	t	2026-10-26 21:10:32.655636-07	2026-10-26 21:10:32.655636-07
365	8	customer.postal_code	Postal Code	Vendor	string	f	t	2026-10-26 21:10:32.655859-07	2026-10-26 21:10:32.655859-07
366	8	customer.country	Vendor Country	Vendor	string	f	t	2026-10-26 21:10:32.656084-07	2026-10-26 21:10:32.656084-07
367	8	customer.ship_to_address	Ship To Address	Vendor	string	f	t	2026-10-26 21:10:32.656303-07	2026-10-26 21:10:32.656303-07
368	8	item.index	#	Items	number	t	t	2026-10-26 21:10:32.656638-07	2026-10-26 21:10:32.656638-07
369	8	item.product_name	Product	Items	string	t	t	2026-10-26 21:10:32.656896-07	2026-10-26 21:10:32.656896-07
370	8	item.description	Description	Items	string	t	t	2026-10-26 21:10:32.657152-07	2026-10-26 21:10:32.657152-07
371	8	item.quantity	Quantity	Items	number	t	t	2026-10-26 21:10:32.6574-07	2026-10-26 21:10:32.6574-07
372	8	item.uom	UOM	Items	string	t	t	2026-10-26 21:10:32.657627-07	2026-10-26 21:10:32.657627-07
373	8	item.unit_price	Unit Price	Items	currency	t	t	2026-10-26 21:10:32.657944-07	2026-10-26 21:10:32.657944-07
374	8	item.discount	Item Discount	Items	number	t	t	2026-10-26 21:10:32.658182-07	2026-10-26 21:10:32.658182-07
375	8	item.tax	Item Tax	Items	number	t	t	2026-10-26 21:10:32.658456-07	2026-10-26 21:10:32.658456-07
376	8	item.amount	Amount	Items	currency	t	t	2026-10-26 21:10:32.658809-07	2026-10-26 21:10:32.658809-07
377	9	company.name	Company Name	Company	string	f	t	2026-10-26 21:10:32.662025-07	2026-10-26 21:10:32.662025-07
378	9	company.logo	Company Logo	Company	image	f	t	2026-10-26 21:10:32.66233-07	2026-10-26 21:10:32.66233-07
379	9	company.address	Company Address	Company	string	f	t	2026-10-26 21:10:32.66263-07	2026-10-26 21:10:32.66263-07
380	9	company.country	Company Country	Company	string	f	t	2026-10-26 21:10:32.662885-07	2026-10-26 21:10:32.662885-07
381	9	company.phone	Company Phone	Company	string	f	t	2026-10-26 21:10:32.663172-07	2026-10-26 21:10:32.663172-07
382	9	company.email	Company Email	Company	string	f	t	2026-10-26 21:10:32.66348-07	2026-10-26 21:10:32.66348-07
383	9	company.website	Company Website	Company	string	f	t	2026-10-26 21:10:32.663794-07	2026-10-26 21:10:32.663794-07
384	9	company.tax_number	Company Tax Number	Company	string	f	t	2026-10-26 21:10:32.664056-07	2026-10-26 21:10:32.664056-07
385	9	company.registration_number	Registration Number	Company	string	f	t	2026-10-26 21:10:32.664295-07	2026-10-26 21:10:32.664295-07
386	9	company.bank_details	Bank Details	Company	string	f	t	2026-10-26 21:10:32.664571-07	2026-10-26 21:10:32.664571-07
387	9	company.terms	Terms & Conditions	Company	string	f	t	2026-10-26 21:10:32.664945-07	2026-10-26 21:10:32.664945-07
388	9	company.gst_rate	GST Rate	Company	string	f	t	2026-10-26 21:10:32.665294-07	2026-10-26 21:10:32.665294-07
389	9	invoice.invoice_number	PO Number	Purchase Order	string	f	t	2026-10-26 21:10:32.665552-07	2026-10-26 21:10:32.665552-07
390	9	invoice.invoice_date	PO Date	Purchase Order	date	f	t	2026-10-26 21:10:32.665819-07	2026-10-26 21:10:32.665819-07
391	9	invoice.delivery_date	Delivery Date	Purchase Order	date	f	t	2026-10-26 21:10:32.666057-07	2026-10-26 21:10:32.666057-07
392	9	invoice.payment_terms	Payment Terms	Purchase Order	string	f	t	2026-10-26 21:10:32.666278-07	2026-10-26 21:10:32.666278-07
393	9	invoice.po_ref	PO Reference	Purchase Order	string	f	t	2026-10-26 21:10:32.666531-07	2026-10-26 21:10:32.666531-07
394	9	invoice.notes	Notes	Purchase Order	string	f	t	2026-10-26 21:10:32.666983-07	2026-10-26 21:10:32.666983-07
395	9	invoice.customer_note	Customer Note	Purchase Order	string	f	t	2026-10-26 21:10:32.667421-07	2026-10-26 21:10:32.667421-07
396	9	invoice.delivery_instructions	Delivery Instructions	Purchase Order	string	f	t	2026-10-26 21:10:32.6678-07	2026-10-26 21:10:32.6678-07
397	9	invoice.terms_and_conditions	Terms & Conditions	Purchase Order	string	f	t	2026-10-26 21:10:32.668171-07	2026-10-26 21:10:32.668171-07
398	9	invoice.authorised_signature	Authorised Signature	Purchase Order	image	f	t	2026-10-26 21:10:32.668549-07	2026-10-26 21:10:32.668549-07
399	9	invoice.subtotal	Subtotal	Purchase Order	currency	f	t	2026-10-26 21:10:32.668971-07	2026-10-26 21:10:32.668971-07
400	9	invoice.discount	Discount	Purchase Order	currency	f	t	2026-10-26 21:10:32.669333-07	2026-10-26 21:10:32.669333-07
401	9	invoice.tax	Tax	Purchase Order	currency	f	t	2026-10-26 21:10:32.669672-07	2026-10-26 21:10:32.669672-07
402	9	invoice.tax_label	GST Label	Purchase Order	string	f	t	2026-10-26 21:10:32.670031-07	2026-10-26 21:10:32.670031-07
403	9	invoice.total	Total	Purchase Order	currency	f	t	2026-10-26 21:10:32.67044-07	2026-10-26 21:10:32.67044-07
404	9	invoice.currency	Currency	Purchase Order	string	f	t	2026-10-26 21:10:32.670982-07	2026-10-26 21:10:32.670982-07
405	9	invoice.status	Status	Purchase Order	string	f	t	2026-10-26 21:10:32.67138-07	2026-10-26 21:10:32.67138-07
406	9	customer.name	Vendor Name	Vendor	string	f	t	2026-10-26 21:10:32.671796-07	2026-10-26 21:10:32.671796-07
407	9	customer.address	Vendor Address	Vendor	string	f	t	2026-10-26 21:10:32.672214-07	2026-10-26 21:10:32.672214-07
408	9	customer.email	Vendor Email	Vendor	string	f	t	2026-10-26 21:10:32.672621-07	2026-10-26 21:10:32.672621-07
409	9	customer.phone	Vendor Phone	Vendor	string	f	t	2026-10-26 21:10:32.673466-07	2026-10-26 21:10:32.673466-07
410	9	customer.tax_number	Vendor Tax Number	Vendor	string	f	t	2026-10-26 21:10:32.673859-07	2026-10-26 21:10:32.673859-07
411	9	customer.contact_person	Contact Person	Vendor	string	f	t	2026-10-26 21:10:32.674241-07	2026-10-26 21:10:32.674241-07
412	9	customer.postal_code	Postal Code	Vendor	string	f	t	2026-10-26 21:10:32.674849-07	2026-10-26 21:10:32.674849-07
413	9	customer.country	Vendor Country	Vendor	string	f	t	2026-10-26 21:10:32.675297-07	2026-10-26 21:10:32.675297-07
414	9	customer.ship_to_address	Ship To Address	Vendor	string	f	t	2026-10-26 21:10:32.675737-07	2026-10-26 21:10:32.675737-07
415	9	item.index	#	Items	number	t	t	2026-10-26 21:10:32.676118-07	2026-10-26 21:10:32.676118-07
416	9	item.product_name	Product	Items	string	t	t	2026-10-26 21:10:32.676769-07	2026-10-26 21:10:32.676769-07
417	9	item.description	Description	Items	string	t	t	2026-10-26 21:10:32.677347-07	2026-10-26 21:10:32.677347-07
418	9	item.quantity	Quantity	Items	number	t	t	2026-10-26 21:10:32.677672-07	2026-10-26 21:10:32.677672-07
419	9	item.uom	UOM	Items	string	t	t	2026-10-26 21:10:32.678023-07	2026-10-26 21:10:32.678023-07
420	9	item.unit_price	Unit Price	Items	currency	t	t	2026-10-26 21:10:32.678351-07	2026-10-26 21:10:32.678351-07
421	9	item.discount	Item Discount	Items	number	t	t	2026-10-26 21:10:32.678678-07	2026-10-26 21:10:32.678678-07
422	9	item.tax	Item Tax	Items	number	t	t	2026-10-26 21:10:32.678993-07	2026-10-26 21:10:32.678993-07
423	9	item.amount	Amount	Items	currency	t	t	2026-10-26 21:10:32.679351-07	2026-10-26 21:10:32.679351-07
424	10	company.name	Company Name	Company	string	f	t	2026-10-26 21:10:32.682997-07	2026-10-26 21:10:32.682997-07
425	10	company.logo	Company Logo	Company	image	f	t	2026-10-26 21:10:32.683336-07	2026-10-26 21:10:32.683336-07
426	10	company.address	Company Address	Company	string	f	t	2026-10-26 21:10:32.683768-07	2026-10-26 21:10:32.683768-07
427	10	company.country	Company Country	Company	string	f	t	2026-10-26 21:10:32.684186-07	2026-10-26 21:10:32.684186-07
428	10	company.phone	Company Phone	Company	string	f	t	2026-10-26 21:10:32.684695-07	2026-10-26 21:10:32.684695-07
429	10	company.email	Company Email	Company	string	f	t	2026-10-26 21:10:32.685089-07	2026-10-26 21:10:32.685089-07
430	10	company.website	Company Website	Company	string	f	t	2026-10-26 21:10:32.685476-07	2026-10-26 21:10:32.685476-07
431	10	company.tax_number	Company Tax Number	Company	string	f	t	2026-10-26 21:10:32.685844-07	2026-10-26 21:10:32.685844-07
432	10	company.registration_number	Registration Number	Company	string	f	t	2026-10-26 21:10:32.686205-07	2026-10-26 21:10:32.686205-07
433	10	company.bank_details	Bank Details	Company	string	f	t	2026-10-26 21:10:32.686555-07	2026-10-26 21:10:32.686555-07
434	10	company.terms	Terms & Conditions	Company	string	f	t	2026-10-26 21:10:32.687064-07	2026-10-26 21:10:32.687064-07
435	10	company.gst_rate	GST Rate	Company	string	f	t	2026-10-26 21:10:32.687532-07	2026-10-26 21:10:32.687532-07
436	10	invoice.invoice_number	VI Number	Vendor Invoice	string	f	t	2026-10-26 21:10:32.687988-07	2026-10-26 21:10:32.687988-07
437	10	invoice.invoice_date	VI Date	Vendor Invoice	date	f	t	2026-10-26 21:10:32.688396-07	2026-10-26 21:10:32.688396-07
438	10	invoice.delivery_date	Delivery Date	Vendor Invoice	date	f	t	2026-10-26 21:10:32.68875-07	2026-10-26 21:10:32.68875-07
439	10	invoice.payment_terms	Payment Terms	Vendor Invoice	string	f	t	2026-10-26 21:10:32.689132-07	2026-10-26 21:10:32.689132-07
440	10	invoice.po_ref	PO Reference	Vendor Invoice	string	f	t	2026-10-26 21:10:32.689534-07	2026-10-26 21:10:32.689534-07
441	10	invoice.notes	Notes	Vendor Invoice	string	f	t	2026-10-26 21:10:32.689903-07	2026-10-26 21:10:32.689903-07
442	10	invoice.customer_note	Customer Note	Vendor Invoice	string	f	t	2026-10-26 21:10:32.690232-07	2026-10-26 21:10:32.690232-07
443	10	invoice.delivery_instructions	Delivery Instructions	Vendor Invoice	string	f	t	2026-10-26 21:10:32.690566-07	2026-10-26 21:10:32.690566-07
444	10	invoice.terms_and_conditions	Terms & Conditions	Vendor Invoice	string	f	t	2026-10-26 21:10:32.690904-07	2026-10-26 21:10:32.690904-07
445	10	invoice.authorised_signature	Authorised Signature	Vendor Invoice	image	f	t	2026-10-26 21:10:32.691318-07	2026-10-26 21:10:32.691318-07
446	10	invoice.subtotal	Subtotal	Vendor Invoice	currency	f	t	2026-10-26 21:10:32.691734-07	2026-10-26 21:10:32.691734-07
447	10	invoice.discount	Discount	Vendor Invoice	currency	f	t	2026-10-26 21:10:32.692153-07	2026-10-26 21:10:32.692153-07
448	10	invoice.tax	Tax	Vendor Invoice	currency	f	t	2026-10-26 21:10:32.692507-07	2026-10-26 21:10:32.692507-07
449	10	invoice.tax_label	GST Label	Vendor Invoice	string	f	t	2026-10-26 21:10:32.692912-07	2026-10-26 21:10:32.692912-07
450	10	invoice.total	Total	Vendor Invoice	currency	f	t	2026-10-26 21:10:32.693297-07	2026-10-26 21:10:32.693297-07
451	10	invoice.currency	Currency	Vendor Invoice	string	f	t	2026-10-26 21:10:32.693644-07	2026-10-26 21:10:32.693644-07
452	10	invoice.status	Status	Vendor Invoice	string	f	t	2026-10-26 21:10:32.693982-07	2026-10-26 21:10:32.693982-07
453	10	customer.name	Vendor Name	Vendor	string	f	t	2026-10-26 21:10:32.694296-07	2026-10-26 21:10:32.694296-07
454	10	customer.address	Vendor Address	Vendor	string	f	t	2026-10-26 21:10:32.694715-07	2026-10-26 21:10:32.694715-07
455	10	customer.email	Vendor Email	Vendor	string	f	t	2026-10-26 21:10:32.695047-07	2026-10-26 21:10:32.695047-07
456	10	customer.phone	Vendor Phone	Vendor	string	f	t	2026-10-26 21:10:32.695445-07	2026-10-26 21:10:32.695445-07
457	10	customer.tax_number	Vendor Tax Number	Vendor	string	f	t	2026-10-26 21:10:32.695888-07	2026-10-26 21:10:32.695888-07
458	10	customer.contact_person	Contact Person	Vendor	string	f	t	2026-10-26 21:10:32.696567-07	2026-10-26 21:10:32.696567-07
459	10	customer.postal_code	Postal Code	Vendor	string	f	t	2026-10-26 21:10:32.696965-07	2026-10-26 21:10:32.696965-07
460	10	customer.country	Vendor Country	Vendor	string	f	t	2026-10-26 21:10:32.69738-07	2026-10-26 21:10:32.69738-07
461	10	customer.ship_to_address	Ship To Address	Vendor	string	f	t	2026-10-26 21:10:32.697798-07	2026-10-26 21:10:32.697798-07
462	10	item.index	#	Items	number	t	t	2026-10-26 21:10:32.698115-07	2026-10-26 21:10:32.698115-07
463	10	item.product_name	Product	Items	string	t	t	2026-10-26 21:10:32.698388-07	2026-10-26 21:10:32.698388-07
464	10	item.description	Description	Items	string	t	t	2026-10-26 21:10:32.698878-07	2026-10-26 21:10:32.698878-07
465	10	item.quantity	Quantity	Items	number	t	t	2026-10-26 21:10:32.699189-07	2026-10-26 21:10:32.699189-07
466	10	item.uom	UOM	Items	string	t	t	2026-10-26 21:10:32.699449-07	2026-10-26 21:10:32.699449-07
467	10	item.unit_price	Unit Price	Items	currency	t	t	2026-10-26 21:10:32.699696-07	2026-10-26 21:10:32.699696-07
468	10	item.discount	Item Discount	Items	number	t	t	2026-10-26 21:10:32.700046-07	2026-10-26 21:10:32.700046-07
469	10	item.tax	Item Tax	Items	number	t	t	2026-10-26 21:10:32.700572-07	2026-10-26 21:10:32.700572-07
470	10	item.amount	Amount	Items	currency	t	t	2026-10-26 21:10:32.701086-07	2026-10-26 21:10:32.701086-07
471	11	company.name	Company Name	Company	string	f	t	2026-10-26 21:10:32.705103-07	2026-10-26 21:10:32.705103-07
472	11	company.logo	Company Logo	Company	image	f	t	2026-10-26 21:10:32.705497-07	2026-10-26 21:10:32.705497-07
473	11	company.address	Company Address	Company	string	f	t	2026-10-26 21:10:32.705798-07	2026-10-26 21:10:32.705798-07
474	11	company.country	Company Country	Company	string	f	t	2026-10-26 21:10:32.706068-07	2026-10-26 21:10:32.706068-07
475	11	company.phone	Company Phone	Company	string	f	t	2026-10-26 21:10:32.706312-07	2026-10-26 21:10:32.706312-07
476	11	company.email	Company Email	Company	string	f	t	2026-10-26 21:10:32.706551-07	2026-10-26 21:10:32.706551-07
477	11	company.website	Company Website	Company	string	f	t	2026-10-26 21:10:32.706931-07	2026-10-26 21:10:32.706931-07
478	11	company.tax_number	Company Tax Number	Company	string	f	t	2026-10-26 21:10:32.70726-07	2026-10-26 21:10:32.70726-07
479	11	company.registration_number	Registration Number	Company	string	f	t	2026-10-26 21:10:32.707565-07	2026-10-26 21:10:32.707565-07
480	11	company.bank_details	Bank Details	Company	string	f	t	2026-10-26 21:10:32.707804-07	2026-10-26 21:10:32.707804-07
481	11	company.terms	Terms & Conditions	Company	string	f	t	2026-10-26 21:10:32.708041-07	2026-10-26 21:10:32.708041-07
482	11	company.gst_rate	GST Rate	Company	string	f	t	2026-10-26 21:10:32.708274-07	2026-10-26 21:10:32.708274-07
483	11	invoice.invoice_number	GRN Number	Goods Receipt Note	string	f	t	2026-10-26 21:10:32.708531-07	2026-10-26 21:10:32.708531-07
484	11	invoice.invoice_date	GRN Date	Goods Receipt Note	date	f	t	2026-10-26 21:10:32.708896-07	2026-10-26 21:10:32.708896-07
485	11	invoice.delivery_date	Delivery Date	Goods Receipt Note	date	f	t	2026-10-26 21:10:32.709164-07	2026-10-26 21:10:32.709164-07
486	11	invoice.payment_terms	Payment Terms	Goods Receipt Note	string	f	t	2026-10-26 21:10:32.709404-07	2026-10-26 21:10:32.709404-07
487	11	invoice.po_ref	PO Reference	Goods Receipt Note	string	f	t	2026-10-26 21:10:32.709633-07	2026-10-26 21:10:32.709633-07
488	11	invoice.notes	Notes	Goods Receipt Note	string	f	t	2026-10-26 21:10:32.709873-07	2026-10-26 21:10:32.709873-07
489	11	invoice.customer_note	Customer Note	Goods Receipt Note	string	f	t	2026-10-26 21:10:32.710201-07	2026-10-26 21:10:32.710201-07
490	11	invoice.delivery_instructions	Delivery Instructions	Goods Receipt Note	string	f	t	2026-10-26 21:10:32.710491-07	2026-10-26 21:10:32.710491-07
491	11	invoice.terms_and_conditions	Terms & Conditions	Goods Receipt Note	string	f	t	2026-10-26 21:10:32.71075-07	2026-10-26 21:10:32.71075-07
492	11	invoice.authorised_signature	Authorised Signature	Goods Receipt Note	image	f	t	2026-10-26 21:10:32.711021-07	2026-10-26 21:10:32.711021-07
493	11	invoice.subtotal	Subtotal	Goods Receipt Note	currency	f	t	2026-10-26 21:10:32.711337-07	2026-10-26 21:10:32.711337-07
494	11	invoice.discount	Discount	Goods Receipt Note	currency	f	t	2026-10-26 21:10:32.711638-07	2026-10-26 21:10:32.711638-07
495	11	invoice.tax	Tax	Goods Receipt Note	currency	f	t	2026-10-26 21:10:32.711962-07	2026-10-26 21:10:32.711962-07
496	11	invoice.tax_label	GST Label	Goods Receipt Note	string	f	t	2026-10-26 21:10:32.71221-07	2026-10-26 21:10:32.71221-07
497	11	invoice.total	Total	Goods Receipt Note	currency	f	t	2026-10-26 21:10:32.712458-07	2026-10-26 21:10:32.712458-07
498	11	invoice.currency	Currency	Goods Receipt Note	string	f	t	2026-10-26 21:10:32.712757-07	2026-10-26 21:10:32.712757-07
499	11	invoice.status	Status	Goods Receipt Note	string	f	t	2026-10-26 21:10:32.713067-07	2026-10-26 21:10:32.713067-07
500	11	customer.name	Vendor Name	Vendor	string	f	t	2026-10-26 21:10:32.713398-07	2026-10-26 21:10:32.713398-07
501	11	customer.address	Vendor Address	Vendor	string	f	t	2026-10-26 21:10:32.71364-07	2026-10-26 21:10:32.71364-07
502	11	customer.email	Vendor Email	Vendor	string	f	t	2026-10-26 21:10:32.713869-07	2026-10-26 21:10:32.713869-07
503	11	customer.phone	Vendor Phone	Vendor	string	f	t	2026-10-26 21:10:32.714092-07	2026-10-26 21:10:32.714092-07
504	11	customer.tax_number	Vendor Tax Number	Vendor	string	f	t	2026-10-26 21:10:32.714311-07	2026-10-26 21:10:32.714311-07
505	11	customer.contact_person	Contact Person	Vendor	string	f	t	2026-10-26 21:10:32.714531-07	2026-10-26 21:10:32.714531-07
506	11	customer.postal_code	Postal Code	Vendor	string	f	t	2026-10-26 21:10:32.714781-07	2026-10-26 21:10:32.714781-07
507	11	customer.country	Vendor Country	Vendor	string	f	t	2026-10-26 21:10:32.715036-07	2026-10-26 21:10:32.715036-07
508	11	customer.ship_to_address	Ship To Address	Vendor	string	f	t	2026-10-26 21:10:32.715278-07	2026-10-26 21:10:32.715278-07
509	11	item.index	#	Items	number	t	t	2026-10-26 21:10:32.715512-07	2026-10-26 21:10:32.715512-07
510	11	item.product_name	Product	Items	string	t	t	2026-10-26 21:10:32.715747-07	2026-10-26 21:10:32.715747-07
511	11	item.description	Description	Items	string	t	t	2026-10-26 21:10:32.715987-07	2026-10-26 21:10:32.715987-07
512	11	item.quantity	Quantity	Items	number	t	t	2026-10-26 21:10:32.71623-07	2026-10-26 21:10:32.71623-07
513	11	item.uom	UOM	Items	string	t	t	2026-10-26 21:10:32.716488-07	2026-10-26 21:10:32.716488-07
514	11	item.unit_price	Unit Price	Items	currency	t	t	2026-10-26 21:10:32.717074-07	2026-10-26 21:10:32.717074-07
515	11	item.discount	Item Discount	Items	number	t	t	2026-10-26 21:10:32.717633-07	2026-10-26 21:10:32.717633-07
516	11	item.tax	Item Tax	Items	number	t	t	2026-10-26 21:10:32.718083-07	2026-10-26 21:10:32.718083-07
517	11	item.amount	Amount	Items	currency	t	t	2026-10-26 21:10:32.718716-07	2026-10-26 21:10:32.718716-07
\.


--
-- Data for Name: report_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_templates (id, company_id, report_definition_id, name, description, template_json, is_system_template, is_active, created_by, updated_by, created_at, updated_at) FROM stdin;
1	\N	1	Default Quotation Template	System default quotation layout matching the BizOne document. Company data is bound at print time.	{"page": {"size": "A4", "margin": {"top": 10, "left": 14, "right": 14, "bottom": 12}, "orientation": "portrait"}, "version": 1, "elements": [{"x": 14, "y": 10, "id": "company-logo", "type": "image", "color": "#111827", "field": "company.logo", "width": 62, "height": 16, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 28, "id": "company-name", "type": "field", "color": "#111827", "field": "company.name", "width": 100, "height": 6, "visible": true, "fontSize": 11, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 35, "id": "company-address", "type": "field", "color": "#646464", "field": "company.address", "width": 108, "height": 10, "visible": true, "fontSize": 9, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 46, "id": "reg-label", "text": "Co. Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 46, "id": "company-reg", "type": "field", "color": "#646464", "field": "company.registration_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 50.5, "id": "gst-reg-label", "text": "GST Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 50.5, "id": "company-tax", "type": "field", "color": "#646464", "field": "company.tax_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 108, "y": 10, "id": "doc-title", "text": "QUOTATION", "type": "text", "color": "#18212F", "width": 88, "height": 11, "visible": true, "fontSize": 22, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 24, "id": "number-label", "text": "Number:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 24, "id": "invoice-number", "type": "field", "color": "#646464", "field": "invoice.invoice_number", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 30, "id": "date-label", "text": "Date:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 30, "id": "invoice-date", "type": "field", "color": "#646464", "field": "invoice.invoice_date", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 118, "y": 36, "id": "terms-meta-label", "text": "Payment Terms:", "type": "text", "color": "#646464", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 36, "id": "payment-terms", "type": "field", "color": "#646464", "field": "invoice.payment_terms", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 57, "id": "header-line", "type": "line", "color": "#111827", "width": 182, "height": 0.35, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#C8C8C8"}, {"x": 14, "y": 61, "id": "bill-to-label", "text": "Bill To:", "type": "text", "color": "#111827", "width": 80, "height": 5, "visible": true, "fontSize": 10, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 68, "id": "customer-name", "type": "field", "color": "#3C3C3C", "field": "customer.name", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 74, "id": "customer-address", "type": "field", "color": "#3C3C3C", "field": "customer.address", "width": 130, "height": 10, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 85, "id": "customer-attn", "type": "field", "color": "#3C3C3C", "field": "customer.contact_person", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 94, "id": "items-table", "type": "table", "color": "#111827", "width": 182, "height": 88, "source": "items", "columns": [{"align": "left", "field": "item.index", "width": 10, "header": "#"}, {"align": "left", "field": "item.product_name", "width": 32, "header": "Item / Part Number"}, {"align": "left", "field": "item.description", "width": 48, "header": "Description"}, {"align": "right", "field": "item.quantity", "width": 16, "header": "Qty"}, {"align": "center", "field": "item.uom", "width": 16, "header": "UOM"}, {"align": "right", "field": "item.unit_price", "width": 30, "header": "Unit Price"}, {"align": "right", "field": "item.amount", "width": 30, "header": "Amount"}], "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "headerColor": "#FFFFFF", "headerBackground": "#18212F"}, {"x": 118, "y": 188, "id": "totals-box", "type": "rectangle", "color": "#111827", "width": 78, "height": 28, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#F3F4F6"}, {"x": 122, "y": 191, "id": "subtotal-label", "text": "Subtotal", "type": "text", "color": "#646464", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 191, "id": "subtotal", "type": "field", "color": "#111827", "field": "invoice.subtotal", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 198, "id": "tax-label", "type": "field", "color": "#646464", "field": "invoice.tax_label", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 198, "id": "tax", "type": "field", "color": "#111827", "field": "invoice.tax", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 205, "id": "total-line", "type": "line", "color": "#111827", "width": 70, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 122, "y": 208, "id": "total-label", "text": "Total Amount", "type": "text", "color": "#111827", "width": 32, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 208, "id": "total", "type": "field", "color": "#111827", "field": "invoice.total", "width": 38, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 220, "id": "cust-note-label", "text": "Customer Note:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 224, "id": "cust-note-field", "type": "field", "color": "#111827", "field": "invoice.customer_note", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 236, "id": "deliv-inst-label", "text": "Delivery Instructions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 240, "id": "deliv-inst-field", "type": "field", "color": "#111827", "field": "invoice.delivery_instructions", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 252, "id": "terms-label", "text": "Terms & Conditions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 256, "id": "terms-field", "type": "field", "color": "#111827", "field": "invoice.terms_and_conditions", "width": 90, "height": 18, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 224, "id": "authorised-sig-img", "type": "image", "color": "#111827", "field": "invoice.authorised_signature", "width": 45, "height": 15, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 240, "id": "authorised-sig-line", "type": "line", "color": "#111827", "width": 45, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 136, "y": 241, "id": "authorised-sig-label", "text": "Authorised Signature", "type": "text", "color": "#646464", "width": 45, "height": 4, "visible": true, "fontSize": 8, "textAlign": "center", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 278, "id": "footer-line", "type": "line", "color": "#111827", "width": 182, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D2D2D2"}, {"x": 14, "y": 281, "id": "footer-note", "text": "This is a computer-generated Quotation document and does not require a physical signature.", "type": "text", "color": "#AFAFAF", "width": 140, "height": 5, "visible": true, "fontSize": 6.5, "fontStyle": "italic", "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 281, "id": "page-number", "type": "page_number", "color": "#AFAFAF", "width": 42, "height": 5, "visible": true, "fontSize": 6.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}], "reportType": "quotation"}	t	f	\N	\N	2026-10-26 21:10:32.54272-07	2026-10-26 22:20:25.715-07
2	\N	2	Default Sales Order Template	System default sales order layout matching the BizOne document. Company data is bound at print time.	{"page": {"size": "A4", "margin": {"top": 10, "left": 14, "right": 14, "bottom": 12}, "orientation": "portrait"}, "version": 1, "elements": [{"x": 14, "y": 10, "id": "company-logo", "type": "image", "color": "#111827", "field": "company.logo", "width": 62, "height": 16, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 28, "id": "company-name", "type": "field", "color": "#111827", "field": "company.name", "width": 100, "height": 6, "visible": true, "fontSize": 11, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 35, "id": "company-address", "type": "field", "color": "#646464", "field": "company.address", "width": 108, "height": 10, "visible": true, "fontSize": 9, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 46, "id": "reg-label", "text": "Co. Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 46, "id": "company-reg", "type": "field", "color": "#646464", "field": "company.registration_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 50.5, "id": "gst-reg-label", "text": "GST Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 50.5, "id": "company-tax", "type": "field", "color": "#646464", "field": "company.tax_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 108, "y": 10, "id": "doc-title", "text": "SALES ORDER", "type": "text", "color": "#18212F", "width": 88, "height": 11, "visible": true, "fontSize": 22, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 24, "id": "number-label", "text": "Number:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 24, "id": "invoice-number", "type": "field", "color": "#646464", "field": "invoice.invoice_number", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 30, "id": "date-label", "text": "Date:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 30, "id": "invoice-date", "type": "field", "color": "#646464", "field": "invoice.invoice_date", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 118, "y": 36, "id": "terms-meta-label", "text": "Payment Terms:", "type": "text", "color": "#646464", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 36, "id": "payment-terms", "type": "field", "color": "#646464", "field": "invoice.payment_terms", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 57, "id": "header-line", "type": "line", "color": "#111827", "width": 182, "height": 0.35, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#C8C8C8"}, {"x": 14, "y": 61, "id": "bill-to-label", "text": "Bill To:", "type": "text", "color": "#111827", "width": 80, "height": 5, "visible": true, "fontSize": 10, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 68, "id": "customer-name", "type": "field", "color": "#3C3C3C", "field": "customer.name", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 74, "id": "customer-address", "type": "field", "color": "#3C3C3C", "field": "customer.address", "width": 130, "height": 10, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 85, "id": "customer-attn", "type": "field", "color": "#3C3C3C", "field": "customer.contact_person", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 94, "id": "items-table", "type": "table", "color": "#111827", "width": 182, "height": 88, "source": "items", "columns": [{"align": "left", "field": "item.index", "width": 10, "header": "#"}, {"align": "left", "field": "item.product_name", "width": 32, "header": "Item / Part Number"}, {"align": "left", "field": "item.description", "width": 48, "header": "Description"}, {"align": "right", "field": "item.quantity", "width": 16, "header": "Qty"}, {"align": "center", "field": "item.uom", "width": 16, "header": "UOM"}, {"align": "right", "field": "item.unit_price", "width": 30, "header": "Unit Price"}, {"align": "right", "field": "item.amount", "width": 30, "header": "Amount"}], "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "headerColor": "#FFFFFF", "headerBackground": "#18212F"}, {"x": 118, "y": 188, "id": "totals-box", "type": "rectangle", "color": "#111827", "width": 78, "height": 28, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#F3F4F6"}, {"x": 122, "y": 191, "id": "subtotal-label", "text": "Subtotal", "type": "text", "color": "#646464", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 191, "id": "subtotal", "type": "field", "color": "#111827", "field": "invoice.subtotal", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 198, "id": "tax-label", "type": "field", "color": "#646464", "field": "invoice.tax_label", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 198, "id": "tax", "type": "field", "color": "#111827", "field": "invoice.tax", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 205, "id": "total-line", "type": "line", "color": "#111827", "width": 70, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 122, "y": 208, "id": "total-label", "text": "Total Amount", "type": "text", "color": "#111827", "width": 32, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 208, "id": "total", "type": "field", "color": "#111827", "field": "invoice.total", "width": 38, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 220, "id": "cust-note-label", "text": "Customer Note:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 224, "id": "cust-note-field", "type": "field", "color": "#111827", "field": "invoice.customer_note", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 236, "id": "deliv-inst-label", "text": "Delivery Instructions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 240, "id": "deliv-inst-field", "type": "field", "color": "#111827", "field": "invoice.delivery_instructions", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 252, "id": "terms-label", "text": "Terms & Conditions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 256, "id": "terms-field", "type": "field", "color": "#111827", "field": "invoice.terms_and_conditions", "width": 90, "height": 18, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 224, "id": "authorised-sig-img", "type": "image", "color": "#111827", "field": "invoice.authorised_signature", "width": 45, "height": 15, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 240, "id": "authorised-sig-line", "type": "line", "color": "#111827", "width": 45, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 136, "y": 241, "id": "authorised-sig-label", "text": "Authorised Signature", "type": "text", "color": "#646464", "width": 45, "height": 4, "visible": true, "fontSize": 8, "textAlign": "center", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 278, "id": "footer-line", "type": "line", "color": "#111827", "width": 182, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D2D2D2"}, {"x": 14, "y": 281, "id": "footer-note", "text": "This is a computer-generated Sales Order document and does not require a physical signature.", "type": "text", "color": "#AFAFAF", "width": 140, "height": 5, "visible": true, "fontSize": 6.5, "fontStyle": "italic", "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 281, "id": "page-number", "type": "page_number", "color": "#AFAFAF", "width": 42, "height": 5, "visible": true, "fontSize": 6.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}], "reportType": "sales-order"}	t	f	\N	\N	2026-10-26 21:10:32.561383-07	2026-10-26 22:20:25.726-07
3	\N	3	Default Proforma Invoice Template	System default proforma invoice layout matching the BizOne document. Company data is bound at print time.	{"page": {"size": "A4", "margin": {"top": 10, "left": 14, "right": 14, "bottom": 12}, "orientation": "portrait"}, "version": 1, "elements": [{"x": 14, "y": 10, "id": "company-logo", "type": "image", "color": "#111827", "field": "company.logo", "width": 62, "height": 16, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 28, "id": "company-name", "type": "field", "color": "#111827", "field": "company.name", "width": 100, "height": 6, "visible": true, "fontSize": 11, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 35, "id": "company-address", "type": "field", "color": "#646464", "field": "company.address", "width": 108, "height": 10, "visible": true, "fontSize": 9, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 46, "id": "reg-label", "text": "Co. Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 46, "id": "company-reg", "type": "field", "color": "#646464", "field": "company.registration_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 50.5, "id": "gst-reg-label", "text": "GST Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 50.5, "id": "company-tax", "type": "field", "color": "#646464", "field": "company.tax_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 108, "y": 10, "id": "doc-title", "text": "PROFORMA INVOICE", "type": "text", "color": "#18212F", "width": 88, "height": 11, "visible": true, "fontSize": 22, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 24, "id": "number-label", "text": "Number:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 24, "id": "invoice-number", "type": "field", "color": "#646464", "field": "invoice.invoice_number", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 30, "id": "date-label", "text": "Date:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 30, "id": "invoice-date", "type": "field", "color": "#646464", "field": "invoice.invoice_date", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 118, "y": 36, "id": "terms-meta-label", "text": "Payment Terms:", "type": "text", "color": "#646464", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 36, "id": "payment-terms", "type": "field", "color": "#646464", "field": "invoice.payment_terms", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 57, "id": "header-line", "type": "line", "color": "#111827", "width": 182, "height": 0.35, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#C8C8C8"}, {"x": 14, "y": 61, "id": "bill-to-label", "text": "Bill To:", "type": "text", "color": "#111827", "width": 80, "height": 5, "visible": true, "fontSize": 10, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 68, "id": "customer-name", "type": "field", "color": "#3C3C3C", "field": "customer.name", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 74, "id": "customer-address", "type": "field", "color": "#3C3C3C", "field": "customer.address", "width": 130, "height": 10, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 85, "id": "customer-attn", "type": "field", "color": "#3C3C3C", "field": "customer.contact_person", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 94, "id": "items-table", "type": "table", "color": "#111827", "width": 182, "height": 88, "source": "items", "columns": [{"align": "left", "field": "item.index", "width": 10, "header": "#"}, {"align": "left", "field": "item.product_name", "width": 32, "header": "Item / Part Number"}, {"align": "left", "field": "item.description", "width": 48, "header": "Description"}, {"align": "right", "field": "item.quantity", "width": 16, "header": "Qty"}, {"align": "center", "field": "item.uom", "width": 16, "header": "UOM"}, {"align": "right", "field": "item.unit_price", "width": 30, "header": "Unit Price"}, {"align": "right", "field": "item.amount", "width": 30, "header": "Amount"}], "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "headerColor": "#FFFFFF", "headerBackground": "#18212F"}, {"x": 118, "y": 188, "id": "totals-box", "type": "rectangle", "color": "#111827", "width": 78, "height": 28, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#F3F4F6"}, {"x": 122, "y": 191, "id": "subtotal-label", "text": "Subtotal", "type": "text", "color": "#646464", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 191, "id": "subtotal", "type": "field", "color": "#111827", "field": "invoice.subtotal", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 198, "id": "tax-label", "type": "field", "color": "#646464", "field": "invoice.tax_label", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 198, "id": "tax", "type": "field", "color": "#111827", "field": "invoice.tax", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 205, "id": "total-line", "type": "line", "color": "#111827", "width": 70, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 122, "y": 208, "id": "total-label", "text": "Total Amount", "type": "text", "color": "#111827", "width": 32, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 208, "id": "total", "type": "field", "color": "#111827", "field": "invoice.total", "width": 38, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 220, "id": "cust-note-label", "text": "Customer Note:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 224, "id": "cust-note-field", "type": "field", "color": "#111827", "field": "invoice.customer_note", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 236, "id": "deliv-inst-label", "text": "Delivery Instructions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 240, "id": "deliv-inst-field", "type": "field", "color": "#111827", "field": "invoice.delivery_instructions", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 252, "id": "terms-label", "text": "Terms & Conditions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 256, "id": "terms-field", "type": "field", "color": "#111827", "field": "invoice.terms_and_conditions", "width": 90, "height": 18, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 224, "id": "authorised-sig-img", "type": "image", "color": "#111827", "field": "invoice.authorised_signature", "width": 45, "height": 15, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 240, "id": "authorised-sig-line", "type": "line", "color": "#111827", "width": 45, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 136, "y": 241, "id": "authorised-sig-label", "text": "Authorised Signature", "type": "text", "color": "#646464", "width": 45, "height": 4, "visible": true, "fontSize": 8, "textAlign": "center", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 278, "id": "footer-line", "type": "line", "color": "#111827", "width": 182, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D2D2D2"}, {"x": 14, "y": 281, "id": "footer-note", "text": "This is a computer-generated Proforma Invoice document and does not require a physical signature.", "type": "text", "color": "#AFAFAF", "width": 140, "height": 5, "visible": true, "fontSize": 6.5, "fontStyle": "italic", "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 281, "id": "page-number", "type": "page_number", "color": "#AFAFAF", "width": 42, "height": 5, "visible": true, "fontSize": 6.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}], "reportType": "proforma-invoice"}	t	f	\N	\N	2026-10-26 21:10:32.577162-07	2026-10-26 22:20:25.73-07
4	\N	4	Default Tax Invoice Template	System default tax invoice layout matching the BizOne document. Company data is bound at print time.	{"page": {"size": "A4", "margin": {"top": 10, "left": 14, "right": 14, "bottom": 12}, "orientation": "portrait"}, "version": 1, "elements": [{"x": 14, "y": 10, "id": "company-logo", "type": "image", "color": "#111827", "field": "company.logo", "width": 62, "height": 16, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 28, "id": "company-name", "type": "field", "color": "#111827", "field": "company.name", "width": 100, "height": 6, "visible": true, "fontSize": 11, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 35, "id": "company-address", "type": "field", "color": "#646464", "field": "company.address", "width": 108, "height": 10, "visible": true, "fontSize": 9, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 46, "id": "reg-label", "text": "Co. Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 46, "id": "company-reg", "type": "field", "color": "#646464", "field": "company.registration_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 50.5, "id": "gst-reg-label", "text": "GST Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 50.5, "id": "company-tax", "type": "field", "color": "#646464", "field": "company.tax_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 108, "y": 10, "id": "doc-title", "text": "TAX INVOICE", "type": "text", "color": "#18212F", "width": 88, "height": 11, "visible": true, "fontSize": 22, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 24, "id": "number-label", "text": "Number:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 24, "id": "invoice-number", "type": "field", "color": "#646464", "field": "invoice.invoice_number", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 30, "id": "date-label", "text": "Date:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 30, "id": "invoice-date", "type": "field", "color": "#646464", "field": "invoice.invoice_date", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 118, "y": 36, "id": "terms-meta-label", "text": "Payment Terms:", "type": "text", "color": "#646464", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 36, "id": "payment-terms", "type": "field", "color": "#646464", "field": "invoice.payment_terms", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 57, "id": "header-line", "type": "line", "color": "#111827", "width": 182, "height": 0.35, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#C8C8C8"}, {"x": 14, "y": 61, "id": "bill-to-label", "text": "Bill To:", "type": "text", "color": "#111827", "width": 80, "height": 5, "visible": true, "fontSize": 10, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 68, "id": "customer-name", "type": "field", "color": "#3C3C3C", "field": "customer.name", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 74, "id": "customer-address", "type": "field", "color": "#3C3C3C", "field": "customer.address", "width": 130, "height": 10, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 85, "id": "customer-attn", "type": "field", "color": "#3C3C3C", "field": "customer.contact_person", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 94, "id": "items-table", "type": "table", "color": "#111827", "width": 182, "height": 88, "source": "items", "columns": [{"align": "left", "field": "item.index", "width": 10, "header": "#"}, {"align": "left", "field": "item.product_name", "width": 32, "header": "Item / Part Number"}, {"align": "left", "field": "item.description", "width": 48, "header": "Description"}, {"align": "right", "field": "item.quantity", "width": 16, "header": "Qty"}, {"align": "center", "field": "item.uom", "width": 16, "header": "UOM"}, {"align": "right", "field": "item.unit_price", "width": 30, "header": "Unit Price"}, {"align": "right", "field": "item.amount", "width": 30, "header": "Amount"}], "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "headerColor": "#FFFFFF", "headerBackground": "#18212F"}, {"x": 118, "y": 188, "id": "totals-box", "type": "rectangle", "color": "#111827", "width": 78, "height": 28, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#F3F4F6"}, {"x": 122, "y": 191, "id": "subtotal-label", "text": "Subtotal", "type": "text", "color": "#646464", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 191, "id": "subtotal", "type": "field", "color": "#111827", "field": "invoice.subtotal", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 198, "id": "tax-label", "type": "field", "color": "#646464", "field": "invoice.tax_label", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 198, "id": "tax", "type": "field", "color": "#111827", "field": "invoice.tax", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 205, "id": "total-line", "type": "line", "color": "#111827", "width": 70, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 122, "y": 208, "id": "total-label", "text": "Total Amount", "type": "text", "color": "#111827", "width": 32, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 208, "id": "total", "type": "field", "color": "#111827", "field": "invoice.total", "width": 38, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 220, "id": "cust-note-label", "text": "Customer Note:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 224, "id": "cust-note-field", "type": "field", "color": "#111827", "field": "invoice.customer_note", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 236, "id": "deliv-inst-label", "text": "Delivery Instructions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 240, "id": "deliv-inst-field", "type": "field", "color": "#111827", "field": "invoice.delivery_instructions", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 252, "id": "terms-label", "text": "Terms & Conditions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 256, "id": "terms-field", "type": "field", "color": "#111827", "field": "invoice.terms_and_conditions", "width": 90, "height": 18, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 224, "id": "authorised-sig-img", "type": "image", "color": "#111827", "field": "invoice.authorised_signature", "width": 45, "height": 15, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 240, "id": "authorised-sig-line", "type": "line", "color": "#111827", "width": 45, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 136, "y": 241, "id": "authorised-sig-label", "text": "Authorised Signature", "type": "text", "color": "#646464", "width": 45, "height": 4, "visible": true, "fontSize": 8, "textAlign": "center", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 278, "id": "footer-line", "type": "line", "color": "#111827", "width": 182, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D2D2D2"}, {"x": 14, "y": 281, "id": "footer-note", "text": "This is a computer-generated Tax Invoice document and does not require a physical signature.", "type": "text", "color": "#AFAFAF", "width": 140, "height": 5, "visible": true, "fontSize": 6.5, "fontStyle": "italic", "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 281, "id": "page-number", "type": "page_number", "color": "#AFAFAF", "width": 42, "height": 5, "visible": true, "fontSize": 6.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}], "reportType": "invoice"}	t	f	\N	\N	2026-10-26 21:10:32.593828-07	2026-10-26 22:20:25.737-07
5	\N	5	Default Credit Note Template	System default credit note layout matching the BizOne document. Company data is bound at print time.	{"page": {"size": "A4", "margin": {"top": 10, "left": 14, "right": 14, "bottom": 12}, "orientation": "portrait"}, "version": 1, "elements": [{"x": 14, "y": 10, "id": "company-logo", "type": "image", "color": "#111827", "field": "company.logo", "width": 62, "height": 16, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 28, "id": "company-name", "type": "field", "color": "#111827", "field": "company.name", "width": 100, "height": 6, "visible": true, "fontSize": 11, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 35, "id": "company-address", "type": "field", "color": "#646464", "field": "company.address", "width": 108, "height": 10, "visible": true, "fontSize": 9, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 46, "id": "reg-label", "text": "Co. Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 46, "id": "company-reg", "type": "field", "color": "#646464", "field": "company.registration_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 50.5, "id": "gst-reg-label", "text": "GST Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 50.5, "id": "company-tax", "type": "field", "color": "#646464", "field": "company.tax_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 108, "y": 10, "id": "doc-title", "text": "CREDIT NOTE", "type": "text", "color": "#18212F", "width": 88, "height": 11, "visible": true, "fontSize": 22, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 24, "id": "number-label", "text": "Number:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 24, "id": "invoice-number", "type": "field", "color": "#646464", "field": "invoice.invoice_number", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 30, "id": "date-label", "text": "Date:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 30, "id": "invoice-date", "type": "field", "color": "#646464", "field": "invoice.invoice_date", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 118, "y": 36, "id": "terms-meta-label", "text": "Payment Terms:", "type": "text", "color": "#646464", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 36, "id": "payment-terms", "type": "field", "color": "#646464", "field": "invoice.payment_terms", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 57, "id": "header-line", "type": "line", "color": "#111827", "width": 182, "height": 0.35, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#C8C8C8"}, {"x": 14, "y": 61, "id": "bill-to-label", "text": "Bill To:", "type": "text", "color": "#111827", "width": 80, "height": 5, "visible": true, "fontSize": 10, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 68, "id": "customer-name", "type": "field", "color": "#3C3C3C", "field": "customer.name", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 74, "id": "customer-address", "type": "field", "color": "#3C3C3C", "field": "customer.address", "width": 130, "height": 10, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 85, "id": "customer-attn", "type": "field", "color": "#3C3C3C", "field": "customer.contact_person", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 94, "id": "items-table", "type": "table", "color": "#111827", "width": 182, "height": 88, "source": "items", "columns": [{"align": "left", "field": "item.index", "width": 10, "header": "#"}, {"align": "left", "field": "item.product_name", "width": 32, "header": "Item / Part Number"}, {"align": "left", "field": "item.description", "width": 48, "header": "Description"}, {"align": "right", "field": "item.quantity", "width": 16, "header": "Qty"}, {"align": "center", "field": "item.uom", "width": 16, "header": "UOM"}, {"align": "right", "field": "item.unit_price", "width": 30, "header": "Unit Price"}, {"align": "right", "field": "item.amount", "width": 30, "header": "Amount"}], "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "headerColor": "#FFFFFF", "headerBackground": "#18212F"}, {"x": 118, "y": 188, "id": "totals-box", "type": "rectangle", "color": "#111827", "width": 78, "height": 28, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#F3F4F6"}, {"x": 122, "y": 191, "id": "subtotal-label", "text": "Subtotal", "type": "text", "color": "#646464", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 191, "id": "subtotal", "type": "field", "color": "#111827", "field": "invoice.subtotal", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 198, "id": "tax-label", "type": "field", "color": "#646464", "field": "invoice.tax_label", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 198, "id": "tax", "type": "field", "color": "#111827", "field": "invoice.tax", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 205, "id": "total-line", "type": "line", "color": "#111827", "width": 70, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 122, "y": 208, "id": "total-label", "text": "Total Amount", "type": "text", "color": "#111827", "width": 32, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 208, "id": "total", "type": "field", "color": "#111827", "field": "invoice.total", "width": 38, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 220, "id": "cust-note-label", "text": "Customer Note:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 224, "id": "cust-note-field", "type": "field", "color": "#111827", "field": "invoice.customer_note", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 236, "id": "deliv-inst-label", "text": "Delivery Instructions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 240, "id": "deliv-inst-field", "type": "field", "color": "#111827", "field": "invoice.delivery_instructions", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 252, "id": "terms-label", "text": "Terms & Conditions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 256, "id": "terms-field", "type": "field", "color": "#111827", "field": "invoice.terms_and_conditions", "width": 90, "height": 18, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 224, "id": "authorised-sig-img", "type": "image", "color": "#111827", "field": "invoice.authorised_signature", "width": 45, "height": 15, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 240, "id": "authorised-sig-line", "type": "line", "color": "#111827", "width": 45, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 136, "y": 241, "id": "authorised-sig-label", "text": "Authorised Signature", "type": "text", "color": "#646464", "width": 45, "height": 4, "visible": true, "fontSize": 8, "textAlign": "center", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 278, "id": "footer-line", "type": "line", "color": "#111827", "width": 182, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D2D2D2"}, {"x": 14, "y": 281, "id": "footer-note", "text": "This is a computer-generated Credit Note document and does not require a physical signature.", "type": "text", "color": "#AFAFAF", "width": 140, "height": 5, "visible": true, "fontSize": 6.5, "fontStyle": "italic", "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 281, "id": "page-number", "type": "page_number", "color": "#AFAFAF", "width": 42, "height": 5, "visible": true, "fontSize": 6.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}], "reportType": "credit-note"}	t	f	\N	\N	2026-10-26 21:10:32.609816-07	2026-10-26 22:20:25.742-07
6	\N	6	Default Debit Note Template	System default debit note layout matching the BizOne document. Company data is bound at print time.	{"page": {"size": "A4", "margin": {"top": 10, "left": 14, "right": 14, "bottom": 12}, "orientation": "portrait"}, "version": 1, "elements": [{"x": 14, "y": 10, "id": "company-logo", "type": "image", "color": "#111827", "field": "company.logo", "width": 62, "height": 16, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 28, "id": "company-name", "type": "field", "color": "#111827", "field": "company.name", "width": 100, "height": 6, "visible": true, "fontSize": 11, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 35, "id": "company-address", "type": "field", "color": "#646464", "field": "company.address", "width": 108, "height": 10, "visible": true, "fontSize": 9, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 46, "id": "reg-label", "text": "Co. Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 46, "id": "company-reg", "type": "field", "color": "#646464", "field": "company.registration_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 50.5, "id": "gst-reg-label", "text": "GST Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 50.5, "id": "company-tax", "type": "field", "color": "#646464", "field": "company.tax_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 108, "y": 10, "id": "doc-title", "text": "DEBIT NOTE", "type": "text", "color": "#18212F", "width": 88, "height": 11, "visible": true, "fontSize": 22, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 24, "id": "number-label", "text": "Number:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 24, "id": "invoice-number", "type": "field", "color": "#646464", "field": "invoice.invoice_number", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 30, "id": "date-label", "text": "Date:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 30, "id": "invoice-date", "type": "field", "color": "#646464", "field": "invoice.invoice_date", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 118, "y": 36, "id": "terms-meta-label", "text": "Payment Terms:", "type": "text", "color": "#646464", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 36, "id": "payment-terms", "type": "field", "color": "#646464", "field": "invoice.payment_terms", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 57, "id": "header-line", "type": "line", "color": "#111827", "width": 182, "height": 0.35, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#C8C8C8"}, {"x": 14, "y": 61, "id": "bill-to-label", "text": "Bill To:", "type": "text", "color": "#111827", "width": 80, "height": 5, "visible": true, "fontSize": 10, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 68, "id": "customer-name", "type": "field", "color": "#3C3C3C", "field": "customer.name", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 74, "id": "customer-address", "type": "field", "color": "#3C3C3C", "field": "customer.address", "width": 130, "height": 10, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 85, "id": "customer-attn", "type": "field", "color": "#3C3C3C", "field": "customer.contact_person", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 94, "id": "items-table", "type": "table", "color": "#111827", "width": 182, "height": 88, "source": "items", "columns": [{"align": "left", "field": "item.index", "width": 10, "header": "#"}, {"align": "left", "field": "item.product_name", "width": 32, "header": "Item / Part Number"}, {"align": "left", "field": "item.description", "width": 48, "header": "Description"}, {"align": "right", "field": "item.quantity", "width": 16, "header": "Qty"}, {"align": "center", "field": "item.uom", "width": 16, "header": "UOM"}, {"align": "right", "field": "item.unit_price", "width": 30, "header": "Unit Price"}, {"align": "right", "field": "item.amount", "width": 30, "header": "Amount"}], "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "headerColor": "#FFFFFF", "headerBackground": "#18212F"}, {"x": 118, "y": 188, "id": "totals-box", "type": "rectangle", "color": "#111827", "width": 78, "height": 28, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#F3F4F6"}, {"x": 122, "y": 191, "id": "subtotal-label", "text": "Subtotal", "type": "text", "color": "#646464", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 191, "id": "subtotal", "type": "field", "color": "#111827", "field": "invoice.subtotal", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 198, "id": "tax-label", "type": "field", "color": "#646464", "field": "invoice.tax_label", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 198, "id": "tax", "type": "field", "color": "#111827", "field": "invoice.tax", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 205, "id": "total-line", "type": "line", "color": "#111827", "width": 70, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 122, "y": 208, "id": "total-label", "text": "Total Amount", "type": "text", "color": "#111827", "width": 32, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 208, "id": "total", "type": "field", "color": "#111827", "field": "invoice.total", "width": 38, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 220, "id": "cust-note-label", "text": "Customer Note:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 224, "id": "cust-note-field", "type": "field", "color": "#111827", "field": "invoice.customer_note", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 236, "id": "deliv-inst-label", "text": "Delivery Instructions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 240, "id": "deliv-inst-field", "type": "field", "color": "#111827", "field": "invoice.delivery_instructions", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 252, "id": "terms-label", "text": "Terms & Conditions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 256, "id": "terms-field", "type": "field", "color": "#111827", "field": "invoice.terms_and_conditions", "width": 90, "height": 18, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 224, "id": "authorised-sig-img", "type": "image", "color": "#111827", "field": "invoice.authorised_signature", "width": 45, "height": 15, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 240, "id": "authorised-sig-line", "type": "line", "color": "#111827", "width": 45, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 136, "y": 241, "id": "authorised-sig-label", "text": "Authorised Signature", "type": "text", "color": "#646464", "width": 45, "height": 4, "visible": true, "fontSize": 8, "textAlign": "center", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 278, "id": "footer-line", "type": "line", "color": "#111827", "width": 182, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D2D2D2"}, {"x": 14, "y": 281, "id": "footer-note", "text": "This is a computer-generated Debit Note document and does not require a physical signature.", "type": "text", "color": "#AFAFAF", "width": 140, "height": 5, "visible": true, "fontSize": 6.5, "fontStyle": "italic", "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 281, "id": "page-number", "type": "page_number", "color": "#AFAFAF", "width": 42, "height": 5, "visible": true, "fontSize": 6.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}], "reportType": "debit-note"}	t	f	\N	\N	2026-10-26 21:10:32.627128-07	2026-10-26 22:20:25.75-07
7	\N	7	Default Delivery Order Template	System default delivery order layout matching the BizOne document. Company data is bound at print time.	{"page": {"size": "A4", "margin": {"top": 10, "left": 14, "right": 14, "bottom": 12}, "orientation": "portrait"}, "version": 1, "elements": [{"x": 14, "y": 10, "id": "company-logo", "type": "image", "color": "#111827", "field": "company.logo", "width": 62, "height": 16, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 28, "id": "company-name", "type": "field", "color": "#111827", "field": "company.name", "width": 100, "height": 6, "visible": true, "fontSize": 11, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 35, "id": "company-address", "type": "field", "color": "#646464", "field": "company.address", "width": 108, "height": 10, "visible": true, "fontSize": 9, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 46, "id": "reg-label", "text": "Co. Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 46, "id": "company-reg", "type": "field", "color": "#646464", "field": "company.registration_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 50.5, "id": "gst-reg-label", "text": "GST Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 50.5, "id": "company-tax", "type": "field", "color": "#646464", "field": "company.tax_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 108, "y": 10, "id": "doc-title", "text": "DELIVERY ORDER", "type": "text", "color": "#18212F", "width": 88, "height": 11, "visible": true, "fontSize": 22, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 24, "id": "number-label", "text": "Number:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 24, "id": "invoice-number", "type": "field", "color": "#646464", "field": "invoice.invoice_number", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 30, "id": "date-label", "text": "Date:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 30, "id": "invoice-date", "type": "field", "color": "#646464", "field": "invoice.invoice_date", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 118, "y": 36, "id": "terms-meta-label", "text": "Payment Terms:", "type": "text", "color": "#646464", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 36, "id": "payment-terms", "type": "field", "color": "#646464", "field": "invoice.payment_terms", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 57, "id": "header-line", "type": "line", "color": "#111827", "width": 182, "height": 0.35, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#C8C8C8"}, {"x": 14, "y": 61, "id": "bill-to-label", "text": "Deliver To:", "type": "text", "color": "#111827", "width": 80, "height": 5, "visible": true, "fontSize": 10, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 68, "id": "customer-name", "type": "field", "color": "#3C3C3C", "field": "customer.name", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 74, "id": "customer-address", "type": "field", "color": "#3C3C3C", "field": "customer.address", "width": 130, "height": 10, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 85, "id": "customer-attn", "type": "field", "color": "#3C3C3C", "field": "customer.contact_person", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 94, "id": "items-table", "type": "table", "color": "#111827", "width": 182, "height": 88, "source": "items", "columns": [{"align": "left", "field": "item.index", "width": 10, "header": "#"}, {"align": "left", "field": "item.product_name", "width": 32, "header": "Item / Part Number"}, {"align": "left", "field": "item.description", "width": 48, "header": "Description"}, {"align": "right", "field": "item.quantity", "width": 16, "header": "Qty"}, {"align": "center", "field": "item.uom", "width": 16, "header": "UOM"}, {"align": "right", "field": "item.unit_price", "width": 30, "header": "Unit Price"}, {"align": "right", "field": "item.amount", "width": 30, "header": "Amount"}], "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "headerColor": "#FFFFFF", "headerBackground": "#18212F"}, {"x": 118, "y": 188, "id": "totals-box", "type": "rectangle", "color": "#111827", "width": 78, "height": 28, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#F3F4F6"}, {"x": 122, "y": 191, "id": "subtotal-label", "text": "Subtotal", "type": "text", "color": "#646464", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 191, "id": "subtotal", "type": "field", "color": "#111827", "field": "invoice.subtotal", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 198, "id": "tax-label", "type": "field", "color": "#646464", "field": "invoice.tax_label", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 198, "id": "tax", "type": "field", "color": "#111827", "field": "invoice.tax", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 205, "id": "total-line", "type": "line", "color": "#111827", "width": 70, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 122, "y": 208, "id": "total-label", "text": "Total Amount", "type": "text", "color": "#111827", "width": 32, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 208, "id": "total", "type": "field", "color": "#111827", "field": "invoice.total", "width": 38, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 220, "id": "cust-note-label", "text": "Customer Note:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 224, "id": "cust-note-field", "type": "field", "color": "#111827", "field": "invoice.customer_note", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 236, "id": "deliv-inst-label", "text": "Delivery Instructions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 240, "id": "deliv-inst-field", "type": "field", "color": "#111827", "field": "invoice.delivery_instructions", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 252, "id": "terms-label", "text": "Terms & Conditions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 256, "id": "terms-field", "type": "field", "color": "#111827", "field": "invoice.terms_and_conditions", "width": 90, "height": 18, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 224, "id": "authorised-sig-img", "type": "image", "color": "#111827", "field": "invoice.authorised_signature", "width": 45, "height": 15, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 240, "id": "authorised-sig-line", "type": "line", "color": "#111827", "width": 45, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 136, "y": 241, "id": "authorised-sig-label", "text": "Authorised Signature", "type": "text", "color": "#646464", "width": 45, "height": 4, "visible": true, "fontSize": 8, "textAlign": "center", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 278, "id": "footer-line", "type": "line", "color": "#111827", "width": 182, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D2D2D2"}, {"x": 14, "y": 281, "id": "footer-note", "text": "This is a computer-generated Delivery Order document and does not require a physical signature.", "type": "text", "color": "#AFAFAF", "width": 140, "height": 5, "visible": true, "fontSize": 6.5, "fontStyle": "italic", "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 281, "id": "page-number", "type": "page_number", "color": "#AFAFAF", "width": 42, "height": 5, "visible": true, "fontSize": 6.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}], "reportType": "delivery-order"}	t	f	\N	\N	2026-10-26 21:10:32.644277-07	2026-10-26 22:20:25.756-07
8	\N	8	Default Purchase Quotation Template	System default purchase quotation layout matching the BizOne document. Company data is bound at print time.	{"page": {"size": "A4", "margin": {"top": 10, "left": 14, "right": 14, "bottom": 12}, "orientation": "portrait"}, "version": 1, "elements": [{"x": 14, "y": 10, "id": "company-logo", "type": "image", "color": "#111827", "field": "company.logo", "width": 62, "height": 16, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 28, "id": "company-name", "type": "field", "color": "#111827", "field": "company.name", "width": 100, "height": 6, "visible": true, "fontSize": 11, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 35, "id": "company-address", "type": "field", "color": "#646464", "field": "company.address", "width": 108, "height": 10, "visible": true, "fontSize": 9, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 46, "id": "reg-label", "text": "Co. Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 46, "id": "company-reg", "type": "field", "color": "#646464", "field": "company.registration_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 50.5, "id": "gst-reg-label", "text": "GST Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 50.5, "id": "company-tax", "type": "field", "color": "#646464", "field": "company.tax_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 108, "y": 10, "id": "doc-title", "text": "PURCHASE QUOTATION", "type": "text", "color": "#18212F", "width": 88, "height": 11, "visible": true, "fontSize": 22, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 24, "id": "number-label", "text": "Number:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 24, "id": "invoice-number", "type": "field", "color": "#646464", "field": "invoice.invoice_number", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 30, "id": "date-label", "text": "Date:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 30, "id": "invoice-date", "type": "field", "color": "#646464", "field": "invoice.invoice_date", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 118, "y": 36, "id": "terms-meta-label", "text": "Payment Terms:", "type": "text", "color": "#646464", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 36, "id": "payment-terms", "type": "field", "color": "#646464", "field": "invoice.payment_terms", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 57, "id": "header-line", "type": "line", "color": "#111827", "width": 182, "height": 0.35, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#C8C8C8"}, {"x": 14, "y": 61, "id": "bill-to-label", "text": "Vendor:", "type": "text", "color": "#111827", "width": 80, "height": 5, "visible": true, "fontSize": 10, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 68, "id": "customer-name", "type": "field", "color": "#3C3C3C", "field": "customer.name", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 74, "id": "customer-address", "type": "field", "color": "#3C3C3C", "field": "customer.address", "width": 130, "height": 10, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 85, "id": "customer-attn", "type": "field", "color": "#3C3C3C", "field": "customer.contact_person", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 94, "id": "items-table", "type": "table", "color": "#111827", "width": 182, "height": 88, "source": "items", "columns": [{"align": "left", "field": "item.index", "width": 10, "header": "#"}, {"align": "left", "field": "item.product_name", "width": 32, "header": "Item / Part Number"}, {"align": "left", "field": "item.description", "width": 48, "header": "Description"}, {"align": "right", "field": "item.quantity", "width": 16, "header": "Qty"}, {"align": "center", "field": "item.uom", "width": 16, "header": "UOM"}, {"align": "right", "field": "item.unit_price", "width": 30, "header": "Unit Price"}, {"align": "right", "field": "item.amount", "width": 30, "header": "Amount"}], "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "headerColor": "#FFFFFF", "headerBackground": "#18212F"}, {"x": 118, "y": 188, "id": "totals-box", "type": "rectangle", "color": "#111827", "width": 78, "height": 28, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#F3F4F6"}, {"x": 122, "y": 191, "id": "subtotal-label", "text": "Subtotal", "type": "text", "color": "#646464", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 191, "id": "subtotal", "type": "field", "color": "#111827", "field": "invoice.subtotal", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 198, "id": "tax-label", "type": "field", "color": "#646464", "field": "invoice.tax_label", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 198, "id": "tax", "type": "field", "color": "#111827", "field": "invoice.tax", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 205, "id": "total-line", "type": "line", "color": "#111827", "width": 70, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 122, "y": 208, "id": "total-label", "text": "Total Amount", "type": "text", "color": "#111827", "width": 32, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 208, "id": "total", "type": "field", "color": "#111827", "field": "invoice.total", "width": 38, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 220, "id": "cust-note-label", "text": "Customer Note:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 224, "id": "cust-note-field", "type": "field", "color": "#111827", "field": "invoice.customer_note", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 236, "id": "deliv-inst-label", "text": "Delivery Instructions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 240, "id": "deliv-inst-field", "type": "field", "color": "#111827", "field": "invoice.delivery_instructions", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 252, "id": "terms-label", "text": "Terms & Conditions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 256, "id": "terms-field", "type": "field", "color": "#111827", "field": "invoice.terms_and_conditions", "width": 90, "height": 18, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 224, "id": "authorised-sig-img", "type": "image", "color": "#111827", "field": "invoice.authorised_signature", "width": 45, "height": 15, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 240, "id": "authorised-sig-line", "type": "line", "color": "#111827", "width": 45, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 136, "y": 241, "id": "authorised-sig-label", "text": "Authorised Signature", "type": "text", "color": "#646464", "width": 45, "height": 4, "visible": true, "fontSize": 8, "textAlign": "center", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 278, "id": "footer-line", "type": "line", "color": "#111827", "width": 182, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D2D2D2"}, {"x": 14, "y": 281, "id": "footer-note", "text": "This is a computer-generated Purchase Quotation document and does not require a physical signature.", "type": "text", "color": "#AFAFAF", "width": 140, "height": 5, "visible": true, "fontSize": 6.5, "fontStyle": "italic", "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 281, "id": "page-number", "type": "page_number", "color": "#AFAFAF", "width": 42, "height": 5, "visible": true, "fontSize": 6.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}], "reportType": "purchase-quotation"}	t	f	\N	\N	2026-10-26 21:10:32.659987-07	2026-10-26 22:20:25.761-07
9	\N	9	Default Purchase Order Template	System default purchase order layout matching the BizOne document. Company data is bound at print time.	{"page": {"size": "A4", "margin": {"top": 10, "left": 14, "right": 14, "bottom": 12}, "orientation": "portrait"}, "version": 1, "elements": [{"x": 14, "y": 10, "id": "company-logo", "type": "image", "color": "#111827", "field": "company.logo", "width": 62, "height": 16, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 28, "id": "company-name", "type": "field", "color": "#111827", "field": "company.name", "width": 100, "height": 6, "visible": true, "fontSize": 11, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 35, "id": "company-address", "type": "field", "color": "#646464", "field": "company.address", "width": 108, "height": 10, "visible": true, "fontSize": 9, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 46, "id": "reg-label", "text": "Co. Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 46, "id": "company-reg", "type": "field", "color": "#646464", "field": "company.registration_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 50.5, "id": "gst-reg-label", "text": "GST Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 50.5, "id": "company-tax", "type": "field", "color": "#646464", "field": "company.tax_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 108, "y": 10, "id": "doc-title", "text": "PURCHASE ORDER", "type": "text", "color": "#18212F", "width": 88, "height": 11, "visible": true, "fontSize": 22, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 24, "id": "number-label", "text": "Number:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 24, "id": "invoice-number", "type": "field", "color": "#646464", "field": "invoice.invoice_number", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 30, "id": "date-label", "text": "Date:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 30, "id": "invoice-date", "type": "field", "color": "#646464", "field": "invoice.invoice_date", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 118, "y": 36, "id": "terms-meta-label", "text": "Payment Terms:", "type": "text", "color": "#646464", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 36, "id": "payment-terms", "type": "field", "color": "#646464", "field": "invoice.payment_terms", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 57, "id": "header-line", "type": "line", "color": "#111827", "width": 182, "height": 0.35, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#C8C8C8"}, {"x": 14, "y": 61, "id": "bill-to-label", "text": "Vendor:", "type": "text", "color": "#111827", "width": 80, "height": 5, "visible": true, "fontSize": 10, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 68, "id": "customer-name", "type": "field", "color": "#3C3C3C", "field": "customer.name", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 74, "id": "customer-address", "type": "field", "color": "#3C3C3C", "field": "customer.address", "width": 130, "height": 10, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 85, "id": "customer-attn", "type": "field", "color": "#3C3C3C", "field": "customer.contact_person", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 94, "id": "items-table", "type": "table", "color": "#111827", "width": 182, "height": 88, "source": "items", "columns": [{"align": "left", "field": "item.index", "width": 10, "header": "#"}, {"align": "left", "field": "item.product_name", "width": 32, "header": "Item / Part Number"}, {"align": "left", "field": "item.description", "width": 48, "header": "Description"}, {"align": "right", "field": "item.quantity", "width": 16, "header": "Qty"}, {"align": "center", "field": "item.uom", "width": 16, "header": "UOM"}, {"align": "right", "field": "item.unit_price", "width": 30, "header": "Unit Price"}, {"align": "right", "field": "item.amount", "width": 30, "header": "Amount"}], "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "headerColor": "#FFFFFF", "headerBackground": "#18212F"}, {"x": 118, "y": 188, "id": "totals-box", "type": "rectangle", "color": "#111827", "width": 78, "height": 28, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#F3F4F6"}, {"x": 122, "y": 191, "id": "subtotal-label", "text": "Subtotal", "type": "text", "color": "#646464", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 191, "id": "subtotal", "type": "field", "color": "#111827", "field": "invoice.subtotal", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 198, "id": "tax-label", "type": "field", "color": "#646464", "field": "invoice.tax_label", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 198, "id": "tax", "type": "field", "color": "#111827", "field": "invoice.tax", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 205, "id": "total-line", "type": "line", "color": "#111827", "width": 70, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 122, "y": 208, "id": "total-label", "text": "Total Amount", "type": "text", "color": "#111827", "width": 32, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 208, "id": "total", "type": "field", "color": "#111827", "field": "invoice.total", "width": 38, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 220, "id": "cust-note-label", "text": "Customer Note:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 224, "id": "cust-note-field", "type": "field", "color": "#111827", "field": "invoice.customer_note", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 236, "id": "deliv-inst-label", "text": "Delivery Instructions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 240, "id": "deliv-inst-field", "type": "field", "color": "#111827", "field": "invoice.delivery_instructions", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 252, "id": "terms-label", "text": "Terms & Conditions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 256, "id": "terms-field", "type": "field", "color": "#111827", "field": "invoice.terms_and_conditions", "width": 90, "height": 18, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 224, "id": "authorised-sig-img", "type": "image", "color": "#111827", "field": "invoice.authorised_signature", "width": 45, "height": 15, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 240, "id": "authorised-sig-line", "type": "line", "color": "#111827", "width": 45, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 136, "y": 241, "id": "authorised-sig-label", "text": "Authorised Signature", "type": "text", "color": "#646464", "width": 45, "height": 4, "visible": true, "fontSize": 8, "textAlign": "center", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 278, "id": "footer-line", "type": "line", "color": "#111827", "width": 182, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D2D2D2"}, {"x": 14, "y": 281, "id": "footer-note", "text": "This is a computer-generated Purchase Order document and does not require a physical signature.", "type": "text", "color": "#AFAFAF", "width": 140, "height": 5, "visible": true, "fontSize": 6.5, "fontStyle": "italic", "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 281, "id": "page-number", "type": "page_number", "color": "#AFAFAF", "width": 42, "height": 5, "visible": true, "fontSize": 6.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}], "reportType": "purchase-order"}	t	f	\N	\N	2026-10-26 21:10:32.680827-07	2026-10-26 22:20:25.766-07
10	\N	10	Default Vendor Invoice Template	System default vendor invoice layout matching the BizOne document. Company data is bound at print time.	{"page": {"size": "A4", "margin": {"top": 10, "left": 14, "right": 14, "bottom": 12}, "orientation": "portrait"}, "version": 1, "elements": [{"x": 14, "y": 10, "id": "company-logo", "type": "image", "color": "#111827", "field": "company.logo", "width": 62, "height": 16, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 28, "id": "company-name", "type": "field", "color": "#111827", "field": "company.name", "width": 100, "height": 6, "visible": true, "fontSize": 11, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 35, "id": "company-address", "type": "field", "color": "#646464", "field": "company.address", "width": 108, "height": 10, "visible": true, "fontSize": 9, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 46, "id": "reg-label", "text": "Co. Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 46, "id": "company-reg", "type": "field", "color": "#646464", "field": "company.registration_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 50.5, "id": "gst-reg-label", "text": "GST Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 50.5, "id": "company-tax", "type": "field", "color": "#646464", "field": "company.tax_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 108, "y": 10, "id": "doc-title", "text": "VENDOR INVOICE", "type": "text", "color": "#18212F", "width": 88, "height": 11, "visible": true, "fontSize": 22, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 24, "id": "number-label", "text": "Number:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 24, "id": "invoice-number", "type": "field", "color": "#646464", "field": "invoice.invoice_number", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 30, "id": "date-label", "text": "Date:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 30, "id": "invoice-date", "type": "field", "color": "#646464", "field": "invoice.invoice_date", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 118, "y": 36, "id": "terms-meta-label", "text": "Payment Terms:", "type": "text", "color": "#646464", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 36, "id": "payment-terms", "type": "field", "color": "#646464", "field": "invoice.payment_terms", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 57, "id": "header-line", "type": "line", "color": "#111827", "width": 182, "height": 0.35, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#C8C8C8"}, {"x": 14, "y": 61, "id": "bill-to-label", "text": "Vendor:", "type": "text", "color": "#111827", "width": 80, "height": 5, "visible": true, "fontSize": 10, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 68, "id": "customer-name", "type": "field", "color": "#3C3C3C", "field": "customer.name", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 74, "id": "customer-address", "type": "field", "color": "#3C3C3C", "field": "customer.address", "width": 130, "height": 10, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 85, "id": "customer-attn", "type": "field", "color": "#3C3C3C", "field": "customer.contact_person", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 94, "id": "items-table", "type": "table", "color": "#111827", "width": 182, "height": 88, "source": "items", "columns": [{"align": "left", "field": "item.index", "width": 10, "header": "#"}, {"align": "left", "field": "item.product_name", "width": 32, "header": "Item / Part Number"}, {"align": "left", "field": "item.description", "width": 48, "header": "Description"}, {"align": "right", "field": "item.quantity", "width": 16, "header": "Qty"}, {"align": "center", "field": "item.uom", "width": 16, "header": "UOM"}, {"align": "right", "field": "item.unit_price", "width": 30, "header": "Unit Price"}, {"align": "right", "field": "item.amount", "width": 30, "header": "Amount"}], "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "headerColor": "#FFFFFF", "headerBackground": "#18212F"}, {"x": 118, "y": 188, "id": "totals-box", "type": "rectangle", "color": "#111827", "width": 78, "height": 28, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#F3F4F6"}, {"x": 122, "y": 191, "id": "subtotal-label", "text": "Subtotal", "type": "text", "color": "#646464", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 191, "id": "subtotal", "type": "field", "color": "#111827", "field": "invoice.subtotal", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 198, "id": "tax-label", "type": "field", "color": "#646464", "field": "invoice.tax_label", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 198, "id": "tax", "type": "field", "color": "#111827", "field": "invoice.tax", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 205, "id": "total-line", "type": "line", "color": "#111827", "width": 70, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 122, "y": 208, "id": "total-label", "text": "Total Amount", "type": "text", "color": "#111827", "width": 32, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 208, "id": "total", "type": "field", "color": "#111827", "field": "invoice.total", "width": 38, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 220, "id": "cust-note-label", "text": "Customer Note:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 224, "id": "cust-note-field", "type": "field", "color": "#111827", "field": "invoice.customer_note", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 236, "id": "deliv-inst-label", "text": "Delivery Instructions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 240, "id": "deliv-inst-field", "type": "field", "color": "#111827", "field": "invoice.delivery_instructions", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 252, "id": "terms-label", "text": "Terms & Conditions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 256, "id": "terms-field", "type": "field", "color": "#111827", "field": "invoice.terms_and_conditions", "width": 90, "height": 18, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 224, "id": "authorised-sig-img", "type": "image", "color": "#111827", "field": "invoice.authorised_signature", "width": 45, "height": 15, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 240, "id": "authorised-sig-line", "type": "line", "color": "#111827", "width": 45, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 136, "y": 241, "id": "authorised-sig-label", "text": "Authorised Signature", "type": "text", "color": "#646464", "width": 45, "height": 4, "visible": true, "fontSize": 8, "textAlign": "center", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 278, "id": "footer-line", "type": "line", "color": "#111827", "width": 182, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D2D2D2"}, {"x": 14, "y": 281, "id": "footer-note", "text": "This is a computer-generated Vendor Invoice document and does not require a physical signature.", "type": "text", "color": "#AFAFAF", "width": 140, "height": 5, "visible": true, "fontSize": 6.5, "fontStyle": "italic", "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 281, "id": "page-number", "type": "page_number", "color": "#AFAFAF", "width": 42, "height": 5, "visible": true, "fontSize": 6.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}], "reportType": "vendor-invoice"}	t	f	\N	\N	2026-10-26 21:10:32.702599-07	2026-10-26 22:20:25.77-07
11	\N	11	Default Goods Receipt Note Template	System default goods receipt note layout matching the BizOne document. Company data is bound at print time.	{"page": {"size": "A4", "margin": {"top": 10, "left": 14, "right": 14, "bottom": 12}, "orientation": "portrait"}, "version": 1, "elements": [{"x": 14, "y": 10, "id": "company-logo", "type": "image", "color": "#111827", "field": "company.logo", "width": 62, "height": 16, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 28, "id": "company-name", "type": "field", "color": "#111827", "field": "company.name", "width": 100, "height": 6, "visible": true, "fontSize": 11, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 35, "id": "company-address", "type": "field", "color": "#646464", "field": "company.address", "width": 108, "height": 10, "visible": true, "fontSize": 9, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 46, "id": "reg-label", "text": "Co. Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 46, "id": "company-reg", "type": "field", "color": "#646464", "field": "company.registration_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 50.5, "id": "gst-reg-label", "text": "GST Reg. No.:", "type": "text", "color": "#646464", "width": 26, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 40, "y": 50.5, "id": "company-tax", "type": "field", "color": "#646464", "field": "company.tax_number", "width": 82, "height": 4, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 108, "y": 10, "id": "doc-title", "text": "GOODS RECEIPT NOTE", "type": "text", "color": "#18212F", "width": 88, "height": 11, "visible": true, "fontSize": 22, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 24, "id": "number-label", "text": "Number:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 24, "id": "invoice-number", "type": "field", "color": "#646464", "field": "invoice.invoice_number", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 128, "y": 30, "id": "date-label", "text": "Date:", "type": "text", "color": "#646464", "width": 28, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 30, "id": "invoice-date", "type": "field", "color": "#646464", "field": "invoice.invoice_date", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 118, "y": 36, "id": "terms-meta-label", "text": "Payment Terms:", "type": "text", "color": "#646464", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 157, "y": 36, "id": "payment-terms", "type": "field", "color": "#646464", "field": "invoice.payment_terms", "width": 39, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 57, "id": "header-line", "type": "line", "color": "#111827", "width": 182, "height": 0.35, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#C8C8C8"}, {"x": 14, "y": 61, "id": "bill-to-label", "text": "Vendor:", "type": "text", "color": "#111827", "width": 80, "height": 5, "visible": true, "fontSize": 10, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 68, "id": "customer-name", "type": "field", "color": "#3C3C3C", "field": "customer.name", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 74, "id": "customer-address", "type": "field", "color": "#3C3C3C", "field": "customer.address", "width": 130, "height": 10, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 85, "id": "customer-attn", "type": "field", "color": "#3C3C3C", "field": "customer.contact_person", "width": 120, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 94, "id": "items-table", "type": "table", "color": "#111827", "width": 182, "height": 88, "source": "items", "columns": [{"align": "left", "field": "item.index", "width": 10, "header": "#"}, {"align": "left", "field": "item.product_name", "width": 32, "header": "Item / Part Number"}, {"align": "left", "field": "item.description", "width": 48, "header": "Description"}, {"align": "right", "field": "item.quantity", "width": 16, "header": "Qty"}, {"align": "center", "field": "item.uom", "width": 16, "header": "UOM"}, {"align": "right", "field": "item.unit_price", "width": 30, "header": "Unit Price"}, {"align": "right", "field": "item.amount", "width": 30, "header": "Amount"}], "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "headerColor": "#FFFFFF", "headerBackground": "#18212F"}, {"x": 118, "y": 188, "id": "totals-box", "type": "rectangle", "color": "#111827", "width": 78, "height": 28, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#F3F4F6"}, {"x": 122, "y": 191, "id": "subtotal-label", "text": "Subtotal", "type": "text", "color": "#646464", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 191, "id": "subtotal", "type": "field", "color": "#111827", "field": "invoice.subtotal", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 198, "id": "tax-label", "type": "field", "color": "#646464", "field": "invoice.tax_label", "width": 32, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 198, "id": "tax", "type": "field", "color": "#111827", "field": "invoice.tax", "width": 38, "height": 5, "visible": true, "fontSize": 9.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 122, "y": 205, "id": "total-line", "type": "line", "color": "#111827", "width": 70, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 122, "y": 208, "id": "total-label", "text": "Total Amount", "type": "text", "color": "#111827", "width": 32, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 208, "id": "total", "type": "field", "color": "#111827", "field": "invoice.total", "width": 38, "height": 6, "visible": true, "fontSize": 10.5, "textAlign": "right", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 220, "id": "cust-note-label", "text": "Customer Note:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 224, "id": "cust-note-field", "type": "field", "color": "#111827", "field": "invoice.customer_note", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 236, "id": "deliv-inst-label", "text": "Delivery Instructions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 240, "id": "deliv-inst-field", "type": "field", "color": "#111827", "field": "invoice.delivery_instructions", "width": 90, "height": 10, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 252, "id": "terms-label", "text": "Terms & Conditions:", "type": "text", "color": "#646464", "width": 90, "height": 4, "visible": true, "fontSize": 7.5, "textAlign": "left", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 256, "id": "terms-field", "type": "field", "color": "#111827", "field": "invoice.terms_and_conditions", "width": 90, "height": 18, "visible": true, "fontSize": 8, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 224, "id": "authorised-sig-img", "type": "image", "color": "#111827", "field": "invoice.authorised_signature", "width": 45, "height": 15, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 136, "y": 240, "id": "authorised-sig-line", "type": "line", "color": "#111827", "width": 45, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D1D5DB"}, {"x": 136, "y": 241, "id": "authorised-sig-label", "text": "Authorised Signature", "type": "text", "color": "#646464", "width": 45, "height": 4, "visible": true, "fontSize": 8, "textAlign": "center", "fontWeight": "bold", "borderStyle": "none", "borderWidth": 0}, {"x": 14, "y": 278, "id": "footer-line", "type": "line", "color": "#111827", "width": 182, "height": 0.25, "visible": true, "fontSize": 9.5, "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0, "backgroundColor": "#D2D2D2"}, {"x": 14, "y": 281, "id": "footer-note", "text": "This is a computer-generated Goods Receipt Note document and does not require a physical signature.", "type": "text", "color": "#AFAFAF", "width": 140, "height": 5, "visible": true, "fontSize": 6.5, "fontStyle": "italic", "textAlign": "left", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}, {"x": 154, "y": 281, "id": "page-number", "type": "page_number", "color": "#AFAFAF", "width": 42, "height": 5, "visible": true, "fontSize": 6.5, "textAlign": "right", "fontWeight": "normal", "borderStyle": "none", "borderWidth": 0}], "reportType": "grn"}	t	f	\N	\N	2026-10-26 21:10:32.720098-07	2026-10-26 22:20:25.774-07
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
248	1
248	2
248	3
248	4
248	5
248	6
248	7
248	8
248	9
248	10
248	11
248	12
248	13
248	14
248	15
248	16
248	17
248	18
248	19
248	20
248	25
248	26
248	27
248	28
248	29
248	30
248	31
248	32
248	33
248	34
248	35
248	36
248	37
248	38
248	39
248	40
248	41
248	42
248	43
248	44
248	45
248	46
248	47
248	48
248	49
248	50
248	51
248	52
248	53
248	54
248	55
248	56
248	57
248	58
248	59
248	60
248	61
248	62
248	63
248	64
248	65
248	66
248	67
248	68
248	69
248	70
248	71
248	72
248	73
248	74
248	75
248	76
248	77
248	78
248	79
248	80
248	81
248	82
248	83
248	84
248	85
248	86
248	87
248	88
248	89
248	90
248	91
248	92
248	93
248	94
248	95
248	96
248	97
248	98
248	99
248	100
248	101
248	102
248	103
248	104
248	105
248	106
248	107
248	108
248	109
248	110
248	111
248	112
248	113
248	114
248	115
248	116
248	117
248	118
248	119
248	120
248	121
248	122
248	123
248	124
248	125
248	126
248	127
248	128
248	129
248	130
248	131
248	132
248	133
248	134
248	135
248	136
248	137
248	138
248	139
248	140
248	141
248	142
248	143
248	144
248	145
248	146
248	147
248	148
248	149
248	150
248	151
248	152
248	153
248	154
248	155
248	156
248	157
248	158
248	159
248	160
248	161
248	162
248	163
248	164
248	165
248	166
248	167
248	168
248	169
248	170
248	171
248	172
248	173
248	174
248	175
248	176
248	177
248	178
248	179
248	180
248	181
248	182
248	183
248	184
248	185
248	186
248	187
248	188
248	1153
248	1154
248	1155
248	1156
248	1177
248	1178
248	1179
248	1180
248	1225
248	1226
248	1227
248	1228
248	1261
248	1262
248	1263
248	1264
248	1317
248	1318
248	1319
248	1320
248	1321
248	1322
248	1323
248	1324
248	6765
248	6766
248	6767
248	6768
248	9501
248	9502
248	9503
248	9504
248	13461
248	13462
248	13463
248	13464
248	40560
248	40561
248	40562
248	40563
248	57556
248	57557
248	57558
248	57559
248	57560
248	57561
248	57562
248	57563
248	57564
248	57565
248	57566
248	57567
248	57568
248	57569
248	57570
248	57571
248	57572
248	57573
248	57574
248	57575
248	57820
248	57821
248	57822
248	57823
248	66696
248	66697
248	66698
248	66699
249	1
249	2
249	3
249	5
249	6
249	7
249	9
249	10
249	11
249	13
249	14
249	15
249	17
249	18
249	19
249	25
249	26
249	27
249	29
249	30
249	31
249	33
249	34
249	35
249	37
249	38
249	39
249	41
249	42
249	43
249	45
249	46
249	47
249	49
249	50
249	51
249	53
249	54
249	55
249	57
249	58
249	59
249	61
249	62
249	63
249	65
249	66
249	67
249	69
249	70
249	71
249	73
249	74
249	75
249	77
249	78
249	79
249	81
249	82
249	83
249	85
249	86
249	87
249	89
249	90
249	91
249	93
249	94
249	95
249	97
249	98
249	99
249	101
249	102
249	103
249	105
249	106
249	107
249	109
249	110
249	111
249	113
249	114
249	115
249	117
249	118
249	119
249	121
249	122
249	123
249	125
249	126
249	127
249	129
249	130
249	131
249	133
249	134
249	135
249	137
249	138
249	139
249	141
249	142
249	143
249	145
249	146
249	147
249	149
249	150
249	151
249	153
249	154
249	155
249	157
249	158
249	159
249	161
249	162
249	163
249	165
249	166
249	167
249	169
249	170
249	171
249	173
249	174
249	175
249	177
249	178
249	179
249	181
249	182
249	183
249	185
249	186
249	187
249	1153
249	1154
249	1155
249	1177
249	1178
249	1179
249	1225
249	1226
249	1227
249	1261
249	1262
249	1263
249	1317
249	1318
249	1319
249	1321
249	1322
249	1323
249	6765
249	6766
249	6767
249	9501
249	9502
249	9503
249	13461
249	13462
249	13463
249	40560
249	40561
249	40562
249	57556
249	57557
249	57558
249	57560
249	57561
249	57562
249	57564
249	57565
249	57566
249	57568
249	57569
249	57570
249	57572
249	57573
249	57574
249	57820
249	57821
249	57822
249	66696
249	66697
249	66698
250	1
250	5
250	9
250	13
251	1
251	2
251	3
251	4
251	17
251	18
251	19
251	20
251	37
251	38
251	39
251	40
251	41
251	42
251	43
251	44
251	45
251	46
251	47
251	48
251	97
251	98
251	99
251	100
251	101
251	102
251	103
251	104
251	105
251	106
251	107
251	108
251	109
251	110
251	111
251	112
251	113
251	114
251	115
251	116
251	117
251	118
251	119
251	120
251	121
251	122
251	123
251	124
251	125
251	126
251	127
251	128
251	129
251	130
251	131
251	132
251	133
251	134
251	135
251	136
251	137
251	138
251	139
251	140
251	141
251	142
251	143
251	144
251	145
251	146
251	147
251	148
251	149
251	150
251	151
251	152
251	153
251	154
251	155
251	156
251	157
251	158
251	159
251	160
251	161
251	162
251	163
251	164
251	165
251	166
251	167
251	168
251	169
251	170
251	171
251	172
251	173
251	174
251	175
251	176
251	1177
251	1178
251	1179
251	1180
251	9501
251	9502
251	9503
251	9504
252	1
252	2
252	3
252	29
252	30
252	31
252	33
252	34
252	35
252	37
252	38
252	39
252	89
252	90
252	91
252	9501
252	9502
252	9503
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, company_id, created_at, updated_at) FROM stdin;
248	Administrator	24	2026-10-26 21:08:54.111-07	2026-10-26 21:08:54.111-07
249	Manager	24	2026-10-26 21:08:54.111-07	2026-10-26 21:08:54.111-07
250	Employee	24	2026-10-26 21:08:54.111-07	2026-10-26 21:08:54.111-07
251	Accountant	24	2026-10-26 21:08:54.111-07	2026-10-26 21:08:54.111-07
252	Sales User	24	2026-10-26 21:08:54.111-07	2026-10-26 21:08:54.111-07
\.


--
-- Data for Name: sales_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_orders (id, so_number, company_id, qt_id, qt_number, customer_name, customer_address, customer_contact, customer_contact_email, delivery_address, issue_date, delivery_date, payment_terms, notes, is_private, items, subtotal, discount_amount, tax, total_amount, currency, status, email_sent_to, created_by, created_at, inv_id, inv_number, do_id, do_number, terms_and_conditions, delivery_instructions, customer_note, authorised_signature, attachment_path, attachment_name) FROM stdin;
\.


--
-- Data for Name: sales_persons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_persons (id, company_id, name, employment_code, password_hash, department, phone, country, address, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_reports (id, company_id, csr_number, customer_id, customer_name, customer_address, customer_contact_person, customer_phone, customer_email, support_requested_by, support_request_date, problem_description, engineer_id, service_date, service_time, hours_charged, service_details, remarks, priority_level, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.session (sid, sess, expire) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, company_id, gst_rate, smtp_host, smtp_port, smtp_user, smtp_pass, smtp_from, po_prefix, po_counter, po_suffix, inv_prefix, inv_counter, inv_suffix, qt_prefix, qt_counter, qt_suffix, do_prefix, do_counter, do_suffix, grn_prefix, grn_counter, grn_suffix, cn_prefix, cn_counter, cn_suffix, pi_prefix, pi_counter, pi_suffix, pv_prefix, pv_counter, pv_suffix, allow_negative_stock, auto_deduct_on_do, low_stock_warning, default_uom, bank_details, terms_and_conditions, quotation_terms, default_verifier_id, default_approver_id, default_paid_by_id, igr_prefix, igr_counter, igr_suffix, gin_prefix, gin_counter, gin_suffix, st_prefix, st_counter, st_suffix, sa_prefix, sa_counter, sa_suffix, si_prefix, si_counter, si_suffix, dn_prefix, dn_counter, dn_suffix, so_prefix, so_counter, so_suffix, pq_prefix, pq_counter, pq_suffix, fa_prefix, fa_counter, fa_suffix, bc_prefix, bc_counter, bc_suffix, vpi_prefix, vpi_counter, vpi_suffix) FROM stdin;
1	24	9.00	\N	\N	\N	\N	\N	PO	0		INV	0		QT	0		DO	0		GRN	0		CN	1		PI	1		PV	1		f	f	0.000	pcs	\N	\N	\N	\N	\N	\N	IGR	1		GIN	1		ST	1		SA	1		STK	1		DN	1		SO	0		PQ	0		FA	0		BC	0		VPI	0	
\.


--
-- Data for Name: stock_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_adjustments (id, company_id, adjustment_number, warehouse_id, stock_item_id, adjustment_type, reason, current_quantity, actual_quantity, difference, remarks, adjustment_date, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_item_purchase_prices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_item_purchase_prices (id, company_id, stock_item_id, purchase_price, quantity, effective_date, source_type, source_id, source_ref, notes, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: stock_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_items (id, company_id, code, name, description, uom, type, unit_price, stock_qty, is_active, created_at, min_stock_level, reorder_level, max_stock_level, created_by, updated_by, updated_at, batch_no, mrp_price, alternate_uom, alternate_qty, main_qty, is_weight_based, category, sub_category, brand, barcode, sales_person, item_image, purchase_price, track_inventory, show_in_pos, pricing_method, tax_percent, expiry_date, manufacturing_date, batches_json, stock_group) FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_movements (id, company_id, warehouse_id, stock_item_id, transaction_type, document_number, reference_type, reference_id, quantity_in, quantity_out, balance, reference, user_id, username, movement_date, created_at) FROM stdin;
\.


--
-- Data for Name: stock_serials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_serials (id, company_id, stock_item_id, serial_number, status, grn_id, grn_number, invoice_id, invoice_number, reserved_by_user, do_id, do_number, created_at, batch_no, expiry_date, manufacturing_date) FROM stdin;
\.


--
-- Data for Name: stock_transfer_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_transfer_items (id, stock_transfer_id, stock_item_id, quantity) FROM stdin;
\.


--
-- Data for Name: stock_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_transfers (id, company_id, transfer_number, from_warehouse_id, to_warehouse_id, transfer_date, remarks, status, created_by, updated_by, created_at, updated_at, sales_person) FROM stdin;
\.


--
-- Data for Name: tax_filings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_filings (id, company_id, type, financial_year, fy_end_date, revenue, chargeable_income, tax_payable, status, filed_date, reference_no, data, notes, created_at, updated_at, created_by) FROM stdin;
\.


--
-- Data for Name: user_companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_companies (id, user_id, company_id, modules) FROM stdin;
72	34	24	["dashboard", "assets", "licenses", "employees", "payroll", "purchase_quotations", "purchase_orders", "vendor_invoices", "vendor_proforma_invoices", "quotations", "sales_orders", "invoices", "proforma_invoices", "delivery_orders", "credit_notes", "debit_notes", "point_of_sale", "pos_retail", "pos_supermarket", "pos_restaurants", "pos_pharmacy", "pos_electronics", "pos_reports", "bill_of_materials", "multi_price_level", "grn", "stock_items", "warehouses", "stock_transfer", "inventory_reports", "sales_person_wise_report", "batch_expiry", "vendors", "customers", "address_book", "projects", "accounting_coa", "accounting_je", "accounting_gl", "accounting_tb", "accounting_bs", "accounting_pl", "accounting_cf", "accounting_bank_recon", "accounting_gst_f5", "accounting_gst_f7", "accounting_gst_io", "accounting_wht", "accounting_eci", "accounting_formcs", "accounting_iaf", "accounting_ar", "accounting_ar_aging", "accounting_cust_stmt", "accounting_ap", "accounting_ap_aging", "accounting_vendor_stmt", "accounting_expenses", "accounting_income", "user_management", "audit_log", "settings", "report_templates"]
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, password_hash, role, email, created_at, full_name, phone_number, is_active, updated_at, company_id, role_id, sales_person_id, database_name) FROM stdin;
34	msmsolutions@gmail.com	$2b$10$BgzGxNUdhwu2g7qJiv139uI.1AddBNasBdJskaqNlBMwnInvvgrwy	admin	msmsolutions@gmail.com	2026-10-26 21:08:54.111-07	MSM Solutions	+65 2156 2750	t	2026-10-26 21:08:54.111-07	24	248	\N	bizone_msmsolutions
\.


--
-- Data for Name: vendor_invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_invoices (id, company_id, pi_number, pi_date, vendor_name, po_ids, po_numbers, currency, total_amount, paid_amount, status, notes, expense_account_id, created_by, created_at, updated_at, items, subtotal, tax, exchange_rate, gst_treatment, gst_rate, gst_amount, gst_inclusive, payment_terms, due_date, planned_payment_date, reminders_enabled, reminder_start_day, reminder_extra_recipients, reminder_extra_emails, reminder_start_after_day, reminder_emails, sales_person, customer_note, delivery_instructions, terms_and_conditions, authorised_signature, discount_amount, attachment_path, attachment_name) FROM stdin;
\.


--
-- Data for Name: vendor_opening_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_opening_balances (id, company_id, financial_year_id, vendor_id, vendor_name, amount, currency, created_at) FROM stdin;
\.


--
-- Data for Name: vendor_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_payments (id, company_id, vendor_invoice_id, payment_date, amount, reference, payment_method, notes, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: vendor_proforma_invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_proforma_invoices (id, vpi_number, company_id, vendor_name, vendor_address, vendor_contact, vendor_contact_email, delivery_address, issue_date, delivery_date, payment_terms, notes, is_private, items, subtotal, discount_amount, tax, total_amount, currency, pq_ref_no, status, email_sent_to, terms_and_conditions, delivery_instructions, customer_note, authorised_signature, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, company_id, name, address, postal_code, country, contact_person, contact_email, phone, currency, gst_registered, gst_no, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: voucher_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.voucher_attachments (id, voucher_id, file_name, mime_type, file_data, created_at) FROM stdin;
\.


--
-- Data for Name: vouchers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vouchers (id, voucher_number, company_id, project_id, type, payee, payee_contact, issue_date, description, status, items, total_amount, currency, paid_date, bank_ref, notes, proof_data, proof_mime_type, created_by, prepared_by_name, verifier_id, approver_id, paid_by_id, verified_at, approved_at, created_at) FROM stdin;
\.


--
-- Data for Name: warehouse_stock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warehouse_stock (id, company_id, warehouse_id, stock_item_id, quantity, updated_at) FROM stdin;
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warehouses (id, company_id, code, name, description, address, city, country, contact_person, contact_number, email, is_default, is_active, created_by, updated_by, created_at, updated_at, state, pin_code, remarks) FROM stdin;
\.


--
-- Data for Name: wht_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wht_records (id, company_id, vendor_name, vendor_country, payment_date, nature, payment_type, currency, gross_amount, wht_rate, wht_amount, net_amount, filing_deadline, status, filed_date, reference_no, notes, created_at, created_by) FROM stdin;
\.


--
-- Name: accounting_backups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounting_backups_id_seq', 1, false);


--
-- Name: accounting_restore_operations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounting_restore_operations_id_seq', 1, false);


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounts_id_seq', 1, false);


--
-- Name: asset_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.asset_assignments_id_seq', 1, false);


--
-- Name: assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assets_id_seq', 1, false);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: backup_retention_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.backup_retention_settings_id_seq', 1, false);


--
-- Name: backup_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.backup_schedules_id_seq', 1, false);


--
-- Name: bank_opening_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_opening_balances_id_seq', 1, false);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.companies_id_seq', 24, true);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversations_id_seq', 1, false);


--
-- Name: credit_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_notes_id_seq', 1, false);


--
-- Name: customer_deposits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_deposits_id_seq', 1, false);


--
-- Name: customer_opening_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_opening_balances_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 1, false);


--
-- Name: debit_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.debit_notes_id_seq', 1, false);


--
-- Name: delivery_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.delivery_orders_id_seq', 1, false);


--
-- Name: dependents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dependents_id_seq', 1, false);


--
-- Name: email_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_contacts_id_seq', 1, false);


--
-- Name: employee_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_documents_id_seq', 1, false);


--
-- Name: employee_payroll_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_payroll_id_seq', 1, false);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employees_id_seq', 1, false);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expenses_id_seq', 1, false);


--
-- Name: financial_years_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.financial_years_id_seq', 1, true);


--
-- Name: fixed_asset_opening_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fixed_asset_opening_balances_id_seq', 1, false);


--
-- Name: goods_issue_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.goods_issue_items_id_seq', 1, false);


--
-- Name: goods_issues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.goods_issues_id_seq', 1, false);


--
-- Name: goods_receipt_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.goods_receipt_items_id_seq', 1, false);


--
-- Name: goods_receipts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.goods_receipts_id_seq', 1, false);


--
-- Name: grn_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grn_id_seq', 1, false);


--
-- Name: income_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.income_attachments_id_seq', 1, false);


--
-- Name: income_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.income_records_id_seq', 1, false);


--
-- Name: inventory_opening_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_opening_balances_id_seq', 1, false);


--
-- Name: invoice_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_payments_id_seq', 1, false);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoices_id_seq', 1, false);


--
-- Name: ir8a_employers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ir8a_employers_id_seq', 1, false);


--
-- Name: journal_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.journal_entries_id_seq', 1, false);


--
-- Name: journal_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.journal_lines_id_seq', 1, false);


--
-- Name: licenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.licenses_id_seq', 1, false);


--
-- Name: maintenance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.maintenance_id_seq', 1, false);


--
-- Name: maintenance_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.maintenance_records_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: opening_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.opening_balances_id_seq', 1, false);


--
-- Name: opening_stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.opening_stock_id_seq', 1, false);


--
-- Name: ops_asset_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ops_asset_assignments_id_seq', 1, false);


--
-- Name: ops_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ops_assets_id_seq', 1, false);


--
-- Name: ops_company_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ops_company_documents_id_seq', 1, false);


--
-- Name: ops_employee_payroll_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ops_employee_payroll_id_seq', 1, false);


--
-- Name: ops_employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ops_employees_id_seq', 1, false);


--
-- Name: ops_licenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ops_licenses_id_seq', 1, false);


--
-- Name: ops_payroll_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ops_payroll_records_id_seq', 1, false);


--
-- Name: ops_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ops_tasks_id_seq', 1, false);


--
-- Name: payroll_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_records_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 1, false);


--
-- Name: proforma_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.proforma_invoices_id_seq', 1, false);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, false);


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_orders_id_seq', 1, false);


--
-- Name: purchase_quotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_quotations_id_seq', 1, false);


--
-- Name: quotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotations_id_seq', 1, false);


--
-- Name: report_definitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.report_definitions_id_seq', 11, true);


--
-- Name: report_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.report_fields_id_seq', 517, true);


--
-- Name: report_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.report_templates_id_seq', 11, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 252, true);


--
-- Name: sales_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_orders_id_seq', 1, false);


--
-- Name: sales_persons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_persons_id_seq', 1, false);


--
-- Name: service_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_reports_id_seq', 1, false);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.settings_id_seq', 1, true);


--
-- Name: stock_adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_adjustments_id_seq', 1, false);


--
-- Name: stock_item_purchase_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_item_purchase_prices_id_seq', 1, false);


--
-- Name: stock_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_items_id_seq', 1, false);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 1, false);


--
-- Name: stock_serials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_serials_id_seq', 1, false);


--
-- Name: stock_transfer_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_transfer_items_id_seq', 1, false);


--
-- Name: stock_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_transfers_id_seq', 1, false);


--
-- Name: tax_filings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tax_filings_id_seq', 1, false);


--
-- Name: user_companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_companies_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: vendor_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendor_invoices_id_seq', 1, false);


--
-- Name: vendor_opening_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendor_opening_balances_id_seq', 1, false);


--
-- Name: vendor_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendor_payments_id_seq', 1, false);


--
-- Name: vendor_proforma_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendor_proforma_invoices_id_seq', 1, false);


--
-- Name: vendors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendors_id_seq', 1, false);


--
-- Name: voucher_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.voucher_attachments_id_seq', 1, false);


--
-- Name: vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vouchers_id_seq', 1, false);


--
-- Name: warehouse_stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warehouse_stock_id_seq', 1, false);


--
-- Name: warehouses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warehouses_id_seq', 1, false);


--
-- Name: wht_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wht_records_id_seq', 1, false);


--
-- Name: accounting_backups accounting_backups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_backups
    ADD CONSTRAINT accounting_backups_pkey PRIMARY KEY (id);


--
-- Name: accounting_restore_operations accounting_restore_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_restore_operations
    ADD CONSTRAINT accounting_restore_operations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_company_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_company_code_unique UNIQUE (company_id, code);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: asset_assignments asset_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_assignments
    ADD CONSTRAINT asset_assignments_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_retention_settings backup_retention_settings_company_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_retention_settings
    ADD CONSTRAINT backup_retention_settings_company_id_key UNIQUE (company_id);


--
-- Name: backup_retention_settings backup_retention_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_retention_settings
    ADD CONSTRAINT backup_retention_settings_pkey PRIMARY KEY (id);


--
-- Name: backup_schedules backup_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_schedules
    ADD CONSTRAINT backup_schedules_pkey PRIMARY KEY (id);


--
-- Name: bank_opening_balances bank_opening_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_opening_balances
    ADD CONSTRAINT bank_opening_balances_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: credit_notes credit_notes_company_cn_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT credit_notes_company_cn_number_unique UNIQUE (company_id, cn_number);


--
-- Name: credit_notes credit_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT credit_notes_pkey PRIMARY KEY (id);


--
-- Name: customer_deposits customer_deposits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_deposits
    ADD CONSTRAINT customer_deposits_pkey PRIMARY KEY (id);


--
-- Name: customer_opening_balances customer_opening_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_opening_balances
    ADD CONSTRAINT customer_opening_balances_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: debit_notes debit_notes_company_dn_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.debit_notes
    ADD CONSTRAINT debit_notes_company_dn_number_unique UNIQUE (company_id, dn_number);


--
-- Name: debit_notes debit_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.debit_notes
    ADD CONSTRAINT debit_notes_pkey PRIMARY KEY (id);


--
-- Name: delivery_orders delivery_orders_do_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_orders
    ADD CONSTRAINT delivery_orders_do_number_key UNIQUE (do_number);


--
-- Name: delivery_orders delivery_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_orders
    ADD CONSTRAINT delivery_orders_pkey PRIMARY KEY (id);


--
-- Name: dependents dependents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dependents
    ADD CONSTRAINT dependents_pkey PRIMARY KEY (id);


--
-- Name: email_contacts email_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_contacts
    ADD CONSTRAINT email_contacts_pkey PRIMARY KEY (id);


--
-- Name: employee_documents employee_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_documents
    ADD CONSTRAINT employee_documents_pkey PRIMARY KEY (id);


--
-- Name: employee_payroll employee_payroll_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_payroll
    ADD CONSTRAINT employee_payroll_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: financial_years financial_years_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_years
    ADD CONSTRAINT financial_years_pkey PRIMARY KEY (id);


--
-- Name: fixed_asset_opening_balances fixed_asset_opening_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_asset_opening_balances
    ADD CONSTRAINT fixed_asset_opening_balances_pkey PRIMARY KEY (id);


--
-- Name: goods_issue_items goods_issue_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_issue_items
    ADD CONSTRAINT goods_issue_items_pkey PRIMARY KEY (id);


--
-- Name: goods_issues goods_issues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_issues
    ADD CONSTRAINT goods_issues_pkey PRIMARY KEY (id);


--
-- Name: goods_receipt_items goods_receipt_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_pkey PRIMARY KEY (id);


--
-- Name: goods_receipts goods_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT goods_receipts_pkey PRIMARY KEY (id);


--
-- Name: grn grn_grn_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn
    ADD CONSTRAINT grn_grn_number_key UNIQUE (grn_number);


--
-- Name: grn grn_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn
    ADD CONSTRAINT grn_pkey PRIMARY KEY (id);


--
-- Name: income_attachments income_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.income_attachments
    ADD CONSTRAINT income_attachments_pkey PRIMARY KEY (id);


--
-- Name: income_records income_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.income_records
    ADD CONSTRAINT income_records_pkey PRIMARY KEY (id);


--
-- Name: inventory_opening_balances inventory_opening_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_opening_balances
    ADD CONSTRAINT inventory_opening_balances_pkey PRIMARY KEY (id);


--
-- Name: invoice_payments invoice_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_company_inv_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_company_inv_number_unique UNIQUE (company_id, inv_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: ir8a_employers ir8a_employers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ir8a_employers
    ADD CONSTRAINT ir8a_employers_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_lines journal_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_pkey PRIMARY KEY (id);


--
-- Name: licenses licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_pkey PRIMARY KEY (id);


--
-- Name: login_credentials login_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_credentials
    ADD CONSTRAINT login_credentials_pkey PRIMARY KEY (user_id);


--
-- Name: maintenance maintenance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance
    ADD CONSTRAINT maintenance_pkey PRIMARY KEY (id);


--
-- Name: maintenance_records maintenance_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_records
    ADD CONSTRAINT maintenance_records_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: opening_balances opening_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opening_balances
    ADD CONSTRAINT opening_balances_pkey PRIMARY KEY (id);


--
-- Name: opening_stock opening_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opening_stock
    ADD CONSTRAINT opening_stock_pkey PRIMARY KEY (id);


--
-- Name: opening_stock opening_stock_warehouse_id_stock_item_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opening_stock
    ADD CONSTRAINT opening_stock_warehouse_id_stock_item_id_key UNIQUE (warehouse_id, stock_item_id);


--
-- Name: ops_asset_assignments ops_asset_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_asset_assignments
    ADD CONSTRAINT ops_asset_assignments_pkey PRIMARY KEY (id);


--
-- Name: ops_assets ops_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_assets
    ADD CONSTRAINT ops_assets_pkey PRIMARY KEY (id);


--
-- Name: ops_company_documents ops_company_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_company_documents
    ADD CONSTRAINT ops_company_documents_pkey PRIMARY KEY (id);


--
-- Name: ops_employee_payroll ops_employee_payroll_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_employee_payroll
    ADD CONSTRAINT ops_employee_payroll_pkey PRIMARY KEY (id);


--
-- Name: ops_employees ops_employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_employees
    ADD CONSTRAINT ops_employees_pkey PRIMARY KEY (id);


--
-- Name: ops_licenses ops_licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_licenses
    ADD CONSTRAINT ops_licenses_pkey PRIMARY KEY (id);


--
-- Name: ops_payroll_records ops_payroll_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_payroll_records
    ADD CONSTRAINT ops_payroll_records_pkey PRIMARY KEY (id);


--
-- Name: ops_tasks ops_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_tasks
    ADD CONSTRAINT ops_tasks_pkey PRIMARY KEY (id);


--
-- Name: payroll_records payroll_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records
    ADD CONSTRAINT payroll_records_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_module_action_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_module_action_unique UNIQUE (module, action);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: pos_sales pos_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_sales
    ADD CONSTRAINT pos_sales_pkey PRIMARY KEY (id);


--
-- Name: proforma_invoices proforma_invoices_company_pi_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_invoices
    ADD CONSTRAINT proforma_invoices_company_pi_number_unique UNIQUE (company_id, pi_number);


--
-- Name: proforma_invoices proforma_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_invoices
    ADD CONSTRAINT proforma_invoices_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_po_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_po_number_key UNIQUE (po_number);


--
-- Name: purchase_quotations purchase_quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_quotations
    ADD CONSTRAINT purchase_quotations_pkey PRIMARY KEY (id);


--
-- Name: purchase_quotations purchase_quotations_pq_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_quotations
    ADD CONSTRAINT purchase_quotations_pq_number_key UNIQUE (pq_number);


--
-- Name: quotations quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_pkey PRIMARY KEY (id);


--
-- Name: quotations quotations_qt_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_qt_number_key UNIQUE (qt_number);


--
-- Name: report_definitions report_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_definitions
    ADD CONSTRAINT report_definitions_pkey PRIMARY KEY (id);


--
-- Name: report_fields report_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_fields
    ADD CONSTRAINT report_fields_pkey PRIMARY KEY (id);


--
-- Name: report_templates report_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_templates
    ADD CONSTRAINT report_templates_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_role_id_permission_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_permission_id_unique UNIQUE (role_id, permission_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sales_orders sales_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_pkey PRIMARY KEY (id);


--
-- Name: sales_orders sales_orders_so_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_so_number_key UNIQUE (so_number);


--
-- Name: sales_persons sales_persons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_persons
    ADD CONSTRAINT sales_persons_pkey PRIMARY KEY (id);


--
-- Name: service_reports service_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_reports
    ADD CONSTRAINT service_reports_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: stock_adjustments stock_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_pkey PRIMARY KEY (id);


--
-- Name: stock_item_purchase_prices stock_item_purchase_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_purchase_prices
    ADD CONSTRAINT stock_item_purchase_prices_pkey PRIMARY KEY (id);


--
-- Name: stock_items stock_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_items
    ADD CONSTRAINT stock_items_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: stock_serials stock_serials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_serials
    ADD CONSTRAINT stock_serials_pkey PRIMARY KEY (id);


--
-- Name: stock_transfer_items stock_transfer_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_pkey PRIMARY KEY (id);


--
-- Name: stock_transfers stock_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_pkey PRIMARY KEY (id);


--
-- Name: tax_filings tax_filings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_filings
    ADD CONSTRAINT tax_filings_pkey PRIMARY KEY (id);


--
-- Name: user_companies user_companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_companies
    ADD CONSTRAINT user_companies_pkey PRIMARY KEY (id);


--
-- Name: user_companies user_companies_user_id_company_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_companies
    ADD CONSTRAINT user_companies_user_id_company_id_key UNIQUE (user_id, company_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vendor_invoices vendor_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_invoices
    ADD CONSTRAINT vendor_invoices_pkey PRIMARY KEY (id);


--
-- Name: vendor_opening_balances vendor_opening_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_opening_balances
    ADD CONSTRAINT vendor_opening_balances_pkey PRIMARY KEY (id);


--
-- Name: vendor_payments vendor_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_payments
    ADD CONSTRAINT vendor_payments_pkey PRIMARY KEY (id);


--
-- Name: vendor_proforma_invoices vendor_proforma_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_proforma_invoices
    ADD CONSTRAINT vendor_proforma_invoices_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: voucher_attachments voucher_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voucher_attachments
    ADD CONSTRAINT voucher_attachments_pkey PRIMARY KEY (id);


--
-- Name: vouchers vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_pkey PRIMARY KEY (id);


--
-- Name: warehouse_stock warehouse_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_stock
    ADD CONSTRAINT warehouse_stock_pkey PRIMARY KEY (id);


--
-- Name: warehouse_stock warehouse_stock_warehouse_id_stock_item_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_stock
    ADD CONSTRAINT warehouse_stock_warehouse_id_stock_item_id_key UNIQUE (warehouse_id, stock_item_id);


--
-- Name: warehouses warehouses_company_id_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_company_id_code_key UNIQUE (company_id, code);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: wht_records wht_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wht_records
    ADD CONSTRAINT wht_records_pkey PRIMARY KEY (id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: accounting_backups_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounting_backups_company_idx ON public.accounting_backups USING btree (company_id);


--
-- Name: accounting_backups_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounting_backups_status_idx ON public.accounting_backups USING btree (company_id, status);


--
-- Name: accounting_restore_ops_backup_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounting_restore_ops_backup_idx ON public.accounting_restore_operations USING btree (backup_id);


--
-- Name: accounting_restore_ops_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounting_restore_ops_company_idx ON public.accounting_restore_operations USING btree (company_id);


--
-- Name: assets_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assets_company_id_idx ON public.assets USING btree (company_id);


--
-- Name: companies_slug_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX companies_slug_unique ON public.companies USING btree (slug) WHERE (slug IS NOT NULL);


--
-- Name: employee_documents_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employee_documents_company_id_idx ON public.employee_documents USING btree (company_id);


--
-- Name: employee_payroll_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employee_payroll_company_id_idx ON public.employee_payroll USING btree (company_id);


--
-- Name: employee_payroll_employee_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employee_payroll_employee_id_idx ON public.employee_payroll USING btree (employee_id);


--
-- Name: employees_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employees_company_id_idx ON public.employees USING btree (company_id);


--
-- Name: financial_years_company_dates_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX financial_years_company_dates_uidx ON public.financial_years USING btree (company_id, start_date, end_date);


--
-- Name: idx_audit_logs_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_company ON public.audit_logs USING btree (company_id, created_at DESC);


--
-- Name: idx_audit_logs_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_entity ON public.audit_logs USING btree (entity_type, entity_id);


--
-- Name: idx_credit_notes_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credit_notes_company ON public.credit_notes USING btree (company_id, created_at DESC);


--
-- Name: idx_customers_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_company ON public.customers USING btree (company_id);


--
-- Name: idx_delivery_orders_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_delivery_orders_company ON public.delivery_orders USING btree (company_id, created_at DESC);


--
-- Name: idx_grn_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_grn_company ON public.grn USING btree (company_id, created_at DESC);


--
-- Name: idx_invoice_payments_inv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_payments_inv ON public.invoice_payments USING btree (invoice_id);


--
-- Name: idx_invoices_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_company ON public.invoices USING btree (company_id, created_at DESC);


--
-- Name: idx_journal_entries_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_entries_company ON public.journal_entries USING btree (company_id, entry_date DESC);


--
-- Name: idx_journal_lines_account; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_lines_account ON public.journal_lines USING btree (account_id);


--
-- Name: idx_journal_lines_entry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_lines_entry ON public.journal_lines USING btree (journal_entry_id);


--
-- Name: idx_proforma_invoices_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proforma_invoices_company ON public.proforma_invoices USING btree (company_id, created_at DESC);


--
-- Name: idx_purchase_orders_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_purchase_orders_company ON public.purchase_orders USING btree (company_id, created_at DESC);


--
-- Name: idx_quotations_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quotations_company ON public.quotations USING btree (company_id, created_at DESC);


--
-- Name: idx_stock_items_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_items_company ON public.stock_items USING btree (company_id);


--
-- Name: idx_vendor_payments_vi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vendor_payments_vi ON public.vendor_payments USING btree (vendor_invoice_id);


--
-- Name: idx_vendors_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vendors_company ON public.vendors USING btree (company_id);


--
-- Name: ir8a_employers_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ir8a_employers_company_id_idx ON public.ir8a_employers USING btree (company_id);


--
-- Name: licenses_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX licenses_company_id_idx ON public.licenses USING btree (company_id);


--
-- Name: payroll_records_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_records_company_id_idx ON public.payroll_records USING btree (company_id);


--
-- Name: payroll_records_employee_period_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_records_employee_period_idx ON public.payroll_records USING btree (company_id, employee_id, pay_period_start, pay_period_end);


--
-- Name: pos_sales_company_channel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_sales_company_channel_idx ON public.pos_sales USING btree (company_id, channel);


--
-- Name: pos_sales_company_number_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_sales_company_number_idx ON public.pos_sales USING btree (company_id, pos_number);


--
-- Name: report_definitions_report_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX report_definitions_report_type_idx ON public.report_definitions USING btree (report_type);


--
-- Name: report_fields_definition_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX report_fields_definition_key_idx ON public.report_fields USING btree (report_definition_id, field_key);


--
-- Name: report_templates_company_def_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX report_templates_company_def_name_idx ON public.report_templates USING btree (company_id, report_definition_id, lower(name)) WHERE (company_id IS NOT NULL);


--
-- Name: report_templates_one_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX report_templates_one_active_idx ON public.report_templates USING btree (company_id, report_definition_id) WHERE ((is_active = true) AND (company_id IS NOT NULL) AND (is_system_template = false));


--
-- Name: report_templates_one_system_default_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX report_templates_one_system_default_idx ON public.report_templates USING btree (report_definition_id) WHERE ((is_system_template = true) AND (company_id IS NULL));


--
-- Name: sales_persons_company_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sales_persons_company_code_idx ON public.sales_persons USING btree (company_id, employment_code);


--
-- Name: service_reports_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_reports_company_id_idx ON public.service_reports USING btree (company_id);


--
-- Name: stock_item_purchase_prices_item_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_item_purchase_prices_item_idx ON public.stock_item_purchase_prices USING btree (stock_item_id, effective_date DESC, id DESC);


--
-- Name: stock_movements_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_company_idx ON public.stock_movements USING btree (company_id);


--
-- Name: stock_movements_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_date_idx ON public.stock_movements USING btree (movement_date);


--
-- Name: stock_movements_item_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_item_idx ON public.stock_movements USING btree (stock_item_id);


--
-- Name: stock_movements_wh_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_wh_idx ON public.stock_movements USING btree (warehouse_id);


--
-- Name: vendor_proforma_invoices_company_vpi_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX vendor_proforma_invoices_company_vpi_number_unique ON public.vendor_proforma_invoices USING btree (company_id, vpi_number);


--
-- Name: customer_deposits customer_deposits_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_deposits
    ADD CONSTRAINT customer_deposits_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id);


--
-- Name: goods_issue_items goods_issue_items_goods_issue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_issue_items
    ADD CONSTRAINT goods_issue_items_goods_issue_id_fkey FOREIGN KEY (goods_issue_id) REFERENCES public.goods_issues(id) ON DELETE CASCADE;


--
-- Name: goods_issue_items goods_issue_items_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_issue_items
    ADD CONSTRAINT goods_issue_items_stock_item_id_fkey FOREIGN KEY (stock_item_id) REFERENCES public.stock_items(id);


--
-- Name: goods_issues goods_issues_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_issues
    ADD CONSTRAINT goods_issues_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: goods_receipt_items goods_receipt_items_goods_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_goods_receipt_id_fkey FOREIGN KEY (goods_receipt_id) REFERENCES public.goods_receipts(id) ON DELETE CASCADE;


--
-- Name: goods_receipt_items goods_receipt_items_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_stock_item_id_fkey FOREIGN KEY (stock_item_id) REFERENCES public.stock_items(id);


--
-- Name: goods_receipts goods_receipts_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT goods_receipts_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: income_attachments income_attachments_income_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.income_attachments
    ADD CONSTRAINT income_attachments_income_id_fkey FOREIGN KEY (income_id) REFERENCES public.income_records(id) ON DELETE CASCADE;


--
-- Name: invoice_payments invoice_payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: journal_lines journal_lines_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: journal_lines journal_lines_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id) ON DELETE CASCADE;


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: opening_stock opening_stock_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opening_stock
    ADD CONSTRAINT opening_stock_stock_item_id_fkey FOREIGN KEY (stock_item_id) REFERENCES public.stock_items(id);


--
-- Name: opening_stock opening_stock_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opening_stock
    ADD CONSTRAINT opening_stock_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: pos_sales pos_sales_sales_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_sales
    ADD CONSTRAINT pos_sales_sales_person_id_fkey FOREIGN KEY (sales_person_id) REFERENCES public.sales_persons(id) ON DELETE SET NULL;


--
-- Name: report_fields report_fields_report_definition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_fields
    ADD CONSTRAINT report_fields_report_definition_id_fkey FOREIGN KEY (report_definition_id) REFERENCES public.report_definitions(id) ON DELETE CASCADE;


--
-- Name: report_templates report_templates_report_definition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_templates
    ADD CONSTRAINT report_templates_report_definition_id_fkey FOREIGN KEY (report_definition_id) REFERENCES public.report_definitions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: stock_adjustments stock_adjustments_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_stock_item_id_fkey FOREIGN KEY (stock_item_id) REFERENCES public.stock_items(id);


--
-- Name: stock_adjustments stock_adjustments_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: stock_item_purchase_prices stock_item_purchase_prices_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_purchase_prices
    ADD CONSTRAINT stock_item_purchase_prices_stock_item_id_fkey FOREIGN KEY (stock_item_id) REFERENCES public.stock_items(id) ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_stock_item_id_fkey FOREIGN KEY (stock_item_id) REFERENCES public.stock_items(id);


--
-- Name: stock_movements stock_movements_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: stock_serials stock_serials_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_serials
    ADD CONSTRAINT stock_serials_stock_item_id_fkey FOREIGN KEY (stock_item_id) REFERENCES public.stock_items(id) ON DELETE CASCADE;


--
-- Name: stock_transfer_items stock_transfer_items_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_stock_item_id_fkey FOREIGN KEY (stock_item_id) REFERENCES public.stock_items(id);


--
-- Name: stock_transfer_items stock_transfer_items_stock_transfer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_stock_transfer_id_fkey FOREIGN KEY (stock_transfer_id) REFERENCES public.stock_transfers(id) ON DELETE CASCADE;


--
-- Name: stock_transfers stock_transfers_from_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_from_warehouse_id_fkey FOREIGN KEY (from_warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: stock_transfers stock_transfers_to_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_to_warehouse_id_fkey FOREIGN KEY (to_warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: users users_sales_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_sales_person_id_fkey FOREIGN KEY (sales_person_id) REFERENCES public.sales_persons(id) ON DELETE SET NULL;


--
-- Name: vendor_payments vendor_payments_vendor_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_payments
    ADD CONSTRAINT vendor_payments_vendor_invoice_id_fkey FOREIGN KEY (vendor_invoice_id) REFERENCES public.vendor_invoices(id) ON DELETE CASCADE;


--
-- Name: voucher_attachments voucher_attachments_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voucher_attachments
    ADD CONSTRAINT voucher_attachments_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE CASCADE;


--
-- Name: warehouse_stock warehouse_stock_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_stock
    ADD CONSTRAINT warehouse_stock_stock_item_id_fkey FOREIGN KEY (stock_item_id) REFERENCES public.stock_items(id) ON DELETE CASCADE;


--
-- Name: warehouse_stock warehouse_stock_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_stock
    ADD CONSTRAINT warehouse_stock_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict ANIYBWw2gwLiQ5lecv5eybL9agm95V8wtEazjkLTnd1aiNHE0OYBYFVmTZtnsXY

