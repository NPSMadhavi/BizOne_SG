--
-- PostgreSQL database dump
--

\restrict 1vaDc1hkBfqEucHo0aB1oyB6LL5Ofa5jBUSe8c6GvjQYz6fprv603z7I0L2MsDX

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_company_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_companies DROP CONSTRAINT IF EXISTS user_companies_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_companies DROP CONSTRAINT IF EXISTS user_companies_company_id_fkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_company_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_permission_id_fkey;
ALTER TABLE IF EXISTS ONLY public.login_credentials DROP CONSTRAINT IF EXISTS login_credentials_user_id_fkey;
DROP INDEX IF EXISTS public.companies_slug_unique;
DROP INDEX IF EXISTS public."IDX_session_expire";
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_companies DROP CONSTRAINT IF EXISTS user_companies_user_id_company_id_key;
ALTER TABLE IF EXISTS ONLY public.user_companies DROP CONSTRAINT IF EXISTS user_companies_pkey;
ALTER TABLE IF EXISTS ONLY public.session DROP CONSTRAINT IF EXISTS session_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_role_id_permission_id_unique;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_module_action_unique;
ALTER TABLE IF EXISTS ONLY public.maintenance DROP CONSTRAINT IF EXISTS maintenance_pkey;
ALTER TABLE IF EXISTS ONLY public.login_credentials DROP CONSTRAINT IF EXISTS login_credentials_pkey;
ALTER TABLE IF EXISTS ONLY public.companies DROP CONSTRAINT IF EXISTS companies_pkey;
ALTER TABLE IF EXISTS ONLY public.backup_schedules DROP CONSTRAINT IF EXISTS backup_schedules_pkey;
ALTER TABLE IF EXISTS ONLY public.backup_retention_settings DROP CONSTRAINT IF EXISTS backup_retention_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.backup_retention_settings DROP CONSTRAINT IF EXISTS backup_retention_settings_company_id_key;
ALTER TABLE IF EXISTS ONLY public.accounting_restore_operations DROP CONSTRAINT IF EXISTS accounting_restore_operations_pkey;
ALTER TABLE IF EXISTS ONLY public.accounting_backups DROP CONSTRAINT IF EXISTS accounting_backups_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_companies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.maintenance ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.companies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.backup_schedules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.backup_retention_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.accounting_restore_operations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.accounting_backups ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_companies_id_seq;
DROP TABLE IF EXISTS public.user_companies;
DROP TABLE IF EXISTS public.session;
DROP SEQUENCE IF EXISTS public.roles_id_seq;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.role_permissions;
DROP SEQUENCE IF EXISTS public.permissions_id_seq;
DROP TABLE IF EXISTS public.permissions;
DROP SEQUENCE IF EXISTS public.maintenance_id_seq;
DROP TABLE IF EXISTS public.maintenance;
DROP TABLE IF EXISTS public.login_credentials;
DROP SEQUENCE IF EXISTS public.companies_id_seq;
DROP TABLE IF EXISTS public.companies;
DROP SEQUENCE IF EXISTS public.backup_schedules_id_seq;
DROP TABLE IF EXISTS public.backup_schedules;
DROP SEQUENCE IF EXISTS public.backup_retention_settings_id_seq;
DROP TABLE IF EXISTS public.backup_retention_settings;
DROP SEQUENCE IF EXISTS public.accounting_restore_operations_id_seq;
DROP TABLE IF EXISTS public.accounting_restore_operations;
DROP SEQUENCE IF EXISTS public.accounting_backups_id_seq;
DROP TABLE IF EXISTS public.accounting_backups;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounting_backups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounting_backups (
    id integer NOT NULL,
    company_id integer NOT NULL,
    backup_code text NOT NULL,
    backup_type text NOT NULL,
    from_date text,
    to_date text,
    financial_year_id integer,
    financial_year_label text,
    status text DEFAULT 'pending'::text NOT NULL,
    storage_path text,
    storage_ref text,
    file_size_bytes bigint,
    checksum_sha256 text,
    backup_source text DEFAULT 'manual'::text NOT NULL,
    schedule_id integer,
    error_message text,
    created_by integer,
    created_by_username text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    restored_at timestamp with time zone,
    restored_by integer
);


--
-- Name: accounting_backups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounting_backups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounting_backups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounting_backups_id_seq OWNED BY public.accounting_backups.id;


--
-- Name: accounting_restore_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounting_restore_operations (
    id integer NOT NULL,
    company_id integer NOT NULL,
    restore_code text NOT NULL,
    backup_id integer NOT NULL,
    backup_code text NOT NULL,
    restore_type text DEFAULT 'full_system'::text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    safety_backup_id integer,
    safety_backup_code text,
    steps_json text,
    result_message text,
    error_details text,
    started_by integer,
    started_by_username text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: accounting_restore_operations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounting_restore_operations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounting_restore_operations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounting_restore_operations_id_seq OWNED BY public.accounting_restore_operations.id;


--
-- Name: backup_retention_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_retention_settings (
    id integer NOT NULL,
    company_id integer NOT NULL,
    daily_keep_days integer DEFAULT 30 NOT NULL,
    weekly_keep_weeks integer DEFAULT 12 NOT NULL,
    monthly_keep_months integer DEFAULT 12 NOT NULL,
    financial_year_keep_forever boolean DEFAULT true NOT NULL,
    updated_by integer,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: backup_retention_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.backup_retention_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backup_retention_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.backup_retention_settings_id_seq OWNED BY public.backup_retention_settings.id;


--
-- Name: backup_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_schedules (
    id integer NOT NULL,
    company_id integer NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    frequency text DEFAULT 'daily'::text NOT NULL,
    time_of_day text DEFAULT '02:00'::text NOT NULL,
    day_of_week integer,
    backup_type text DEFAULT 'full_system'::text NOT NULL,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: backup_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.backup_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backup_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.backup_schedules_id_seq OWNED BY public.backup_schedules.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name text NOT NULL,
    country text NOT NULL,
    address text,
    registration_no text,
    email text,
    phone text,
    logo_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    domain text,
    gst_reg_no text,
    slug text,
    database_name text,
    business_type text
);


--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: login_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_credentials (
    user_id integer NOT NULL,
    password_hash text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: maintenance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance (
    id integer NOT NULL,
    is_enabled boolean DEFAULT false NOT NULL,
    scheduled_start timestamp with time zone,
    scheduled_end timestamp with time zone,
    message text,
    contact_email text,
    updated_at timestamp with time zone DEFAULT now(),
    updated_by_user integer
);


--
-- Name: maintenance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.maintenance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: maintenance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.maintenance_id_seq OWNED BY public.maintenance.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    module text NOT NULL,
    action text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    role_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name text NOT NULL,
    company_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


--
-- Name: user_companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_companies (
    id integer NOT NULL,
    user_id integer NOT NULL,
    company_id integer NOT NULL,
    modules jsonb DEFAULT '["purchase_orders", "quotations", "invoices", "delivery_orders"]'::jsonb NOT NULL
);


--
-- Name: user_companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_companies_id_seq OWNED BY public.user_companies.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    email text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    full_name text,
    phone_number text,
    is_active boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer,
    role_id integer,
    sales_person_id integer,
    database_name text
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: accounting_backups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_backups ALTER COLUMN id SET DEFAULT nextval('public.accounting_backups_id_seq'::regclass);


--
-- Name: accounting_restore_operations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_restore_operations ALTER COLUMN id SET DEFAULT nextval('public.accounting_restore_operations_id_seq'::regclass);


--
-- Name: backup_retention_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_retention_settings ALTER COLUMN id SET DEFAULT nextval('public.backup_retention_settings_id_seq'::regclass);


--
-- Name: backup_schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_schedules ALTER COLUMN id SET DEFAULT nextval('public.backup_schedules_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: maintenance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance ALTER COLUMN id SET DEFAULT nextval('public.maintenance_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: user_companies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_companies ALTER COLUMN id SET DEFAULT nextval('public.user_companies_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: accounting_backups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounting_backups (id, company_id, backup_code, backup_type, from_date, to_date, financial_year_id, financial_year_label, status, storage_path, storage_ref, file_size_bytes, checksum_sha256, backup_source, schedule_id, error_message, created_by, created_by_username, created_at, completed_at, restored_at, restored_by) FROM stdin;
1	23	SYS-2026-03E15F	full_system	\N	\N	\N	\N	in_progress	C:\\Users\\USER\\OneDrive\\Netopsys Projects\\Biz1_sg_29Sep\\BizOne_SG\\artifacts\\api-server\\uploads\\system-backups\\bizone_backup_SYS-2026-03E15F_2026-10-30T05-42-32-966Z.zip	bizone_backup_SYS-2026-03E15F_2026-10-30T05-42-32-966Z.zip	\N	\N	scheduled	\N	\N	\N	Plesk Cron Task	2026-10-29 22:42:32.973721-07	\N	\N	\N
\.


--
-- Data for Name: accounting_restore_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounting_restore_operations (id, company_id, restore_code, backup_id, backup_code, restore_type, status, safety_backup_id, safety_backup_code, steps_json, result_message, error_details, started_by, started_by_username, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: backup_retention_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_retention_settings (id, company_id, daily_keep_days, weekly_keep_weeks, monthly_keep_months, financial_year_keep_forever, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: backup_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_schedules (id, company_id, enabled, frequency, time_of_day, day_of_week, backup_type, last_run_at, next_run_at, created_by, created_at, updated_at) FROM stdin;
1	23	t	daily	02:00	\N	full_system	\N	2026-10-30 13:30:00-07	\N	2026-10-29 22:39:11.499626-07	2026-10-29 22:39:11.499626-07
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies (id, name, country, address, registration_no, email, phone, logo_url, created_at, domain, gst_reg_no, slug, database_name, business_type) FROM stdin;
23	Spsynet	SG	Singapore	\N	spsynet@gmail.com	+65 6568 1438	\N	2026-10-21 22:49:27.958906-07	\N	\N	spsynet	bizone_spsynet	trading_services
24	MSM Solutions	SG	House Number:36-99-184 RamjeeEstate Kancharapalam visakhapatnam 530008\nHouse Number:36-99-184 RamjeeEstate Kancharapalam visakhapatnam 530008	\N	msmsolutions@gmail.com	+65 2156 2750	\N	2026-10-26 21:08:54.111664-07	\N	\N	msmsolutions	bizone_msmsolutions	trading_services
\.


--
-- Data for Name: login_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_credentials (user_id, password_hash, updated_at) FROM stdin;
33	$2b$10$qDD/s18HatqKMfIdvXlNPOXccn37Qr/lFj1tLmbMMxyry8Q4ED6WC	2026-10-21 23:03:55.039094-07
34	$2b$10$BgzGxNUdhwu2g7qJiv139uI.1AddBNasBdJskaqNlBMwnInvvgrwy	2026-10-26 21:08:54.264317-07
\.


--
-- Data for Name: maintenance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance (id, is_enabled, scheduled_start, scheduled_end, message, contact_email, updated_at, updated_by_user) FROM stdin;
1	f	\N	\N	\N	\N	2026-10-22 22:35:40.734014-07	\N
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, module, action, created_at, updated_at) FROM stdin;
1	dashboard	view	2026-08-12 05:12:08.311944-07	2026-08-12 05:12:08.311944-07
2	dashboard	create	2026-08-12 05:12:08.314498-07	2026-08-12 05:12:08.314498-07
3	dashboard	edit	2026-08-12 05:12:08.315813-07	2026-08-12 05:12:08.315813-07
4	dashboard	delete	2026-08-12 05:12:08.317024-07	2026-08-12 05:12:08.317024-07
5	assets	view	2026-08-12 05:12:08.318071-07	2026-08-12 05:12:08.318071-07
6	assets	create	2026-08-12 05:12:08.31907-07	2026-08-12 05:12:08.31907-07
7	assets	edit	2026-08-12 05:12:08.320058-07	2026-08-12 05:12:08.320058-07
8	assets	delete	2026-08-12 05:12:08.320963-07	2026-08-12 05:12:08.320963-07
9	licenses	view	2026-08-12 05:12:08.321882-07	2026-08-12 05:12:08.321882-07
10	licenses	create	2026-08-12 05:12:08.322823-07	2026-08-12 05:12:08.322823-07
11	licenses	edit	2026-08-12 05:12:08.324088-07	2026-08-12 05:12:08.324088-07
12	licenses	delete	2026-08-12 05:12:08.325419-07	2026-08-12 05:12:08.325419-07
13	employees	view	2026-08-12 05:12:08.326561-07	2026-08-12 05:12:08.326561-07
14	employees	create	2026-08-12 05:12:08.327725-07	2026-08-12 05:12:08.327725-07
15	employees	edit	2026-08-12 05:12:08.328849-07	2026-08-12 05:12:08.328849-07
16	employees	delete	2026-08-12 05:12:08.329856-07	2026-08-12 05:12:08.329856-07
17	payroll	view	2026-08-12 05:12:08.330832-07	2026-08-12 05:12:08.330832-07
18	payroll	create	2026-08-12 05:12:08.331888-07	2026-08-12 05:12:08.331888-07
19	payroll	edit	2026-08-12 05:12:08.332826-07	2026-08-12 05:12:08.332826-07
20	payroll	delete	2026-08-12 05:12:08.333705-07	2026-08-12 05:12:08.333705-07
21	service_reports	view	2026-08-12 05:12:08.334661-07	2026-08-12 05:12:08.334661-07
22	service_reports	create	2026-08-12 05:12:08.335566-07	2026-08-12 05:12:08.335566-07
23	service_reports	edit	2026-08-12 05:12:08.336563-07	2026-08-12 05:12:08.336563-07
24	service_reports	delete	2026-08-12 05:12:08.337542-07	2026-08-12 05:12:08.337542-07
25	purchase_orders	view	2026-08-12 05:12:08.338502-07	2026-08-12 05:12:08.338502-07
26	purchase_orders	create	2026-08-12 05:12:08.339454-07	2026-08-12 05:12:08.339454-07
27	purchase_orders	edit	2026-08-12 05:12:08.340607-07	2026-08-12 05:12:08.340607-07
28	purchase_orders	delete	2026-08-12 05:12:08.341637-07	2026-08-12 05:12:08.341637-07
29	quotations	view	2026-08-12 05:12:08.342598-07	2026-08-12 05:12:08.342598-07
30	quotations	create	2026-08-12 05:12:08.343752-07	2026-08-12 05:12:08.343752-07
31	quotations	edit	2026-08-12 05:12:08.344991-07	2026-08-12 05:12:08.344991-07
32	quotations	delete	2026-08-12 05:12:08.345981-07	2026-08-12 05:12:08.345981-07
33	sales_orders	view	2026-08-12 05:12:08.346935-07	2026-08-12 05:12:08.346935-07
34	sales_orders	create	2026-08-12 05:12:08.347921-07	2026-08-12 05:12:08.347921-07
35	sales_orders	edit	2026-08-12 05:12:08.348845-07	2026-08-12 05:12:08.348845-07
36	sales_orders	delete	2026-08-12 05:12:08.349538-07	2026-08-12 05:12:08.349538-07
37	invoices	view	2026-08-12 05:12:08.350213-07	2026-08-12 05:12:08.350213-07
38	invoices	create	2026-08-12 05:12:08.351119-07	2026-08-12 05:12:08.351119-07
39	invoices	edit	2026-08-12 05:12:08.352133-07	2026-08-12 05:12:08.352133-07
40	invoices	delete	2026-08-12 05:12:08.353403-07	2026-08-12 05:12:08.353403-07
41	proforma_invoices	view	2026-08-12 05:12:08.354408-07	2026-08-12 05:12:08.354408-07
42	proforma_invoices	create	2026-08-12 05:12:08.355549-07	2026-08-12 05:12:08.355549-07
43	proforma_invoices	edit	2026-08-12 05:12:08.356338-07	2026-08-12 05:12:08.356338-07
44	proforma_invoices	delete	2026-08-12 05:12:08.357271-07	2026-08-12 05:12:08.357271-07
45	credit_notes	view	2026-08-12 05:12:08.358181-07	2026-08-12 05:12:08.358181-07
46	credit_notes	create	2026-08-12 05:12:08.359169-07	2026-08-12 05:12:08.359169-07
47	credit_notes	edit	2026-08-12 05:12:08.359908-07	2026-08-12 05:12:08.359908-07
48	credit_notes	delete	2026-08-12 05:12:08.360735-07	2026-08-12 05:12:08.360735-07
49	delivery_orders	view	2026-08-12 05:12:08.361749-07	2026-08-12 05:12:08.361749-07
50	delivery_orders	create	2026-08-12 05:12:08.36285-07	2026-08-12 05:12:08.36285-07
51	delivery_orders	edit	2026-08-12 05:12:08.363566-07	2026-08-12 05:12:08.363566-07
52	delivery_orders	delete	2026-08-12 05:12:08.364385-07	2026-08-12 05:12:08.364385-07
53	point_of_sale	view	2026-08-12 05:12:08.365127-07	2026-08-12 05:12:08.365127-07
54	point_of_sale	create	2026-08-12 05:12:08.365894-07	2026-08-12 05:12:08.365894-07
55	point_of_sale	edit	2026-08-12 05:12:08.366637-07	2026-08-12 05:12:08.366637-07
56	point_of_sale	delete	2026-08-12 05:12:08.367426-07	2026-08-12 05:12:08.367426-07
57	bill_of_materials	view	2026-08-12 05:12:08.368155-07	2026-08-12 05:12:08.368155-07
58	bill_of_materials	create	2026-08-12 05:12:08.368854-07	2026-08-12 05:12:08.368854-07
59	bill_of_materials	edit	2026-08-12 05:12:08.369499-07	2026-08-12 05:12:08.369499-07
60	bill_of_materials	delete	2026-08-12 05:12:08.370118-07	2026-08-12 05:12:08.370118-07
61	grn	view	2026-08-12 05:12:08.370837-07	2026-08-12 05:12:08.370837-07
62	grn	create	2026-08-12 05:12:08.371843-07	2026-08-12 05:12:08.371843-07
63	grn	edit	2026-08-12 05:12:08.37295-07	2026-08-12 05:12:08.37295-07
64	grn	delete	2026-08-12 05:12:08.373973-07	2026-08-12 05:12:08.373973-07
65	stock_items	view	2026-08-12 05:12:08.375065-07	2026-08-12 05:12:08.375065-07
66	stock_items	create	2026-08-12 05:12:08.37624-07	2026-08-12 05:12:08.37624-07
67	stock_items	edit	2026-08-12 05:12:08.377304-07	2026-08-12 05:12:08.377304-07
68	stock_items	delete	2026-08-12 05:12:08.37787-07	2026-08-12 05:12:08.37787-07
69	warehouses	view	2026-08-12 05:12:08.378291-07	2026-08-12 05:12:08.378291-07
70	warehouses	create	2026-08-12 05:12:08.378738-07	2026-08-12 05:12:08.378738-07
71	warehouses	edit	2026-08-12 05:12:08.379397-07	2026-08-12 05:12:08.379397-07
72	warehouses	delete	2026-08-12 05:12:08.380061-07	2026-08-12 05:12:08.380061-07
73	stock_transfer	view	2026-08-12 05:12:08.380662-07	2026-08-12 05:12:08.380662-07
74	stock_transfer	create	2026-08-12 05:12:08.381235-07	2026-08-12 05:12:08.381235-07
75	stock_transfer	edit	2026-08-12 05:12:08.381647-07	2026-08-12 05:12:08.381647-07
76	stock_transfer	delete	2026-08-12 05:12:08.38228-07	2026-08-12 05:12:08.38228-07
77	inventory_reports	view	2026-08-12 05:12:08.38301-07	2026-08-12 05:12:08.38301-07
78	inventory_reports	create	2026-08-12 05:12:08.3838-07	2026-08-12 05:12:08.3838-07
79	inventory_reports	edit	2026-08-12 05:12:08.38448-07	2026-08-12 05:12:08.38448-07
80	inventory_reports	delete	2026-08-12 05:12:08.385006-07	2026-08-12 05:12:08.385006-07
81	batch_expiry	view	2026-08-12 05:12:08.385622-07	2026-08-12 05:12:08.385622-07
82	batch_expiry	create	2026-08-12 05:12:08.386411-07	2026-08-12 05:12:08.386411-07
83	batch_expiry	edit	2026-08-12 05:12:08.387012-07	2026-08-12 05:12:08.387012-07
84	batch_expiry	delete	2026-08-12 05:12:08.387689-07	2026-08-12 05:12:08.387689-07
85	vendors	view	2026-08-12 05:12:08.388499-07	2026-08-12 05:12:08.388499-07
86	vendors	create	2026-08-12 05:12:08.389051-07	2026-08-12 05:12:08.389051-07
87	vendors	edit	2026-08-12 05:12:08.389508-07	2026-08-12 05:12:08.389508-07
88	vendors	delete	2026-08-12 05:12:08.390206-07	2026-08-12 05:12:08.390206-07
89	customers	view	2026-08-12 05:12:08.391018-07	2026-08-12 05:12:08.391018-07
90	customers	create	2026-08-12 05:12:08.391907-07	2026-08-12 05:12:08.391907-07
91	customers	edit	2026-08-12 05:12:08.392623-07	2026-08-12 05:12:08.392623-07
92	customers	delete	2026-08-12 05:12:08.3932-07	2026-08-12 05:12:08.3932-07
93	projects	view	2026-08-12 05:12:08.393792-07	2026-08-12 05:12:08.393792-07
94	projects	create	2026-08-12 05:12:08.394284-07	2026-08-12 05:12:08.394284-07
95	projects	edit	2026-08-12 05:12:08.394692-07	2026-08-12 05:12:08.394692-07
96	projects	delete	2026-08-12 05:12:08.395062-07	2026-08-12 05:12:08.395062-07
97	accounting_coa	view	2026-08-12 05:12:08.395445-07	2026-08-12 05:12:08.395445-07
98	accounting_coa	create	2026-08-12 05:12:08.3959-07	2026-08-12 05:12:08.3959-07
99	accounting_coa	edit	2026-08-12 05:12:08.39639-07	2026-08-12 05:12:08.39639-07
100	accounting_coa	delete	2026-08-12 05:12:08.397027-07	2026-08-12 05:12:08.397027-07
101	accounting_je	view	2026-08-12 05:12:08.398121-07	2026-08-12 05:12:08.398121-07
102	accounting_je	create	2026-08-12 05:12:08.399348-07	2026-08-12 05:12:08.399348-07
103	accounting_je	edit	2026-08-12 05:12:08.400445-07	2026-08-12 05:12:08.400445-07
104	accounting_je	delete	2026-08-12 05:12:08.401682-07	2026-08-12 05:12:08.401682-07
105	accounting_gl	view	2026-08-12 05:12:08.402336-07	2026-08-12 05:12:08.402336-07
106	accounting_gl	create	2026-08-12 05:12:08.402897-07	2026-08-12 05:12:08.402897-07
107	accounting_gl	edit	2026-08-12 05:12:08.403322-07	2026-08-12 05:12:08.403322-07
108	accounting_gl	delete	2026-08-12 05:12:08.404-07	2026-08-12 05:12:08.404-07
109	accounting_tb	view	2026-08-12 05:12:08.404582-07	2026-08-12 05:12:08.404582-07
110	accounting_tb	create	2026-08-12 05:12:08.405158-07	2026-08-12 05:12:08.405158-07
111	accounting_tb	edit	2026-08-12 05:12:08.405881-07	2026-08-12 05:12:08.405881-07
112	accounting_tb	delete	2026-08-12 05:12:08.406453-07	2026-08-12 05:12:08.406453-07
113	accounting_bs	view	2026-08-12 05:12:08.407161-07	2026-08-12 05:12:08.407161-07
114	accounting_bs	create	2026-08-12 05:12:08.407845-07	2026-08-12 05:12:08.407845-07
115	accounting_bs	edit	2026-08-12 05:12:08.40852-07	2026-08-12 05:12:08.40852-07
116	accounting_bs	delete	2026-08-12 05:12:08.409066-07	2026-08-12 05:12:08.409066-07
117	accounting_pl	view	2026-08-12 05:12:08.409553-07	2026-08-12 05:12:08.409553-07
118	accounting_pl	create	2026-08-12 05:12:08.411318-07	2026-08-12 05:12:08.411318-07
119	accounting_pl	edit	2026-08-12 05:12:08.411926-07	2026-08-12 05:12:08.411926-07
120	accounting_pl	delete	2026-08-12 05:12:08.412432-07	2026-08-12 05:12:08.412432-07
121	accounting_cf	view	2026-08-12 05:12:08.412914-07	2026-08-12 05:12:08.412914-07
122	accounting_cf	create	2026-08-12 05:12:08.413678-07	2026-08-12 05:12:08.413678-07
123	accounting_cf	edit	2026-08-12 05:12:08.414206-07	2026-08-12 05:12:08.414206-07
124	accounting_cf	delete	2026-08-12 05:12:08.414645-07	2026-08-12 05:12:08.414645-07
125	accounting_gst_f5	view	2026-08-12 05:12:08.415003-07	2026-08-12 05:12:08.415003-07
126	accounting_gst_f5	create	2026-08-12 05:12:08.415352-07	2026-08-12 05:12:08.415352-07
127	accounting_gst_f5	edit	2026-08-12 05:12:08.415737-07	2026-08-12 05:12:08.415737-07
128	accounting_gst_f5	delete	2026-08-12 05:12:08.416193-07	2026-08-12 05:12:08.416193-07
129	accounting_gst_f7	view	2026-08-12 05:12:08.416614-07	2026-08-12 05:12:08.416614-07
130	accounting_gst_f7	create	2026-08-12 05:12:08.417161-07	2026-08-12 05:12:08.417161-07
131	accounting_gst_f7	edit	2026-08-12 05:12:08.417662-07	2026-08-12 05:12:08.417662-07
132	accounting_gst_f7	delete	2026-08-12 05:12:08.418086-07	2026-08-12 05:12:08.418086-07
133	accounting_gst_io	view	2026-08-12 05:12:08.418632-07	2026-08-12 05:12:08.418632-07
134	accounting_gst_io	create	2026-08-12 05:12:08.419402-07	2026-08-12 05:12:08.419402-07
135	accounting_gst_io	edit	2026-08-12 05:12:08.420208-07	2026-08-12 05:12:08.420208-07
136	accounting_gst_io	delete	2026-08-12 05:12:08.420956-07	2026-08-12 05:12:08.420956-07
137	accounting_wht	view	2026-08-12 05:12:08.421713-07	2026-08-12 05:12:08.421713-07
138	accounting_wht	create	2026-08-12 05:12:08.422332-07	2026-08-12 05:12:08.422332-07
139	accounting_wht	edit	2026-08-12 05:12:08.423059-07	2026-08-12 05:12:08.423059-07
140	accounting_wht	delete	2026-08-12 05:12:08.423889-07	2026-08-12 05:12:08.423889-07
141	accounting_eci	view	2026-08-12 05:12:08.42495-07	2026-08-12 05:12:08.42495-07
142	accounting_eci	create	2026-08-12 05:12:08.425647-07	2026-08-12 05:12:08.425647-07
143	accounting_eci	edit	2026-08-12 05:12:08.426223-07	2026-08-12 05:12:08.426223-07
144	accounting_eci	delete	2026-08-12 05:12:08.42689-07	2026-08-12 05:12:08.42689-07
145	accounting_formcs	view	2026-08-12 05:12:08.427854-07	2026-08-12 05:12:08.427854-07
146	accounting_formcs	create	2026-08-12 05:12:08.428881-07	2026-08-12 05:12:08.428881-07
147	accounting_formcs	edit	2026-08-12 05:12:08.429584-07	2026-08-12 05:12:08.429584-07
148	accounting_formcs	delete	2026-08-12 05:12:08.430071-07	2026-08-12 05:12:08.430071-07
149	accounting_iaf	view	2026-08-12 05:12:08.430634-07	2026-08-12 05:12:08.430634-07
150	accounting_iaf	create	2026-08-12 05:12:08.431091-07	2026-08-12 05:12:08.431091-07
151	accounting_iaf	edit	2026-08-12 05:12:08.4315-07	2026-08-12 05:12:08.4315-07
152	accounting_iaf	delete	2026-08-12 05:12:08.432272-07	2026-08-12 05:12:08.432272-07
153	accounting_ar	view	2026-08-12 05:12:08.432866-07	2026-08-12 05:12:08.432866-07
154	accounting_ar	create	2026-08-12 05:12:08.43357-07	2026-08-12 05:12:08.43357-07
155	accounting_ar	edit	2026-08-12 05:12:08.434142-07	2026-08-12 05:12:08.434142-07
156	accounting_ar	delete	2026-08-12 05:12:08.434772-07	2026-08-12 05:12:08.434772-07
157	accounting_ar_aging	view	2026-08-12 05:12:08.435741-07	2026-08-12 05:12:08.435741-07
158	accounting_ar_aging	create	2026-08-12 05:12:08.436454-07	2026-08-12 05:12:08.436454-07
159	accounting_ar_aging	edit	2026-08-12 05:12:08.437163-07	2026-08-12 05:12:08.437163-07
160	accounting_ar_aging	delete	2026-08-12 05:12:08.437787-07	2026-08-12 05:12:08.437787-07
161	accounting_cust_stmt	view	2026-08-12 05:12:08.438318-07	2026-08-12 05:12:08.438318-07
162	accounting_cust_stmt	create	2026-08-12 05:12:08.438787-07	2026-08-12 05:12:08.438787-07
163	accounting_cust_stmt	edit	2026-08-12 05:12:08.43952-07	2026-08-12 05:12:08.43952-07
164	accounting_cust_stmt	delete	2026-08-12 05:12:08.440555-07	2026-08-12 05:12:08.440555-07
165	accounting_ap	view	2026-08-12 05:12:08.441461-07	2026-08-12 05:12:08.441461-07
166	accounting_ap	create	2026-08-12 05:12:08.442359-07	2026-08-12 05:12:08.442359-07
167	accounting_ap	edit	2026-08-12 05:12:08.443133-07	2026-08-12 05:12:08.443133-07
168	accounting_ap	delete	2026-08-12 05:12:08.444097-07	2026-08-12 05:12:08.444097-07
169	accounting_ap_aging	view	2026-08-12 05:12:08.444726-07	2026-08-12 05:12:08.444726-07
170	accounting_ap_aging	create	2026-08-12 05:12:08.445229-07	2026-08-12 05:12:08.445229-07
171	accounting_ap_aging	edit	2026-08-12 05:12:08.445629-07	2026-08-12 05:12:08.445629-07
172	accounting_ap_aging	delete	2026-08-12 05:12:08.446197-07	2026-08-12 05:12:08.446197-07
173	accounting_vendor_stmt	view	2026-08-12 05:12:08.446717-07	2026-08-12 05:12:08.446717-07
174	accounting_vendor_stmt	create	2026-08-12 05:12:08.447553-07	2026-08-12 05:12:08.447553-07
175	accounting_vendor_stmt	edit	2026-08-12 05:12:08.448-07	2026-08-12 05:12:08.448-07
176	accounting_vendor_stmt	delete	2026-08-12 05:12:08.448381-07	2026-08-12 05:12:08.448381-07
177	user_management	view	2026-08-12 05:12:08.448746-07	2026-08-12 05:12:08.448746-07
178	user_management	create	2026-08-12 05:12:08.44927-07	2026-08-12 05:12:08.44927-07
179	user_management	edit	2026-08-12 05:12:08.450034-07	2026-08-12 05:12:08.450034-07
180	user_management	delete	2026-08-12 05:12:08.450718-07	2026-08-12 05:12:08.450718-07
181	audit_log	view	2026-08-12 05:12:08.451328-07	2026-08-12 05:12:08.451328-07
182	audit_log	create	2026-08-12 05:12:08.451987-07	2026-08-12 05:12:08.451987-07
183	audit_log	edit	2026-08-12 05:12:08.452578-07	2026-08-12 05:12:08.452578-07
184	audit_log	delete	2026-08-12 05:12:08.453139-07	2026-08-12 05:12:08.453139-07
185	settings	view	2026-08-12 05:12:08.453575-07	2026-08-12 05:12:08.453575-07
186	settings	create	2026-08-12 05:12:08.454166-07	2026-08-12 05:12:08.454166-07
187	settings	edit	2026-08-12 05:12:08.454616-07	2026-08-12 05:12:08.454616-07
188	settings	delete	2026-08-12 05:12:08.455038-07	2026-08-12 05:12:08.455038-07
1153	vendor_invoices	view	2026-08-12 21:00:11.134895-07	2026-08-12 21:00:11.134895-07
1154	vendor_invoices	create	2026-08-12 21:00:11.136663-07	2026-08-12 21:00:11.136663-07
1155	vendor_invoices	edit	2026-08-12 21:00:11.137455-07	2026-08-12 21:00:11.137455-07
1156	vendor_invoices	delete	2026-08-12 21:00:11.138179-07	2026-08-12 21:00:11.138179-07
1177	debit_notes	view	2026-08-12 21:00:11.152238-07	2026-08-12 21:00:11.152238-07
1178	debit_notes	create	2026-08-12 21:00:11.153295-07	2026-08-12 21:00:11.153295-07
1179	debit_notes	edit	2026-08-12 21:00:11.154051-07	2026-08-12 21:00:11.154051-07
1180	debit_notes	delete	2026-08-12 21:00:11.154958-07	2026-08-12 21:00:11.154958-07
1225	address_book	view	2026-08-12 21:00:11.184144-07	2026-08-12 21:00:11.184144-07
1226	address_book	create	2026-08-12 21:00:11.184822-07	2026-08-12 21:00:11.184822-07
1227	address_book	edit	2026-08-12 21:00:11.185394-07	2026-08-12 21:00:11.185394-07
1228	address_book	delete	2026-08-12 21:00:11.186008-07	2026-08-12 21:00:11.186008-07
1261	accounting_bank_recon	view	2026-08-12 21:00:11.202827-07	2026-08-12 21:00:11.202827-07
1262	accounting_bank_recon	create	2026-08-12 21:00:11.203418-07	2026-08-12 21:00:11.203418-07
1263	accounting_bank_recon	edit	2026-08-12 21:00:11.203866-07	2026-08-12 21:00:11.203866-07
1264	accounting_bank_recon	delete	2026-08-12 21:00:11.204342-07	2026-08-12 21:00:11.204342-07
1317	accounting_expenses	view	2026-08-12 21:00:11.232774-07	2026-08-12 21:00:11.232774-07
1318	accounting_expenses	create	2026-08-12 21:00:11.233528-07	2026-08-12 21:00:11.233528-07
1319	accounting_expenses	edit	2026-08-12 21:00:11.234165-07	2026-08-12 21:00:11.234165-07
1320	accounting_expenses	delete	2026-08-12 21:00:11.23487-07	2026-08-12 21:00:11.23487-07
1321	accounting_income	view	2026-08-12 21:00:11.236587-07	2026-08-12 21:00:11.236587-07
1322	accounting_income	create	2026-08-12 21:00:11.237226-07	2026-08-12 21:00:11.237226-07
1323	accounting_income	edit	2026-08-12 21:00:11.237837-07	2026-08-12 21:00:11.237837-07
1324	accounting_income	delete	2026-08-12 21:00:11.238537-07	2026-08-12 21:00:11.238537-07
6765	purchase_quotations	view	2026-08-16 20:52:24.462938-07	2026-08-16 20:52:24.462938-07
6766	purchase_quotations	create	2026-08-16 20:52:24.465987-07	2026-08-16 20:52:24.465987-07
6767	purchase_quotations	edit	2026-08-16 20:52:24.46761-07	2026-08-16 20:52:24.46761-07
6768	purchase_quotations	delete	2026-08-16 20:52:24.468686-07	2026-08-16 20:52:24.468686-07
9501	report_templates	view	2026-08-17 22:44:54.474576-07	2026-08-17 22:44:54.474576-07
9502	report_templates	create	2026-08-17 22:44:54.476373-07	2026-08-17 22:44:54.476373-07
9503	report_templates	edit	2026-08-17 22:44:54.480008-07	2026-08-17 22:44:54.480008-07
9504	report_templates	delete	2026-08-17 22:44:54.481381-07	2026-08-17 22:44:54.481381-07
13461	multi_price_level	view	2026-08-25 03:43:31.652793-07	2026-08-25 03:43:31.652793-07
13462	multi_price_level	create	2026-08-25 03:43:31.659884-07	2026-08-25 03:43:31.659884-07
13463	multi_price_level	edit	2026-08-25 03:43:31.662393-07	2026-08-25 03:43:31.662393-07
13464	multi_price_level	delete	2026-08-25 03:43:31.664309-07	2026-08-25 03:43:31.664309-07
20428	accounting_backup	view	2026-09-07 03:02:23.342562-07	2026-09-07 03:02:23.342562-07
20429	accounting_backup	create	2026-09-07 03:02:23.344144-07	2026-09-07 03:02:23.344144-07
20430	accounting_backup	edit	2026-09-07 03:02:23.344877-07	2026-09-07 03:02:23.344877-07
20431	accounting_backup	delete	2026-09-07 03:02:23.34544-07	2026-09-07 03:02:23.34544-07
40560	sales_person_wise_report	view	2026-09-20 22:33:48.992532-07	2026-09-20 22:33:48.992532-07
40561	sales_person_wise_report	create	2026-09-20 22:33:48.995752-07	2026-09-20 22:33:48.995752-07
40562	sales_person_wise_report	edit	2026-09-20 22:33:48.997079-07	2026-09-20 22:33:48.997079-07
40563	sales_person_wise_report	delete	2026-09-20 22:33:48.998119-07	2026-09-20 22:33:48.998119-07
57556	pos_retail	view	2026-10-12 22:41:25.886138-07	2026-10-12 22:41:25.886138-07
57557	pos_retail	create	2026-10-12 22:41:25.888138-07	2026-10-12 22:41:25.888138-07
57558	pos_retail	edit	2026-10-12 22:41:25.888485-07	2026-10-12 22:41:25.888485-07
57559	pos_retail	delete	2026-10-12 22:41:25.888756-07	2026-10-12 22:41:25.888756-07
57560	pos_supermarket	view	2026-10-12 22:41:25.888996-07	2026-10-12 22:41:25.888996-07
57561	pos_supermarket	create	2026-10-12 22:41:25.889217-07	2026-10-12 22:41:25.889217-07
57562	pos_supermarket	edit	2026-10-12 22:41:25.889427-07	2026-10-12 22:41:25.889427-07
57563	pos_supermarket	delete	2026-10-12 22:41:25.889721-07	2026-10-12 22:41:25.889721-07
57564	pos_restaurants	view	2026-10-12 22:41:25.889997-07	2026-10-12 22:41:25.889997-07
57565	pos_restaurants	create	2026-10-12 22:41:25.890263-07	2026-10-12 22:41:25.890263-07
57566	pos_restaurants	edit	2026-10-12 22:41:25.890536-07	2026-10-12 22:41:25.890536-07
57567	pos_restaurants	delete	2026-10-12 22:41:25.890759-07	2026-10-12 22:41:25.890759-07
57568	pos_pharmacy	view	2026-10-12 22:41:25.890993-07	2026-10-12 22:41:25.890993-07
57569	pos_pharmacy	create	2026-10-12 22:41:25.891249-07	2026-10-12 22:41:25.891249-07
57570	pos_pharmacy	edit	2026-10-12 22:41:25.891487-07	2026-10-12 22:41:25.891487-07
57571	pos_pharmacy	delete	2026-10-12 22:41:25.891714-07	2026-10-12 22:41:25.891714-07
57572	pos_electronics	view	2026-10-12 22:41:25.891943-07	2026-10-12 22:41:25.891943-07
57573	pos_electronics	create	2026-10-12 22:41:25.89217-07	2026-10-12 22:41:25.89217-07
57574	pos_electronics	edit	2026-10-12 22:41:25.892396-07	2026-10-12 22:41:25.892396-07
57575	pos_electronics	delete	2026-10-12 22:41:25.89262-07	2026-10-12 22:41:25.89262-07
57820	pos_reports	view	2026-10-12 23:24:47.222518-07	2026-10-12 23:24:47.222518-07
57821	pos_reports	create	2026-10-12 23:24:47.223314-07	2026-10-12 23:24:47.223314-07
57822	pos_reports	edit	2026-10-12 23:24:47.223822-07	2026-10-12 23:24:47.223822-07
57823	pos_reports	delete	2026-10-12 23:24:47.224871-07	2026-10-12 23:24:47.224871-07
66696	vendor_proforma_invoices	view	2026-10-20 21:08:14.534027-07	2026-10-20 21:08:14.534027-07
66697	vendor_proforma_invoices	create	2026-10-20 21:08:14.536166-07	2026-10-20 21:08:14.536166-07
66698	vendor_proforma_invoices	edit	2026-10-20 21:08:14.536803-07	2026-10-20 21:08:14.536803-07
66699	vendor_proforma_invoices	delete	2026-10-20 21:08:14.537381-07	2026-10-20 21:08:14.537381-07
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
248	1
248	2
248	3
248	4
248	5
248	6
248	7
248	8
248	9
248	10
248	11
248	12
248	13
248	14
248	15
248	16
248	17
248	18
248	19
248	20
248	25
248	26
248	27
248	28
248	29
248	30
248	31
248	32
248	33
248	34
248	35
248	36
248	37
248	38
248	39
248	40
248	41
248	42
248	43
248	44
248	45
248	46
248	47
248	48
248	49
248	50
248	51
248	52
248	53
248	54
248	55
248	56
248	57
248	58
248	59
248	60
248	61
248	62
248	63
248	64
248	65
248	66
248	67
248	68
248	69
248	70
248	71
248	72
248	73
248	74
248	75
248	76
248	77
248	78
248	79
248	80
248	81
248	82
248	83
248	84
248	85
248	86
248	87
248	88
248	89
248	90
248	91
248	92
248	93
248	94
248	95
248	96
248	97
248	98
248	99
248	100
248	101
248	102
248	103
248	104
248	105
248	106
248	107
248	108
248	109
248	110
248	111
248	112
248	113
248	114
248	115
248	116
248	117
248	118
248	119
248	120
248	121
248	122
248	123
248	124
248	125
248	126
248	127
248	128
248	129
248	130
248	131
248	132
248	133
248	134
248	135
248	136
248	137
248	138
248	139
248	140
248	141
248	142
248	143
248	144
248	145
248	146
248	147
248	148
248	149
248	150
248	151
248	152
248	153
248	154
248	155
248	156
248	157
248	158
248	159
248	160
248	161
248	162
248	163
248	164
248	165
248	166
248	167
248	168
248	169
248	170
248	171
248	172
248	173
248	174
248	175
248	176
248	177
248	178
248	179
248	180
248	181
248	182
248	183
248	184
248	185
248	186
248	187
248	188
248	1153
248	1154
248	1155
248	1156
248	1177
248	1178
248	1179
248	1180
248	1225
248	1226
248	1227
248	1228
248	1261
248	1262
248	1263
248	1264
248	1317
248	1318
248	1319
248	1320
248	1321
248	1322
248	1323
248	1324
248	6765
248	6766
248	6767
248	6768
248	9501
248	9502
248	9503
248	9504
248	13461
248	13462
248	13463
248	13464
248	40560
248	40561
248	40562
248	40563
248	57556
248	57557
248	57558
248	57559
248	57560
248	57561
248	57562
248	57563
248	57564
248	57565
248	57566
248	57567
248	57568
248	57569
248	57570
248	57571
248	57572
248	57573
248	57574
248	57575
248	57820
248	57821
248	57822
248	57823
248	66696
248	66697
248	66698
248	66699
249	1
249	2
249	3
249	5
249	6
249	7
249	9
249	10
249	11
249	13
249	14
249	15
249	17
249	18
249	19
249	25
249	26
249	27
249	29
249	30
249	31
249	33
249	34
249	35
249	37
249	38
249	39
249	41
249	42
249	43
249	45
249	46
249	47
249	49
249	50
249	51
249	53
249	54
249	55
249	57
249	58
249	59
249	61
249	62
249	63
249	65
249	66
249	67
249	69
249	70
249	71
249	73
249	74
249	75
249	77
249	78
249	79
249	81
249	82
249	83
249	85
249	86
249	87
249	89
249	90
249	91
249	93
249	94
249	95
249	97
249	98
249	99
249	101
249	102
249	103
249	105
249	106
249	107
249	109
249	110
249	111
249	113
249	114
249	115
249	117
249	118
249	119
249	121
249	122
249	123
249	125
249	126
249	127
249	129
249	130
249	131
249	133
249	134
249	135
249	137
249	138
249	139
249	141
249	142
249	143
249	145
249	146
249	147
249	149
249	150
249	151
249	153
249	154
249	155
249	157
249	158
249	159
249	161
249	162
249	163
249	165
249	166
249	167
249	169
249	170
249	171
249	173
249	174
249	175
249	177
249	178
249	179
249	181
249	182
249	183
249	185
249	186
249	187
249	1153
249	1154
249	1155
249	1177
249	1178
249	1179
249	1225
249	1226
249	1227
249	1261
249	1262
249	1263
249	1317
249	1318
249	1319
249	1321
249	1322
249	1323
249	6765
249	6766
249	6767
249	9501
249	9502
249	9503
249	13461
249	13462
249	13463
249	40560
249	40561
249	40562
249	57556
249	57557
249	57558
249	57560
249	57561
249	57562
249	57564
249	57565
249	57566
249	57568
249	57569
249	57570
249	57572
249	57573
249	57574
249	57820
249	57821
249	57822
249	66696
249	66697
249	66698
250	1
250	5
250	9
250	13
251	1
251	2
251	3
251	4
251	17
251	18
251	19
251	20
251	37
251	38
251	39
251	40
251	41
251	42
251	43
251	44
251	45
251	46
251	47
251	48
251	97
251	98
251	99
251	100
251	101
251	102
251	103
251	104
251	105
251	106
251	107
251	108
251	109
251	110
251	111
251	112
251	113
251	114
251	115
251	116
251	117
251	118
251	119
251	120
251	121
251	122
251	123
251	124
251	125
251	126
251	127
251	128
251	129
251	130
251	131
251	132
251	133
251	134
251	135
251	136
251	137
251	138
251	139
251	140
251	141
251	142
251	143
251	144
251	145
251	146
251	147
251	148
251	149
251	150
251	151
251	152
251	153
251	154
251	155
251	156
251	157
251	158
251	159
251	160
251	161
251	162
251	163
251	164
251	165
251	166
251	167
251	168
251	169
251	170
251	171
251	172
251	173
251	174
251	175
251	176
251	1177
251	1178
251	1179
251	1180
251	9501
251	9502
251	9503
251	9504
252	1
252	2
252	3
252	29
252	30
252	31
252	33
252	34
252	35
252	37
252	38
252	39
252	89
252	90
252	91
252	9501
252	9502
252	9503
227	1
227	2
227	3
227	4
227	5
227	6
227	7
227	8
227	9
227	10
227	11
227	12
227	13
227	14
227	15
227	16
227	17
227	18
227	19
227	20
227	21
227	22
227	23
227	24
227	25
227	26
227	27
227	28
227	29
227	30
227	31
227	32
227	33
227	34
227	35
227	36
227	37
227	38
227	39
227	40
227	41
227	42
227	43
227	44
227	45
227	46
227	47
227	48
227	49
227	50
227	51
227	52
227	53
227	54
227	55
227	56
227	57
227	58
227	59
227	60
227	61
227	62
227	63
227	64
227	65
227	66
227	67
227	68
227	69
227	70
227	71
227	72
227	73
227	74
227	75
227	76
227	77
227	78
227	79
227	80
227	81
227	82
227	83
227	84
227	85
227	86
227	87
227	88
227	89
227	90
227	91
227	92
227	93
227	94
227	95
227	96
227	97
227	98
227	99
227	100
227	101
227	102
227	103
227	104
227	105
227	106
227	107
227	108
227	109
227	110
227	111
227	112
227	113
227	114
227	115
227	116
227	117
227	118
227	119
227	120
227	121
227	122
227	123
227	124
227	125
227	126
227	127
227	128
227	129
227	130
227	131
227	132
227	133
227	134
227	135
227	136
227	137
227	138
227	139
227	140
227	141
227	142
227	143
227	144
227	145
227	146
227	147
227	148
227	149
227	150
227	151
227	152
227	153
227	154
227	155
227	156
227	157
227	158
227	159
227	160
227	161
227	162
227	163
227	164
227	165
227	166
227	167
227	168
227	169
227	170
227	171
227	172
227	173
227	174
227	175
227	176
227	177
227	178
227	179
227	180
227	181
227	182
227	183
227	184
227	185
227	186
227	187
227	188
227	1153
227	1154
227	1155
227	1156
227	1177
227	1178
227	1179
227	1180
227	1225
227	1226
227	1227
227	1228
227	1261
227	1262
227	1263
227	1264
227	1317
227	1318
227	1319
227	1320
227	1321
227	1322
227	1323
227	1324
227	6765
227	6766
227	6767
227	6768
227	9501
227	9502
227	9503
227	9504
227	13461
227	13462
227	13463
227	13464
227	20428
227	20429
227	20430
227	20431
227	40560
227	40561
227	40562
227	40563
227	57556
227	57557
227	57558
227	57559
227	57560
227	57561
227	57562
227	57563
227	57564
227	57565
227	57566
227	57567
227	57568
227	57569
227	57570
227	57571
227	57572
227	57573
227	57574
227	57575
227	57820
227	57821
227	57822
227	57823
227	66696
227	66697
227	66698
227	66699
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, company_id, created_at, updated_at) FROM stdin;
248	Administrator	24	2026-10-26 21:08:54.111664-07	2026-10-26 21:08:54.111664-07
249	Manager	24	2026-10-26 21:08:54.111664-07	2026-10-26 21:08:54.111664-07
250	Employee	24	2026-10-26 21:08:54.111664-07	2026-10-26 21:08:54.111664-07
251	Accountant	24	2026-10-26 21:08:54.111664-07	2026-10-26 21:08:54.111664-07
252	Sales User	24	2026-10-26 21:08:54.111664-07	2026-10-26 21:08:54.111664-07
227	Administrator	23	2026-10-21 22:49:27.968377-07	2026-10-21 22:49:27.968377-07
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.session (sid, sess, expire) FROM stdin;
SMznDvRiAdz_B1qQla6nY7Od1RHceJcL	{"cookie":{"originalMaxAge":null,"expires":null,"secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":33,"username":"spsynet@gmail.com","isAdmin":true,"userRole":"admin","companyId":23,"roleId":227,"permissions":["dashboard:view","dashboard:create","dashboard:edit","dashboard:delete","assets:view","assets:create","assets:edit","assets:delete","licenses:view","licenses:create","licenses:edit","licenses:delete","employees:view","employees:create","employees:edit","employees:delete","payroll:view","payroll:create","payroll:edit","payroll:delete","service_reports:view","service_reports:create","service_reports:edit","service_reports:delete","purchase_orders:view","purchase_orders:create","purchase_orders:edit","purchase_orders:delete","quotations:view","quotations:create","quotations:edit","quotations:delete","sales_orders:view","sales_orders:create","sales_orders:edit","sales_orders:delete","invoices:view","invoices:create","invoices:edit","invoices:delete","proforma_invoices:view","proforma_invoices:create","proforma_invoices:edit","proforma_invoices:delete","credit_notes:view","credit_notes:create","credit_notes:edit","credit_notes:delete","delivery_orders:view","delivery_orders:create","delivery_orders:edit","delivery_orders:delete","point_of_sale:view","point_of_sale:create","point_of_sale:edit","point_of_sale:delete","bill_of_materials:view","bill_of_materials:create","bill_of_materials:edit","bill_of_materials:delete","grn:view","grn:create","grn:edit","grn:delete","stock_items:view","stock_items:create","stock_items:edit","stock_items:delete","warehouses:view","warehouses:create","warehouses:edit","warehouses:delete","stock_transfer:view","stock_transfer:create","stock_transfer:edit","stock_transfer:delete","inventory_reports:view","inventory_reports:create","inventory_reports:edit","inventory_reports:delete","batch_expiry:view","batch_expiry:create","batch_expiry:edit","batch_expiry:delete","vendors:view","vendors:create","vendors:edit","vendors:delete","customers:view","customers:create","customers:edit","customers:delete","projects:view","projects:create","projects:edit","projects:delete","accounting_coa:view","accounting_coa:create","accounting_coa:edit","accounting_coa:delete","accounting_je:view","accounting_je:create","accounting_je:edit","accounting_je:delete","accounting_gl:view","accounting_gl:create","accounting_gl:edit","accounting_gl:delete","accounting_tb:view","accounting_tb:create","accounting_tb:edit","accounting_tb:delete","accounting_bs:view","accounting_bs:create","accounting_bs:edit","accounting_bs:delete","accounting_pl:view","accounting_pl:create","accounting_pl:edit","accounting_pl:delete","accounting_cf:view","accounting_cf:create","accounting_cf:edit","accounting_cf:delete","accounting_gst_f5:view","accounting_gst_f5:create","accounting_gst_f5:edit","accounting_gst_f5:delete","accounting_gst_f7:view","accounting_gst_f7:create","accounting_gst_f7:edit","accounting_gst_f7:delete","accounting_gst_io:view","accounting_gst_io:create","accounting_gst_io:edit","accounting_gst_io:delete","accounting_wht:view","accounting_wht:create","accounting_wht:edit","accounting_wht:delete","accounting_eci:view","accounting_eci:create","accounting_eci:edit","accounting_eci:delete","accounting_formcs:view","accounting_formcs:create","accounting_formcs:edit","accounting_formcs:delete","accounting_iaf:view","accounting_iaf:create","accounting_iaf:edit","accounting_iaf:delete","accounting_ar:view","accounting_ar:create","accounting_ar:edit","accounting_ar:delete","accounting_ar_aging:view","accounting_ar_aging:create","accounting_ar_aging:edit","accounting_ar_aging:delete","accounting_cust_stmt:view","accounting_cust_stmt:create","accounting_cust_stmt:edit","accounting_cust_stmt:delete","accounting_ap:view","accounting_ap:create","accounting_ap:edit","accounting_ap:delete","accounting_ap_aging:view","accounting_ap_aging:create","accounting_ap_aging:edit","accounting_ap_aging:delete","accounting_vendor_stmt:view","accounting_vendor_stmt:create","accounting_vendor_stmt:edit","accounting_vendor_stmt:delete","user_management:view","user_management:create","user_management:edit","user_management:delete","audit_log:view","audit_log:create","audit_log:edit","audit_log:delete","settings:view","settings:create","settings:edit","settings:delete","vendor_invoices:view","vendor_invoices:create","vendor_invoices:edit","vendor_invoices:delete","debit_notes:view","debit_notes:create","debit_notes:edit","debit_notes:delete","address_book:view","address_book:create","address_book:edit","address_book:delete","accounting_bank_recon:view","accounting_bank_recon:create","accounting_bank_recon:edit","accounting_bank_recon:delete","accounting_expenses:view","accounting_expenses:create","accounting_expenses:edit","accounting_expenses:delete","accounting_income:view","accounting_income:create","accounting_income:edit","accounting_income:delete","purchase_quotations:view","purchase_quotations:create","purchase_quotations:edit","purchase_quotations:delete","report_templates:view","report_templates:create","report_templates:edit","report_templates:delete","multi_price_level:view","multi_price_level:create","multi_price_level:edit","multi_price_level:delete","accounting_backup:view","accounting_backup:create","accounting_backup:edit","accounting_backup:delete","sales_person_wise_report:view","sales_person_wise_report:create","sales_person_wise_report:edit","sales_person_wise_report:delete","pos_retail:view","pos_retail:create","pos_retail:edit","pos_retail:delete","pos_supermarket:view","pos_supermarket:create","pos_supermarket:edit","pos_supermarket:delete","pos_restaurants:view","pos_restaurants:create","pos_restaurants:edit","pos_restaurants:delete","pos_pharmacy:view","pos_pharmacy:create","pos_pharmacy:edit","pos_pharmacy:delete","pos_electronics:view","pos_electronics:create","pos_electronics:edit","pos_electronics:delete","pos_reports:view","pos_reports:create","pos_reports:edit","pos_reports:delete","vendor_proforma_invoices:view","vendor_proforma_invoices:create","vendor_proforma_invoices:edit","vendor_proforma_invoices:delete"]}	2026-10-30 22:42:27
1f0zBhjiCl1-rJy70XMY3ygp77HoTUFx	{"cookie":{"originalMaxAge":null,"expires":null,"secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":33,"username":"spsynet@gmail.com","isAdmin":true,"userRole":"admin","companyId":23,"roleId":227,"permissions":["dashboard:view","dashboard:create","dashboard:edit","dashboard:delete","assets:view","assets:create","assets:edit","assets:delete","licenses:view","licenses:create","licenses:edit","licenses:delete","employees:view","employees:create","employees:edit","employees:delete","payroll:view","payroll:create","payroll:edit","payroll:delete","service_reports:view","service_reports:create","service_reports:edit","service_reports:delete","purchase_orders:view","purchase_orders:create","purchase_orders:edit","purchase_orders:delete","quotations:view","quotations:create","quotations:edit","quotations:delete","sales_orders:view","sales_orders:create","sales_orders:edit","sales_orders:delete","invoices:view","invoices:create","invoices:edit","invoices:delete","proforma_invoices:view","proforma_invoices:create","proforma_invoices:edit","proforma_invoices:delete","credit_notes:view","credit_notes:create","credit_notes:edit","credit_notes:delete","delivery_orders:view","delivery_orders:create","delivery_orders:edit","delivery_orders:delete","point_of_sale:view","point_of_sale:create","point_of_sale:edit","point_of_sale:delete","bill_of_materials:view","bill_of_materials:create","bill_of_materials:edit","bill_of_materials:delete","grn:view","grn:create","grn:edit","grn:delete","stock_items:view","stock_items:create","stock_items:edit","stock_items:delete","warehouses:view","warehouses:create","warehouses:edit","warehouses:delete","stock_transfer:view","stock_transfer:create","stock_transfer:edit","stock_transfer:delete","inventory_reports:view","inventory_reports:create","inventory_reports:edit","inventory_reports:delete","batch_expiry:view","batch_expiry:create","batch_expiry:edit","batch_expiry:delete","vendors:view","vendors:create","vendors:edit","vendors:delete","customers:view","customers:create","customers:edit","customers:delete","projects:view","projects:create","projects:edit","projects:delete","accounting_coa:view","accounting_coa:create","accounting_coa:edit","accounting_coa:delete","accounting_je:view","accounting_je:create","accounting_je:edit","accounting_je:delete","accounting_gl:view","accounting_gl:create","accounting_gl:edit","accounting_gl:delete","accounting_tb:view","accounting_tb:create","accounting_tb:edit","accounting_tb:delete","accounting_bs:view","accounting_bs:create","accounting_bs:edit","accounting_bs:delete","accounting_pl:view","accounting_pl:create","accounting_pl:edit","accounting_pl:delete","accounting_cf:view","accounting_cf:create","accounting_cf:edit","accounting_cf:delete","accounting_gst_f5:view","accounting_gst_f5:create","accounting_gst_f5:edit","accounting_gst_f5:delete","accounting_gst_f7:view","accounting_gst_f7:create","accounting_gst_f7:edit","accounting_gst_f7:delete","accounting_gst_io:view","accounting_gst_io:create","accounting_gst_io:edit","accounting_gst_io:delete","accounting_wht:view","accounting_wht:create","accounting_wht:edit","accounting_wht:delete","accounting_eci:view","accounting_eci:create","accounting_eci:edit","accounting_eci:delete","accounting_formcs:view","accounting_formcs:create","accounting_formcs:edit","accounting_formcs:delete","accounting_iaf:view","accounting_iaf:create","accounting_iaf:edit","accounting_iaf:delete","accounting_ar:view","accounting_ar:create","accounting_ar:edit","accounting_ar:delete","accounting_ar_aging:view","accounting_ar_aging:create","accounting_ar_aging:edit","accounting_ar_aging:delete","accounting_cust_stmt:view","accounting_cust_stmt:create","accounting_cust_stmt:edit","accounting_cust_stmt:delete","accounting_ap:view","accounting_ap:create","accounting_ap:edit","accounting_ap:delete","accounting_ap_aging:view","accounting_ap_aging:create","accounting_ap_aging:edit","accounting_ap_aging:delete","accounting_vendor_stmt:view","accounting_vendor_stmt:create","accounting_vendor_stmt:edit","accounting_vendor_stmt:delete","user_management:view","user_management:create","user_management:edit","user_management:delete","audit_log:view","audit_log:create","audit_log:edit","audit_log:delete","settings:view","settings:create","settings:edit","settings:delete","vendor_invoices:view","vendor_invoices:create","vendor_invoices:edit","vendor_invoices:delete","debit_notes:view","debit_notes:create","debit_notes:edit","debit_notes:delete","address_book:view","address_book:create","address_book:edit","address_book:delete","accounting_bank_recon:view","accounting_bank_recon:create","accounting_bank_recon:edit","accounting_bank_recon:delete","accounting_expenses:view","accounting_expenses:create","accounting_expenses:edit","accounting_expenses:delete","accounting_income:view","accounting_income:create","accounting_income:edit","accounting_income:delete","purchase_quotations:view","purchase_quotations:create","purchase_quotations:edit","purchase_quotations:delete","report_templates:view","report_templates:create","report_templates:edit","report_templates:delete","multi_price_level:view","multi_price_level:create","multi_price_level:edit","multi_price_level:delete","accounting_backup:view","accounting_backup:create","accounting_backup:edit","accounting_backup:delete","sales_person_wise_report:view","sales_person_wise_report:create","sales_person_wise_report:edit","sales_person_wise_report:delete","pos_retail:view","pos_retail:create","pos_retail:edit","pos_retail:delete","pos_supermarket:view","pos_supermarket:create","pos_supermarket:edit","pos_supermarket:delete","pos_restaurants:view","pos_restaurants:create","pos_restaurants:edit","pos_restaurants:delete","pos_pharmacy:view","pos_pharmacy:create","pos_pharmacy:edit","pos_pharmacy:delete","pos_electronics:view","pos_electronics:create","pos_electronics:edit","pos_electronics:delete","pos_reports:view","pos_reports:create","pos_reports:edit","pos_reports:delete","vendor_proforma_invoices:view","vendor_proforma_invoices:create","vendor_proforma_invoices:edit","vendor_proforma_invoices:delete"]}	2026-10-30 05:15:57
\.


--
-- Data for Name: user_companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_companies (id, user_id, company_id, modules) FROM stdin;
66	33	23	["purchase_orders", "quotations", "invoices", "delivery_orders"]
72	34	24	["dashboard", "assets", "licenses", "employees", "payroll", "purchase_quotations", "purchase_orders", "vendor_invoices", "vendor_proforma_invoices", "quotations", "sales_orders", "invoices", "proforma_invoices", "delivery_orders", "credit_notes", "debit_notes", "point_of_sale", "pos_retail", "pos_supermarket", "pos_restaurants", "pos_pharmacy", "pos_electronics", "pos_reports", "bill_of_materials", "multi_price_level", "grn", "stock_items", "warehouses", "stock_transfer", "inventory_reports", "sales_person_wise_report", "batch_expiry", "vendors", "customers", "address_book", "projects", "accounting_coa", "accounting_je", "accounting_gl", "accounting_tb", "accounting_bs", "accounting_pl", "accounting_cf", "accounting_bank_recon", "accounting_gst_f5", "accounting_gst_f7", "accounting_gst_io", "accounting_wht", "accounting_eci", "accounting_formcs", "accounting_iaf", "accounting_ar", "accounting_ar_aging", "accounting_cust_stmt", "accounting_ap", "accounting_ap_aging", "accounting_vendor_stmt", "accounting_expenses", "accounting_income", "user_management", "audit_log", "settings", "report_templates"]
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, role, email, created_at, full_name, phone_number, is_active, updated_at, company_id, role_id, sales_person_id, database_name) FROM stdin;
33	spsynet@gmail.com	admin	spsynet@gmail.com	2026-10-21 22:49:28.035569-07	SP Sysnet Pte Ltd	+65 6568 1438	t	2026-10-21 22:49:28.035569-07	23	227	\N	bizone_spsynet
34	msmsolutions@gmail.com	admin	msmsolutions@gmail.com	2026-10-26 21:08:54.111664-07	MSM Solutions	+65 2156 2750	t	2026-10-26 21:08:54.111664-07	24	248	\N	bizone_msmsolutions
\.


--
-- Name: accounting_backups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounting_backups_id_seq', 1, true);


--
-- Name: accounting_restore_operations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounting_restore_operations_id_seq', 1, false);


--
-- Name: backup_retention_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.backup_retention_settings_id_seq', 1, false);


--
-- Name: backup_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.backup_schedules_id_seq', 1, true);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.companies_id_seq', 24, true);


--
-- Name: maintenance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.maintenance_id_seq', 1, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 71199, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 252, true);


--
-- Name: user_companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_companies_id_seq', 72, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 34, true);


--
-- Name: accounting_backups accounting_backups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_backups
    ADD CONSTRAINT accounting_backups_pkey PRIMARY KEY (id);


--
-- Name: accounting_restore_operations accounting_restore_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_restore_operations
    ADD CONSTRAINT accounting_restore_operations_pkey PRIMARY KEY (id);


--
-- Name: backup_retention_settings backup_retention_settings_company_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_retention_settings
    ADD CONSTRAINT backup_retention_settings_company_id_key UNIQUE (company_id);


--
-- Name: backup_retention_settings backup_retention_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_retention_settings
    ADD CONSTRAINT backup_retention_settings_pkey PRIMARY KEY (id);


--
-- Name: backup_schedules backup_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_schedules
    ADD CONSTRAINT backup_schedules_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: login_credentials login_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_credentials
    ADD CONSTRAINT login_credentials_pkey PRIMARY KEY (user_id);


--
-- Name: maintenance maintenance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance
    ADD CONSTRAINT maintenance_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_module_action_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_module_action_unique UNIQUE (module, action);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_role_id_permission_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_permission_id_unique UNIQUE (role_id, permission_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: user_companies user_companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_companies
    ADD CONSTRAINT user_companies_pkey PRIMARY KEY (id);


--
-- Name: user_companies user_companies_user_id_company_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_companies
    ADD CONSTRAINT user_companies_user_id_company_id_key UNIQUE (user_id, company_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: companies_slug_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX companies_slug_unique ON public.companies USING btree (slug) WHERE (slug IS NOT NULL);


--
-- Name: login_credentials login_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_credentials
    ADD CONSTRAINT login_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: roles roles_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: user_companies user_companies_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_companies
    ADD CONSTRAINT user_companies_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: user_companies user_companies_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_companies
    ADD CONSTRAINT user_companies_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE SET NULL;


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 1vaDc1hkBfqEucHo0aB1oyB6LL5Ofa5jBUSe8c6GvjQYz6fprv603z7I0L2MsDX

